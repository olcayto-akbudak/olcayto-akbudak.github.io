"""Yalnız yerel makinede çalışan standart kütüphane HTTP arayüzü."""

from __future__ import annotations

import argparse
import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

from .core import Conflict, Lab


ROOT = Path(__file__).resolve().parent.parent


def make_handler(lab: Lab):
    class Handler(BaseHTTPRequestHandler):
        def _json(self, value, status=200):
            data = json.dumps(value, ensure_ascii=False).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(data)

        def do_GET(self):
            path = urlparse(self.path).path
            if path == "/":
                data = (ROOT / "web" / "index.html").read_bytes()
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)
            elif path == "/api/invoices":
                self._json(lab.invoices())
            elif path == "/api/events":
                self._json(lab.events())
            elif path == "/api/metrics":
                self._json(lab.metrics())
            else:
                self._json({"error": "Bulunamadı"}, 404)

        def do_POST(self):
            path = urlparse(self.path).path
            try:
                length = int(self.headers.get("Content-Length", "0"))
                if length > 16_384 or length <= 0:
                    raise ValueError("JSON gövdesi 1–16384 bayt olmalı")
                body = json.loads(self.rfile.read(length))
                if not isinstance(body, dict):
                    raise ValueError("JSON nesnesi gerekli")
                if path == "/api/invoices":
                    allowed = {"tenant", "environment", "invoice_uuid", "payload_hash", "behavior"}
                    if set(body) - allowed:
                        raise ValueError("Beklenmeyen alan")
                    result = lab.submit(**body)
                    self._json(result)
                elif path == "/api/reconcile":
                    self._json(lab.reconcile(int(body["id"])))
                else:
                    self._json({"error": "Bulunamadı"}, 404)
            except Conflict as exc:
                self._json({"error": str(exc)}, 409)
            except (ValueError, TypeError, KeyError) as exc:
                self._json({"error": str(exc)}, 400)

    return Handler


def main():
    parser = argparse.ArgumentParser(description="Sentetik e-Fatura entegrasyon laboratuvarı")
    parser.add_argument("--port", type=int, default=8080)
    parser.add_argument("--db", default=str(ROOT / "lab.sqlite3"))
    args = parser.parse_args()
    lab = Lab(args.db)
    server = ThreadingHTTPServer(("127.0.0.1", args.port), make_handler(lab))
    print(f"Demo: http://127.0.0.1:{args.port} (Ctrl+C ile durdur)")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
