"""Sentetik belge gönderim ve mutabakat durum makinesi.

Bu modül hiçbir gerçek e-Belge servisine veya üretim hesabına bağlanmaz.
"""

from __future__ import annotations

import sqlite3
import threading
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


class Conflict(ValueError):
    pass


class MockProvider:
    """Kalıcı, deterministik sahte entegratör; belirsiz taşıma hataları üretir."""

    def __init__(self, db_path: Path):
        self.db_path = db_path

    def send(self, tenant: str, environment: str, uuid: str, behavior: str) -> str:
        if behavior == "timeout_before_accept":
            raise TimeoutError("Bağlantı istek işlenmeden kesildi (simülasyon)")
        if behavior == "rejected":
            return "REJECTED"
        with sqlite3.connect(self.db_path) as db:
            db.execute(
                "INSERT OR IGNORE INTO provider_documents "
                "(tenant, environment, invoice_uuid, reference, status) VALUES (?, ?, ?, ?, 'ACCEPTED')",
                (tenant, environment, uuid, "MOCK-" + uuid4().hex[:12].upper()),
            )
        if behavior == "timeout_after_accept":
            raise TimeoutError("İstek işlendi; yanıt kayboldu (simülasyon)")
        return "ACCEPTED"

    def lookup(self, tenant: str, environment: str, uuid: str) -> dict | None:
        with sqlite3.connect(self.db_path) as db:
            db.row_factory = sqlite3.Row
            row = db.execute(
                "SELECT reference, status FROM provider_documents "
                "WHERE tenant=? AND environment=? AND invoice_uuid=?",
                (tenant, environment, uuid),
            ).fetchone()
            return dict(row) if row else None


class Lab:
    BEHAVIORS = {"success", "timeout_after_accept", "timeout_before_accept", "rejected"}

    def __init__(self, db_path: str | Path):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        with self._db() as db:
            db.executescript("""
                CREATE TABLE IF NOT EXISTS invoices (
                    id INTEGER PRIMARY KEY, tenant TEXT NOT NULL, environment TEXT NOT NULL,
                    invoice_uuid TEXT NOT NULL, payload_hash TEXT NOT NULL,
                    state TEXT NOT NULL, provider_reference TEXT,
                    attempts INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    UNIQUE (tenant, environment, invoice_uuid)
                );
                CREATE TABLE IF NOT EXISTS provider_documents (
                    tenant TEXT NOT NULL, environment TEXT NOT NULL,
                    invoice_uuid TEXT NOT NULL, reference TEXT NOT NULL, status TEXT NOT NULL,
                    UNIQUE (tenant, environment, invoice_uuid)
                );
                CREATE TABLE IF NOT EXISTS events (
                    id INTEGER PRIMARY KEY, invoice_id INTEGER NOT NULL,
                    event_type TEXT NOT NULL, detail TEXT NOT NULL, created_at TEXT NOT NULL,
                    FOREIGN KEY(invoice_id) REFERENCES invoices(id)
                );
            """)
        self.provider = MockProvider(self.db_path)

    @contextmanager
    def _db(self):
        db = sqlite3.connect(self.db_path, timeout=15)
        db.row_factory = sqlite3.Row
        try:
            with db:
                yield db
        finally:
            db.close()

    def _event(self, db: sqlite3.Connection, id_: int, kind: str, detail: str) -> None:
        db.execute("INSERT INTO events(invoice_id,event_type,detail,created_at) VALUES(?,?,?,?)",
                   (id_, kind, detail, now()))

    def _get(self, db: sqlite3.Connection, id_: int) -> dict:
        return dict(db.execute("SELECT * FROM invoices WHERE id=?", (id_,)).fetchone())

    def submit(self, *, tenant: str, environment: str, invoice_uuid: str,
               payload_hash: str, behavior: str = "success") -> dict:
        if behavior not in self.BEHAVIORS:
            raise ValueError("Geçersiz simülasyon davranışı")
        if not all(isinstance(v, str) and 1 <= len(v.strip()) <= 100
                   for v in (tenant, environment, invoice_uuid, payload_hash)):
            raise ValueError("tenant, environment, invoice_uuid ve payload_hash gerekli")
        if environment not in {"test", "demo"}:
            raise ValueError("Yalnızca test veya demo ortamı kullanılabilir")
        # Tekil anahtar hem yerel kaydı hem paralel gönderimi korur.
        with self._lock, self._db() as db:
            db.execute("BEGIN IMMEDIATE")
            row = db.execute(
                "SELECT * FROM invoices WHERE tenant=? AND environment=? AND invoice_uuid=?",
                (tenant, environment, invoice_uuid),
            ).fetchone()
            if row:
                if row["payload_hash"] != payload_hash:
                    raise Conflict("Aynı UUID farklı içerik özetiyle kullanılamaz")
                self._event(db, row["id"], "DUPLICATE_BLOCKED", "İkinci gönderim açılmadı")
                return self._get(db, row["id"])
            db.execute(
                "INSERT INTO invoices(tenant,environment,invoice_uuid,payload_hash,state,attempts,created_at,updated_at) "
                "VALUES(?,?,?,?, 'SENDING', 1, ?, ?)",
                (tenant, environment, invoice_uuid, payload_hash, now(), now()),
            )
            id_ = db.execute("SELECT last_insert_rowid()").fetchone()[0]
            self._event(db, id_, "SEND_STARTED", "İlk gönderim girişimi")
        try:
            result = self.provider.send(tenant, environment, invoice_uuid, behavior)
            state = "ACCEPTED" if result == "ACCEPTED" else "REJECTED"
            detail = "Sağlayıcı yanıtı: " + result
        except TimeoutError as exc:
            state, detail = "UNKNOWN", str(exc)
        with self._lock, self._db() as db:
            db.execute("UPDATE invoices SET state=?,updated_at=? WHERE id=?", (state, now(), id_))
            self._event(db, id_, state, detail)
            return self._get(db, id_)

    def reconcile(self, id_: int) -> dict:
        with self._lock, self._db() as db:
            row = db.execute("SELECT * FROM invoices WHERE id=?", (id_,)).fetchone()
            if not row:
                raise KeyError("Belge bulunamadı")
            if row["state"] == "REJECTED":
                return dict(row)
            found = self.provider.lookup(row["tenant"], row["environment"], row["invoice_uuid"])
            if found:
                state = "ACCEPTED"
                detail = "Sağlayıcı referansı ile doğrulandı"
                db.execute("UPDATE invoices SET state=?,provider_reference=?,updated_at=? WHERE id=?",
                           (state, found["reference"], now(), id_))
            else:
                # Yok yanıtı kesin işlem görmeme kanıtı değildir.
                state = "UNKNOWN"
                detail = "Sağlayıcıda görünmüyor; güvenli yeniden gönderim kanıtı yok"
                db.execute("UPDATE invoices SET state=?,updated_at=? WHERE id=?", (state, now(), id_))
            self._event(db, id_, "RECONCILED", detail)
            return self._get(db, id_)

    def invoices(self) -> list[dict]:
        with self._db() as db:
            return [dict(r) for r in db.execute("SELECT * FROM invoices ORDER BY id DESC")]

    def events(self) -> list[dict]:
        with self._db() as db:
            return [dict(r) for r in db.execute("SELECT * FROM events ORDER BY id DESC LIMIT 200")]

    def metrics(self) -> dict:
        with self._db() as db:
            states = {r["state"]: r["n"] for r in db.execute(
                "SELECT state, COUNT(*) n FROM invoices GROUP BY state")}
            duplicates = db.execute(
                "SELECT COUNT(*) FROM events WHERE event_type='DUPLICATE_BLOCKED'").fetchone()[0]
            return {"total": sum(states.values()), "states": states,
                    "blocked_duplicates": duplicates,
                    "provider_documents": db.execute("SELECT COUNT(*) FROM provider_documents").fetchone()[0]}
