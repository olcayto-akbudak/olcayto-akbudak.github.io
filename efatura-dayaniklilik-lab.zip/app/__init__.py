"""e-Fatura entegrasyon dayanıklılığı laboratuvarı."""
