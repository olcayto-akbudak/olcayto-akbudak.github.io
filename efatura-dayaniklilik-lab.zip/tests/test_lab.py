import tempfile
import threading
import unittest
from pathlib import Path

from app.core import Conflict, Lab


class LabTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.lab = Lab(Path(self.tmp.name) / "test.sqlite3")
        self.data = dict(tenant="t1", environment="test", invoice_uuid="uuid-1", payload_hash="sha-demo")

    def tearDown(self):
        self.tmp.cleanup()

    def test_accepted_but_response_lost_is_reconciled_without_resend(self):
        first = self.lab.submit(**self.data, behavior="timeout_after_accept")
        self.assertEqual(first["state"], "UNKNOWN")
        again = self.lab.submit(**self.data, behavior="success")
        self.assertEqual(again["attempts"], 1)
        resolved = self.lab.reconcile(first["id"])
        self.assertEqual(resolved["state"], "ACCEPTED")
        self.assertTrue(resolved["provider_reference"].startswith("MOCK-"))
        self.assertEqual(self.lab.metrics()["provider_documents"], 1)
        self.assertEqual(self.lab.metrics()["blocked_duplicates"], 1)

    def test_absent_document_stays_unknown(self):
        first = self.lab.submit(**self.data, behavior="timeout_before_accept")
        result = self.lab.reconcile(first["id"])
        self.assertEqual(result["state"], "UNKNOWN")
        self.assertEqual(self.lab.metrics()["provider_documents"], 0)

    def test_same_uuid_different_payload_is_conflict(self):
        self.lab.submit(**self.data)
        with self.assertRaises(Conflict):
            self.lab.submit(**(self.data | {"payload_hash": "different"}))
        self.assertEqual(self.lab.metrics()["provider_documents"], 1)

    def test_concurrent_submissions_have_one_provider_document(self):
        results = []
        threads = [threading.Thread(target=lambda: results.append(self.lab.submit(**self.data))) for _ in range(8)]
        for t in threads: t.start()
        for t in threads: t.join()
        self.assertEqual(len(results), 8)
        self.assertEqual({r["id"] for r in results}, {1})
        self.assertEqual(self.lab.metrics()["provider_documents"], 1)
        self.assertEqual(self.lab.metrics()["blocked_duplicates"], 7)

    def test_environment_partition_and_rejection(self):
        a = self.lab.submit(**self.data, behavior="rejected")
        b = self.lab.submit(**(self.data | {"environment": "demo"}))
        self.assertEqual(a["state"], "REJECTED")
        self.assertNotEqual(a["id"], b["id"])


if __name__ == "__main__":
    unittest.main()
