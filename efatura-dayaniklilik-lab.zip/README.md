# e‑Belge Entegrasyon Dayanıklılığı Laboratuvarı

> **Yanıt kayboldu. Fatura gönderildi mi?** Timeout sonrasında güvenli karar vermeyi gösteren, yerel çalışan ve tamamen sentetik bir entegrasyon laboratuvarı.

![Python](https://img.shields.io/badge/Python-3.10%2B-3776AB?logo=python&logoColor=white) ![Tests](https://img.shields.io/badge/Tests-unittest-6FDCC0) ![Data](https://img.shields.io/badge/Data-synthetic-6FDCC0) ![License](https://img.shields.io/badge/License-MIT-blue)

## Ne gösteriyor?

Bir ERP, e‑Fatura gönderim isteği yapar. Entegratör belgeyi işleyebilir, ancak yanıt ERP'ye ulaşmayabilir. Ekranda görülen `timeout`, işlemin başarısız olduğunu kanıtlamaz. Bu proje, belirsiz sonucu ayrı bir durum olarak tutar, sağlayıcıyı sorgular ve aynı belge için ikinci gönderim girişimini engeller.

Bu depo **gerçek GİB bağlantısı, gerçek e‑Fatura üretimi veya mevzuat uyumluluk sertifikası içermez**. Sağlayıcı, veriler ve işlem kimlikleri simülasyondur. Herhangi bir kurum/ürün iç yapısı ya da müşteri verisi kullanılmaz.

### Bir bakışta

| Bileşen | Görevi |
| --- | --- |
| `app/core.py` | Durum makinesi, tekil belge kısıtı, sahte sağlayıcı ve mutabakat |
| `app/server.py` | Yerel HTTP API ve pano sunucusu |
| `web/index.html` | Senaryo seçimi, belge listesi, ölçütler ve olay günlüğü |
| `tests/test_lab.py` | Yanıt kaybı, belirsizlik, çakışma ve paralel gönderim kontrolleri |

## Hızlı başlangıç

Python 3.10 veya üzeri yeterli; üçüncü taraf paket gerekmez.

```bash
python -m app.server
```

Tarayıcıda **http://127.0.0.1:8080** adresini açın. Sunucu yalnız `127.0.0.1` üzerinde dinler. Veriler çalışma klasöründe `lab.sqlite3` dosyasına yazılır; bu dosya Git'e eklenmez. Farklı bir konum veya port için:

```bash
python -m app.server --db /tmp/efatura-demo.sqlite3 --port 8081
```

Testleri çalıştırmak için:

```bash
python -m unittest discover -s tests -v
```

## Demoda izlenecek akış

1. **“İşledi, yanıt kayboldu”** senaryosunu seçip gönderin. Yerel durum `UNKNOWN`, sağlayıcıdaki belge sayısı birdir.
2. Aynı UUID ile bir kez daha gönderin. `DUPLICATE_BLOCKED` olayı oluşur; gönderim sayısı hâlâ birdir.
3. Belgedeki **“Durum sorgula”** düğmesine basın. Sağlayıcı referansı bulunur ve durum `ACCEPTED` olur.
4. Yeni UUID ile **“İşlenmeden bağlantı kesildi”** senaryosunu deneyin. Sorgu sonuç vermese bile durum `UNKNOWN` kalır; sistem kanıtsız yeniden gönderim yapmaz.

### Durumlar

```mermaid
stateDiagram-v2
    [*] --> SENDING: İlk gönderim
    SENDING --> ACCEPTED: Kabul yanıtı
    SENDING --> REJECTED: Kesin ret
    SENDING --> UNKNOWN: Timeout
    UNKNOWN --> ACCEPTED: Sağlayıcıda bulundu
    UNKNOWN --> UNKNOWN: Bulunamadı / kesinlik yok
```

`UNKNOWN`, HTTP bağlantısının durumudur; faturanın iş sonucunu tek başına anlatmaz. Aynı `tenant + environment + invoice_uuid` için SQLite tekil kısıtı uygulanır. İçerik özeti farklıysa aynı UUID ile gönderim `409 Conflict` sonucunu verir. İkinci girişim aynı içerikle gelirse var olan kayıt döner ve olay günlüğüne engelleme yazılır. `SENDING` durumunda kalan bir kayıt da sorgulanabilir; bu, yanıt işlenmeden önce süreç kapanması durumunu gözlemlemeye yardımcı olur.

## API örnekleri

```bash
curl -sS -X POST http://127.0.0.1:8080/api/invoices \
  -H 'Content-Type: application/json' \
  -d '{"tenant":"demo-company","environment":"demo","invoice_uuid":"invoice-demo-001","payload_hash":"sample-v1","behavior":"timeout_after_accept"}'
```

Yanıtın `id` alanıyla mutabakat yapın:

```bash
curl -sS -X POST http://127.0.0.1:8080/api/reconcile \
  -H 'Content-Type: application/json' -d '{"id":1}'
```

| Uç nokta | Açıklama |
| --- | --- |
| `POST /api/invoices` | İlk gönderimi simüle eder; `behavior`: `success`, `timeout_after_accept`, `timeout_before_accept`, `rejected` |
| `POST /api/reconcile` | `id` ile sahte sağlayıcı durumunu sorgular |
| `GET /api/invoices` | Yerel belge kayıtları |
| `GET /api/events` | Son 200 olay |
| `GET /api/metrics` | Durum sayıları, engellenen tekrarlar, sağlayıcı belge sayısı |

## Analist açısından kabul ölçütleri

- Yanıt kaybı, otomatik ikinci gönderime dönüşmemeli.
- Aynı UUID'yi eşzamanlı gönderen işçiler tek bir sağlayıcı belgesi üretmeli.
- Sağlayıcıda işlenmiş kayıt bulunduğunda yerel durum ve referans mutabık hâle gelmeli.
- Sağlayıcıda bulunamayan kayıt kesin başarısız sayılmamalı; incelemeye açık kalmalı.
- Test ve demo ortamları birbirinin sonuçlarını karıştırmamalı.

Bu ölçütler `tests/test_lab.py` içinde doğrulanır. Uygulama, operatörün gerçek dünyada ne zaman yeniden gönderime izin verebileceğine karar vermez; böyle bir karar için ilgili entegratör API sözleşmesi ve resmî belge akışı gerekir.

## Mimari kararlar ve sınırlar

- **SQLite:** Kurulum gerektirmeyen, tekrar üretilebilir demo. Üretimde dağıtık işçiler için veritabanı işlemleri, kilitleme ve idempotency sözleşmesi ayrıca tasarlanır.
- **Sahte sağlayıcı:** `timeout_after_accept` önce belgeyi kaydeder, sonra yanıtı kaybettirir. `timeout_before_accept` hiç kayıt açmaz. Her iki durumda da istemci önce `UNKNOWN` görür.
- **İçerik özeti:** `payload_hash` demoda örnek dizedir. Üretimde kanonik içerik özeti, mahremiyet, imza ve sürüm yönetimi ayrı tasarım konularıdır.
- **Güvenlik:** Yerel demo için kimlik doğrulama ve çok kiracılı erişim kontrolü uygulanmadı; internete açılmamalıdır. Veri girişi sentetik tutulmalıdır.
- **Yeniden deneme:** Yok yanıtı nihai kanıt sayılmaz. Otomatik tekrar politikasının koşulları dış sağlayıcının sözleşmesine bağlıdır.

HTTP'deki idempotent yeniden deneme ayrımı için [RFC 9110 §9.2.2](https://www.rfc-editor.org/rfc/rfc9110.html#section-9.2.2), Türkiye e‑Fatura uygulama akışı için [GİB e‑Fatura Entegrasyon Kılavuzu](https://ebelge.gib.gov.tr/dosyalar/kilavuzlar/e-FaturaUygulamasiEntegrasyonKilavuzu-v1.9.pdf) incelenebilir. Bu genel model, belirli bir entegratörün zorunlu davranışı olduğu iddiasında bulunmaz.

## Geliştirme yol haritası

- [ ] Sözleşmeye dayalı güvenli yeniden deneme politikası ve operatör onayı
- [ ] Gecikmiş görünürlük, art arda sorgu hatası ve kuyruk yaşı simülasyonu
- [ ] OpenTelemetry benzeri korelasyon kimliği ve ölçüm dışa aktarımı
- [ ] Ayrı ERP adaptörü, entegratör adaptörü ve sözleşme testleri
- [ ] Sentetik veriyle daha kapsamlı yük ve hata enjeksiyon senaryoları

**Yazar:** İbrahim Olcayto Akbudak — İş Geliştirme Analisti. Bu depo, ERP ve e‑Dönüşüm entegrasyonlarında iş analizi ile teknik hata teşhisinin birlikte nasıl yürütülebileceğini göstermek amacıyla hazırlanmıştır.
