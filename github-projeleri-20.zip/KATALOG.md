# 20 İleri Seviye GitHub Projesi

Olcayto Akbudak için iş/sistem analizi ve entegrasyon odaklı 20 bağımsız çalışma. Her projede çalışan alan motoru, sentetik girdi, CLI, **8 alan testi**, gerçek örnek çıktı, Türkçe README, mimari, veri sözleşmesi, işletim ve karar belgeleri ile GitHub Actions vardır. Toplam **160 test** yerel Python 3.12 ortamında geçti; **20 demo** çalıştırıldı. Bunlar üretim servisi olarak doğrulanmış ürünler değildir; zor mühendislik problemlerini çalıştırılabilir biçimde ele alan laboratuvarlardır.

## Proje haritası

| No | Proje | Depo adı | Zor teknik kapsam | Test |
|---|---|---|---|---|
| 01 | [E-Fatura Kalıcı Gönderim ve Toparlanma](repos/invoice-outbox-recovery/README.md) | `invoice-outbox-recovery` | Lease fencing, idempotency, belirsiz sonuç mutabakatı | 8 |
| 02 | [UBL XML İş Kuralı Motoru](repos/ubl-business-rule-engine/README.md) | `ubl-business-rule-engine` | Namespace, Decimal, tutar ve vergi tutarlılığı | 8 |
| 03 | [Yönlü API Sözleşmesi Analizi](repos/api-contract-evolution/README.md) | `api-contract-evolution` | İstek/yanıt uyumluluğu, değişiklik kapısı | 8 |
| 04 | [Kesinti ve Retry Fırtınası Simülatörü](repos/retry-storm-simulator/README.md) | `retry-storm-simulator` | Olay kuyruğu, token bucket, jitter, circuit breaker | 8 |
| 05 | [Fatura Olay Kaydı ve Replay](repos/invoice-event-replay/README.md) | `invoice-event-replay` | HMAC zinciri, durum makinesi, dış checkpoint | 8 |
| 06 | [Ödeme ve Fatura Mutabakatı](repos/payment-ledger-reconciliation/README.md) | `payment-ledger-reconciliation` | Kısmi tahsis, çoklu referans, kuruş bazlı korunum | 8 |
| 07 | [Süreç Uygunluk ve Varyant Analizi](repos/process-conformance-miner/README.md) | `process-conformance-miner` | Petri net token replay, paralel adımlar | 8 |
| 08 | [Geç Gelen CDC ve SCD2 Ambarı](repos/cdc-scd2-warehouse/README.md) | `cdc-scd2-warehouse` | Event-time, tombstone, tarihçe yeniden kurma | 8 |
| 09 | [Zamansal Müşteri Risk Modeli](repos/temporal-churn-risk/README.md) | `temporal-churn-risk` | Lojistik regresyon, label olgunlaşması, holdout | 8 |
| 10 | [Çok Kademeli Stok ve Kapasite](repos/multi-echelon-inventory/README.md) | `multi-echelon-inventory` | Merkez/depo, lead time, stok pozisyonu, adil tahsis | 8 |
| 11 | [Mevsimsel Anomali Konsensüsü](repos/anomaly-consensus-engine/README.md) | `anomaly-consensus-engine` | Median/MAD, EWMA, ardışık alarm oyları | 8 |
| 12 | [Kısıtlı Müşteri Eşleştirme](repos/entity-resolution-workbench/README.md) | `entity-resolution-workbench` | Unicode normalizasyonu, blocking, cluster constraint | 8 |
| 13 | [Gereksinim ve Test İzlenebilirliği](repos/requirements-traceability-graph/README.md) | `requirements-traceability-graph` | DAG, risk ağırlığı, revision freshness, impact BFS | 8 |
| 14 | [Entegrasyon Test DAG Orkestratörü](repos/integration-test-orchestrator/README.md) | `integration-test-orchestrator` | Sanal scheduler, timeout, safe retry, bağımlılık | 8 |
| 15 | [Sipariş Saga ve Telafi Laboratuvarı](repos/order-saga-recovery/README.md) | `order-saga-recovery` | Kalıcı adımlar, çökme enjeksiyonu, compensation | 8 |
| 16 | [SLA ve Çok Pencereli Burn Rate](repos/sla-error-budget-monitor/README.md) | `sla-error-budget-monitor` | SLO, düşük hacim koruması, p95, hata bütçesi | 8 |
| 17 | [Tenant Adil Kuyruk Motoru](repos/tenant-fair-queue/README.md) | `tenant-fair-queue` | Weighted deficit round robin, değişken maliyet | 8 |
| 18 | [Dayanıklı Proje Portföyü Optimizasyonu](repos/robust-portfolio-optimizer/README.md) | `robust-portfolio-optimizer` | Exact branch and bound, min-max scenarios, bağımlılık | 8 |
| 19 | [Veri Sözleşmesi ve Karantina](repos/data-contract-quality-gate/README.md) | `data-contract-quality-gate` | Type/range/reference/unique/freshness, PSI | 8 |
| 20 | [SQL Doğruluk ve Plan Regresyonu](repos/sql-plan-regression-lab/README.md) | `sql-plan-regression-lab` | Preaggregation, join fanout, digest, query plan | 8 |

## Kullanım

Ana ZIP'i açın, `repos/` altında istediğiniz projeye girin:

```bash
python -m unittest discover -s tests -v
python -m app demo
```

Bütün projeleri ayrı süreçlerde doğrulamak için koleksiyon kökünde `python verify_all.py` çalıştırın. Dış Python paketi gerekmez. Tek tek yüklemek için `individual-zips/` içindeki depo arşivlerini kullanabilirsiniz. README ve docs belgeleri her bağımsız deponun içinde bulunur.

## GitHub durumu

20 proje GitHub'a yüklenmeye hazırdır; bu teslimat GitHub hesabında 20 uzak depo oluşturmaz. Depo adları öneridir; var olan aynı adlı depoların üzerine yazılmamalıdır. Her depodaki README hesap adına uygun git komutlarını içerir. CI tanımlıdır; GitHub üzerinde henüz çalıştırılmamıştır.

## İnceleme sırası

Önce outbox, event replay, CDC ve saga projeleriyle veri bütünlüğünü inceleyin. Ardından contract evolution ve test DAG ile değişiklik güvenliğini değerlendirin. Veri/operasyon projelerinde ölçümleri ve yöntem sınırlarını `docs/results.md` ile birlikte okuyun. Portföy optimizasyonunda exact çözüm küçük örnekte brute-force oracle ile; SQL laboratuvarında sonuçlar bağımsız beklenen toplamla çapraz doğrulanır.

## Dosya yapısı

- `app/core.py`: projeye özgü motor
- `app/__main__.py`: JSON giriş/çıkış CLI
- `tests/test_core.py`: kabul, ret ve sınır testleri
- `examples/scenario.json`: tamamen sentetik girdi
- `outputs/sample-report.json`: çalıştırılmış çıktı
- `docs/`: mimari, sözleşme, runbook, tasarım kararları, sonuç ve test günlüğü
- `.github/workflows/ci.yml`: Python 3.12/3.13, Ubuntu/Windows test matrisi
- `LICENSE`: MIT

## Yöntem ve araç referansları

- Python SQLite: https://docs.python.org/3/library/sqlite3.html
- Python unittest: https://docs.python.org/3/library/unittest.html
- GitHub Python CI: https://docs.github.com/en/actions/tutorials/build-and-test-code/python
- UBL standardı: https://docs.oasis-open.org/ubl/UBL-2.3.html

Bütün üretim açıkları projeye özgü README ve karar kayıtlarında belirtilmiştir. Kullanılan veriler gerçek şirket, müşteri veya mali işlem verisi değildir.
