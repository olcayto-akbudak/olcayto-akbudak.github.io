from pathlib import Path
import subprocess,sys
root=Path(__file__).resolve().parent
failed=[]
for repo in sorted((root/"repos").iterdir()):
    if not repo.is_dir():continue
    print(f"\n{repo.name}",flush=True)
    for command in ([sys.executable,"-m","unittest","discover","-s","tests","-v"],[sys.executable,"-m","app","demo"]):
        if subprocess.run(command,cwd=repo).returncode:failed.append(repo.name)
if failed:print("Failed:",sorted(set(failed)))
else:print("All 20 projects passed tests and demos.")
sys.exit(bool(failed))
