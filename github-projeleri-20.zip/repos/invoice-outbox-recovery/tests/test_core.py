import unittest, tempfile, json, sqlite3, copy
from pathlib import Path
from app import core as c

class CoreTests(unittest.TestCase):

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name) / 'test.sqlite'
        self.config = json.loads((Path(__file__).resolve().parents[1] / 'examples/scenario.json').read_text(encoding='utf-8'))
        with c.sqlite_session(self.path) as connection:
            connection.execute('SELECT 1')
        with self.assertRaises(sqlite3.ProgrammingError):
            connection.execute('SELECT 1')

    def test_dedup(self):
        b = c.Outbox(self.path)
        a = b.enqueue('T', 'U', {'x': 1})
        self.assertEqual(a, b.enqueue('T', 'U', {'x': 1}))

    def test_conflict(self):
        b = c.Outbox(self.path)
        b.enqueue('T', 'U', 1)
        with self.assertRaises(c.Conflict):
            b.enqueue('T', 'U', 2)

    def test_fence(self):
        b = c.Outbox(self.path)
        b.enqueue('T', 'U', 1)
        old = b.claim('A', 0)
        new = b.claim('B', 30)
        with self.assertRaises(c.StaleLease):
            b.complete(old, 31)
        b.complete(new, 31)
        self.assertEqual(b.snapshot()['jobs'][0]['state'], 'ACCEPTED')

    def test_provider_dedup(self):
        b = c.Outbox(self.path)
        b.enqueue('T', 'U', 1)
        a = b.claim('A', 0)
        ref = b.provider_accept(a)
        new = b.claim('B', 31)
        self.assertEqual(ref, b.provider_accept(new))
        self.assertEqual(b.snapshot()['provider_documents'], 1)

    def test_unknown_not_retried(self):
        b = c.Outbox(self.path)
        key = b.enqueue('T', 'U', 1)
        a = b.claim('A', 0)
        b.complete(a, 1, 'UNKNOWN')
        self.assertEqual(b.reconcile(key), 'UNKNOWN')
        self.assertIsNone(b.claim('B', 100))

    def test_tenant_isolation(self):
        b = c.Outbox(self.path)
        b.enqueue('A', 'U', 1)
        b.enqueue('B', 'U', 1)
        self.assertEqual(len(b.snapshot()['jobs']), 2)

    def test_concurrent_enqueue(self):
        from concurrent.futures import ThreadPoolExecutor
        b = c.Outbox(self.path)
        with ThreadPoolExecutor(max_workers=4) as pool:
            results = list(pool.map(lambda _: b.enqueue('T', 'U', 1), range(20)))
        self.assertEqual(len(set(results)), 1)
        self.assertEqual(len(b.snapshot()['jobs']), 1)

    def test_exact_lease_expiry(self):
        b = c.Outbox(self.path)
        b.enqueue('T', 'U', 1)
        a = b.claim('A', 0, ttl=5)
        with self.assertRaises(c.StaleLease):
            b.complete(a, 5)
if __name__ == '__main__':
    unittest.main()
