"""E-Fatura Kalıcı Gönderim ve Toparlanma.

Problem: Sağlayıcı kabulü ile yerel durum kaydı arasında süreç çökerse aynı faturanın ikinci kez oluşmasını önlemek.
Method: Lease fencing, idempotency, belirsiz sonuç mutabakatı
Invariant: Sağlayıcının tenant ve UUID bazında kalıcı idempotency sağlaması gerekir; yerel mock bu varsayımı uygular.
Boundary: SQLite yazma kilidi yatay ölçeklemeyi sınırlar; gerçek sağlayıcı, sır yönetimi ve bağımsız mutabakat işçisi eklenmelidir."""
import hashlib, json, sqlite3, tempfile
from pathlib import Path
from contextlib import contextmanager

@contextmanager
def sqlite_session(path, **kwargs):
    """Commit or roll back, then always close the OS file handle."""
    connection = sqlite3.connect(path, **kwargs)
    try:
        with connection:
            yield connection
    finally:
        connection.close()

class Conflict(ValueError):
    pass

class StaleLease(RuntimeError):
    pass

class Outbox:

    def __init__(self, path):
        self.path = str(path)
        with self.connect() as db:
            db.executescript("CREATE TABLE IF NOT EXISTS jobs(\n              id INTEGER PRIMARY KEY,tenant TEXT,uuid TEXT,digest TEXT,payload TEXT,\n              state TEXT DEFAULT 'PENDING',owner TEXT,lease_until REAL DEFAULT 0,\n              fence INTEGER DEFAULT 0,attempts INTEGER DEFAULT 0,\n              UNIQUE(tenant,uuid));\n              CREATE TABLE IF NOT EXISTS provider(tenant TEXT,uuid TEXT,digest TEXT,\n              reference TEXT,PRIMARY KEY(tenant,uuid));")

    @contextmanager
    def connect(self):
        with sqlite_session(self.path, timeout=5) as db:
            db.row_factory = sqlite3.Row
            yield db

    def enqueue(self, tenant, uuid, payload):
        if not tenant or not uuid:
            raise ValueError('tenant and uuid required')
        value = json.dumps(payload, sort_keys=True, separators=(',', ':'))
        digest = hashlib.sha256(value.encode()).hexdigest()
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            old = db.execute('SELECT * FROM jobs WHERE tenant=? AND uuid=?', (tenant, uuid)).fetchone()
            if old:
                if old['digest'] != digest:
                    raise Conflict('UUID reused with different payload')
                return old['id']
            return db.execute('INSERT INTO jobs(tenant,uuid,digest,payload) VALUES (?,?,?,?)', (tenant, uuid, digest, value)).lastrowid

    def claim(self, owner, now, ttl=30):
        if not owner or ttl <= 0:
            raise ValueError('positive lease and owner required')
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            row = db.execute("SELECT * FROM jobs WHERE state='PENDING' OR (state='SENDING' AND lease_until<=?) ORDER BY id LIMIT 1", (now,)).fetchone()
            if not row:
                return None
            db.execute("UPDATE jobs SET state='SENDING',owner=?,lease_until=?,fence=fence+1,attempts=attempts+1 WHERE id=?", (owner, now + ttl, row['id']))
            return dict(db.execute('SELECT * FROM jobs WHERE id=?', (row['id'],)).fetchone())

    def provider_accept(self, claim):
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            old = db.execute('SELECT * FROM provider WHERE tenant=? AND uuid=?', (claim['tenant'], claim['uuid'])).fetchone()
            if old:
                if old['digest'] != claim['digest']:
                    raise Conflict('provider conflict')
                return old['reference']
            reference = 'MOCK-' + str(claim['id'])
            db.execute('INSERT INTO provider VALUES (?,?,?,?)', (claim['tenant'], claim['uuid'], claim['digest'], reference))
            return reference

    def complete(self, claim, now, state='ACCEPTED'):
        if state not in ['ACCEPTED', 'UNKNOWN', 'REJECTED']:
            raise ValueError('invalid terminal outcome')
        with self.connect() as db:
            changed = db.execute("UPDATE jobs SET state=? WHERE id=? AND owner=? AND fence=? AND lease_until>? AND state='SENDING'", (state, claim['id'], claim['owner'], claim['fence'], now)).rowcount
            if changed != 1:
                raise StaleLease('worker lost its lease')

    def reconcile(self, job_id):
        with self.connect() as db:
            row = db.execute('SELECT * FROM jobs WHERE id=?', (job_id,)).fetchone()
            if row is None:
                raise KeyError(job_id)
            if row['state'] != 'UNKNOWN':
                return row['state']
            effect = db.execute('SELECT * FROM provider WHERE tenant=? AND uuid=?', (row['tenant'], row['uuid'])).fetchone()
            if effect:
                db.execute("UPDATE jobs SET state='ACCEPTED' WHERE id=?", (job_id,))
                return 'ACCEPTED'
            return 'UNKNOWN'

    def snapshot(self):
        with self.connect() as db:
            return {'jobs': [dict(r) for r in db.execute('SELECT id,tenant,uuid,state,fence,attempts FROM jobs ORDER BY id')], 'provider_documents': db.execute('SELECT COUNT(*) FROM provider').fetchone()[0]}

def run(config):
    if not config['documents']:
        raise ValueError('at least one document required')
    with tempfile.TemporaryDirectory() as temp:
        box = Outbox(Path(temp) / 'lab.sqlite')
        for doc in config['documents']:
            box.enqueue(doc['tenant'], doc['uuid'], doc['payload'])
        claim = box.claim('worker-1', 0)
        box.provider_accept(claim)
        recovered = box.claim('worker-2', 31)
        box.provider_accept(recovered)
        box.complete(recovered, 32, 'UNKNOWN')
        box.reconcile(recovered['id'])
        while (job := box.claim('worker-2', 40)):
            box.provider_accept(job)
            box.complete(job, 41)
        return box.snapshot()
