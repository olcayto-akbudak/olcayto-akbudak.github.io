# Tasarım kararları

## Alan motorunu CLI'dan ayırmak

`run(config)` orkestrasyonu kaynak kodun doğrudan test edilebilmesini sağlar. JSON arayüz taşınabilirliği artırır; bu sürüm kullanıcı arayüzü barındırmaz.

## Seçilen yöntem

Lease fencing, idempotency, belirsiz sonuç mutabakatı. Sağlayıcının tenant ve UUID bazında kalıcı idempotency sağlaması gerekir; yerel mock bu varsayımı uygular.

## Bilinçli sınır

SQLite yazma kilidi yatay ölçeklemeyi sınırlar; gerçek sağlayıcı, sır yönetimi ve bağımsız mutabakat işçisi eklenmelidir.

## Önerilen sonraki doğrulama

Gerçek kullanım hacmiyle testten önce mevcut kabul ve ret örneklerinin alan uzmanı tarafından onaylanması gerekir. Sonraki sürüm performans ölçümleri, dış adaptör sözleşmesi ve üretim gözlemlenebilirliğini ayrı karar kayıtlarında ele almalıdır.
