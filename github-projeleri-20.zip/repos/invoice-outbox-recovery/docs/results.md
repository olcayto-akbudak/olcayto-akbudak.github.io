# Çalıştırılmış kabul sonuçları

Python 3.12.14, sentetik `examples/scenario.json`; yerel test sayısı **8**, tümü başarılı. Ham test günlüğü `docs/test-log.txt`.

2 iş ACCEPTED durumunda; 2 sağlayıcı kaydı. İlk iş çökme sonrası 2 kez claim edildi.

Sonuçlar yalnız bu örneğe aittir; üretim doğruluğu veya performans garantisi olarak yorumlanmamalıdır. Ölçülen iş sonucunu kontrol edin; örnek negatif vaka içeriyorsa ret beklenir. Tam çıktı `outputs/sample-report.json`.

## Sınanan davranışlar

| Test | Kontrol |
|---|---|
| `test_dedup` | dedup |
| `test_conflict` | conflict |
| `test_fence` | fence |
| `test_provider_dedup` | provider dedup |
| `test_unknown_not_retried` | unknown not retried |
| `test_tenant_isolation` | tenant isolation |
| `test_concurrent_enqueue` | concurrent enqueue |
| `test_exact_lease_expiry` | exact lease expiry |

## Gelişmiş deney planı

1. İki işçiyle aynı lease sonrasında completion yarışını enjekte edin.
2. Sağlayıcı kabulü sonrası 100 rastgele çökme üretin; provider_documents büyümesini ölçün.
3. Aynı UUID farklı payload durumunu API seviyesinde 409 yanıtına eşleyin.
4. UNKNOWN kayıtları için salt sorgu kullanan ayrı mutabakat işçisi ekleyin.
