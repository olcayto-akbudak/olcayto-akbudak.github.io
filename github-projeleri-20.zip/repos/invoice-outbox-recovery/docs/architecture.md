# Mimari

Sağlayıcı kabulü ile yerel durum kaydı arasında süreç çökerse aynı faturanın ikinci kez oluşmasını önlemek.

```mermaid
flowchart TD
  A["Sentetik senaryo"] --> B["Girdi ve kural doğrulama"]
  B --> C["Lease fencing"]
  C --> D["Bulgular ve durumlar"]
  D --> E["JSON rapor"]
```

Asıl alan akışı: **Outbox.claim → provider_accept → complete → reconcile**. CLI JSON yükler, çekirdek `run(config)` alan motorunu çağırır ve JSON seri hale getirir. Veritabanı kullanan örnekler geçici dizinde izole edilir; kalıcı sınıflar doğrudan çağrılırken dosya yolu dışarıdan verilir.

## İnvariant ve başarısızlık sınırı

Sağlayıcının tenant ve UUID bazında kalıcı idempotency sağlaması gerekir; yerel mock bu varsayımı uygular.

SQLite yazma kilidi yatay ölçeklemeyi sınırlar; gerçek sağlayıcı, sır yönetimi ve bağımsız mutabakat işçisi eklenmelidir.

Her hata kararı makine tarafından okunabilir çıktı veya açık exception üretir. Geçersiz yapılandırma sessizce düzeltilmez. Olası tekrarların güvenliği ilgili çekirdeğin kabul kurallarına bağlıdır; bütün projelere ortak bir retry uygulanmaz.
