# İşletim ve hata inceleme

1. `python --version` ile 3.12 veya daha yeni sürümü doğrulayın.
2. Depo kökünde testleri çalıştırın; başarısız test varken senaryoyu referans kabul etmeyin.
3. `examples/scenario.json` dosyasının bir kopyasını değiştirin; referans örneği koruyun.
4. `python -m app demo --input <dosya> --output outputs/deney.json` çalıştırın.
5. Beklenen ret/inceleme ile beklenmeyen exception durumunu ayırın.
6. Çıktıyı `outputs/sample-report.json` ile karşılaştırın; sentetik negatif örnekleri otomatik başarıya çevirmeyin.

## Projeye özgü kontrol

compare(request/response) → change list → BLOCK/REVIEW/PASS

JSON Schema alt kümesi desteklenir; bilinmeyen anahtarlar manuel incelemeye yönlendirilir.

## Arıza çözümü

JSON parse hatasında girdi biçimini; eksik alan hatasında sözleşmeyi; kural ihlalinde alan bulgusunu; SQLite kilidinde eşzamanlı yazıcı sayısını inceleyin. Gerçek veriyi paylaşmadan önce anonimleştirin. Başarı iddiasını raporun gate/valid/fit/correct/state alanının ilgili semantiğiyle ilişkilendirin; sadece exit code yeterli değildir.

## Üretim açığı

Tam OpenAPI çözümleyicisi değildir; $ref, oneOf ve tüm validator semantiği ayrıca gerekir.
