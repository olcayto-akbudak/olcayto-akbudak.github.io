# Fiyat ve talep ilişkisi

**Durum:** Tamamlanmış, tekrar üretilebilir sentetik veri analizi. Gerçek işletme verisi değildir.

**Soru:** Fiyat aralıklarında satış miktarı nasıl değişiyor?

**Veri:** `160` sentetik kayıt, alanlar: price_band, units_sold, discount_pct.

**Yöntem:** SQLite sorgusu `analysis.sql` dosyasındadır. Python 3 ile `python analizler/fiyat-talep/run.py` çalıştırın. Önceden çalıştırılmış çıktı `results.json`, tarayıcı raporu `index.html` dosyasındadır.

**Yorumlama sınırı:** Fiyat bantları ürün ve sezon etkilerini kontrol etmez; esneklik katsayısı çıkarılmaz.
