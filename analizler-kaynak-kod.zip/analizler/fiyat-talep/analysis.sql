SELECT price_band, COUNT(*) AS gozlem, ROUND(AVG(units_sold),1) AS ort_birim, ROUND(AVG(discount_pct),1) AS ort_indirim FROM data GROUP BY price_band ORDER BY ort_birim DESC;
