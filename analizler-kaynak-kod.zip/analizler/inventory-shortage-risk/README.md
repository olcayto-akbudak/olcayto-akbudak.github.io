# Stok yokluğu kayıp stres testi

Tamamen sentetik, sabit tohumlu portföy çalışması. Gerçek kurum sonucu değildir.

## Soru
Kayıp marj için önlem primi ortak şok ve ağır kuyruk altında ekonomik olarak dayanıklı mı?

## Yöntem
- 12 maruziyetin 800 ortak senaryosu üretilir. Senaryodaki ortak şok olay olasılığını dört katına çıkarır; maruziyetleri bağımsız toplamaktan farklı bir yoğunlaşma yapısı oluşur. Şok dışında olaylar koşullu bağımsızdır.
- Olay şiddeti ağır kuyruklu Pareto çekilişiyle üretilir ve 2,5 kat maruziyette sınırlandırılır. Aday önlem aynı olayları kullanarak brüt kaybı %30 azaltır; her senaryoda 920 örnek para birimi prim eklenir.
- Net kayıp brüt kayıp artı sabit primdir. %95 VaR sıralı örneğin nearest-rank eşiğidir. CVaR bu eşikten başlayan üst kuyruk sıralarının ortalamasıdır; kesikli örnekte bağlar ve kuyruk satır sayısı tanımın parçasıdır.
- Baz çizgi ve aday aynı senaryo kimliğinde eşlenir. 250 senaryo bootstrap yalnız ortalama net kazanım aralığı üretir; kuyruk metrikleri için güven aralığı iddia edilmez. Prim yarım, baz ve iki kat değerlerinde yeniden değerlendirilir.
- Birim kimliği, ilişki anahtarı ve satır düzeyi veri sözleşmesinde açıkça tutulur. SQL önce analiz birimini oluşturur; çoklu tablo satırları bağımsız gözlem gibi sayılmaz. Eksik sonuç ve gerçek sıfır aynı anlama gelmez.
- Sonuçlar sabit tohumlu sentetik senaryodan hesaplanır. Kaynak CSV, şema, SQL sorgusu, parametreler ve tam çıktılar aynı pakette bulunur; yeniden üretim karşılaştırması sayfa metnindeki rakamların kaynakla tutarlılığını denetler.

## Bulgular
- Baz çizgi ortalama net kayıp 1650.533, aday 2075.366. CVaR sırasıyla 10308.756 ve 8136.122.
- Ortalama net kazanım -424.834; %95 senaryo bootstrap aralığı -474.6089–-365.4414. Prim düşüşü veya artışı ekonomik kararı değiştirebilir; uç kayıp ve ortalama aynı karar ölçütü değildir.

## Karar
Tampon stok primini ortak talep şokuyla değerlendir. Önce küçük kapsamlı bir pilot uygula; baz çizgiyle aynı analiz biriminde karşılaştır. Etki, belirsizlik ve yan etki ölçütlerini ayrı izle. Başarı eşiği ihlal edilirse yayılımı durdur ve veri kalitesi ile varsayımları yeniden değerlendir.

## Sınırlar
- Şok olasılığı, Pareto kuyruğu ve önlem katsayısı varsayımsaldır. Sonuçların doğrulanması yalnız hesaplamanın yeniden üretilebildiğini gösterir; gerçek risk kalibrasyonu olduğunu göstermez.
- 800 senaryo çok nadir felaketleri yeterince temsil etmeyebilir. CVaR, senaryo kümesinin dışında kalan kayıplar için üst sınır veya garanti değildir. Örnek para birimi gerçek kurum maliyeti değildir.
- Ürün ikamesi ve kayıp müşteri etkisi yoktur.
- Bu çalışma üretime hazır bir karar sistemi değildir. Pilot öncesinde veri sahibi, iş birimi ve teknik ekip ölçüm tanımını, yanlış karar maliyetini ve geri dönüş koşulunu birlikte belirlemelidir.

## Çalıştırma
Python 3.10+; paket kökünde `python run.py --study inventory-shortage-risk`. CSV tabloları SQLite içine yüklenir, analysis.sql sorguları çalıştırılır ve results.json ile karşılaştırılır. Simülasyon/model çıktıları için `python build_expansion.py`; bütün çıktılar aynı tohumla yeniden üretilir.

## Kontroller
- Her senaryoda iki politika var
- Kayıplar ve maruziyetler negatif değil
- Aday brüt kayıp baz çizgiyi aşmıyor
- CVaR VaR eşiğinden küçük değil

## Veri sözleşmesi
`contract.json` analiz birimi, kolon tipleri, satır sayıları ve sabit tohumu kaydeder. SQL SQLite sözdizimindedir. Takvim ve oran eşikleri bu sentetik senaryonun varsayımlarıdır.
