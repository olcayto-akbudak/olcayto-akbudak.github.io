# Talep eğilimi ve hareketli ortalama

**Durum:** Tamamlanmış, tekrar üretilebilir sentetik veri analizi. Gerçek işletme verisi değildir.

**Soru:** Son üç ay ortalamasına göre ürün grubu talebi nasıl seyreder?

**Veri:** `36` sentetik kayıt, alanlar: category, month, units.

**Yöntem:** SQLite sorgusu `analysis.sql` dosyasındadır. Python 3 ile `python analizler/talep-tahmini/run.py` çalıştırın. Önceden çalıştırılmış çıktı `results.json`, tarayıcı raporu `index.html` dosyasındadır.

**Yorumlama sınırı:** Üç aylık geçmiş/şimdiki ortalamadır; ileriye dönük tahmin modeli değildir.
