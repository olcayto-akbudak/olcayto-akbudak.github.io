SELECT category,month,units,ROUND(AVG(units) OVER (PARTITION BY category ORDER BY month ROWS BETWEEN 2 PRECEDING AND CURRENT ROW),1) AS uc_ay_ort FROM data WHERE month>=9 ORDER BY category,month;
