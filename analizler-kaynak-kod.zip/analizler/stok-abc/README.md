# ERP stok ABC analizi

**Durum:** Tamamlanmış, tekrar üretilebilir sentetik veri analizi. Gerçek işletme verisi değildir.

**Soru:** Hangi ürünler stok değerinin büyük kısmını taşıyor?

**Veri:** `120` sentetik kayıt, alanlar: sku, units, unit_cost.

**Yöntem:** SQLite sorgusu `analysis.sql` dosyasındadır. Python 3 ile `python analizler/stok-abc/run.py` çalıştırın. Önceden çalıştırılmış çıktı `results.json`, tarayıcı raporu `index.html` dosyasındadır.

**Yorumlama sınırı:** ABC sınıfları birikimli stok değerinin %80 ve %95 eşiklerine göre tanımlanır.
