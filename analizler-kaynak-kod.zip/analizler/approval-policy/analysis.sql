-- period_summary
SELECT treated,post,COUNT(DISTINCT unit_id) AS units,COUNT(*) AS observations,ROUND(AVG(outcome),4) AS average FROM observations JOIN units USING(unit_id) GROUP BY treated,post ORDER BY treated,post;

-- daily_panel
SELECT treated,day,ROUND(AVG(outcome),4) AS average FROM observations JOIN units USING(unit_id) GROUP BY treated,day ORDER BY treated,day;