CREATE TABLE units (unit_id INTEGER PRIMARY KEY,treated INTEGER,region TEXT);
CREATE TABLE observations (unit_id INTEGER,day INTEGER,post INTEGER,outcome REAL);