# Tedarikçi zamanında teslim

**Durum:** Tamamlanmış, tekrar üretilebilir sentetik veri analizi. Gerçek işletme verisi değildir.

**Soru:** Teslim performansı hangi tedarikçide düşüyor?

**Veri:** `160` sentetik kayıt, alanlar: supplier, promised_day, actual_day, quantity.

**Yöntem:** SQLite sorgusu `analysis.sql` dosyasındadır. Python 3 ile `python analizler/tedarikci-otd/run.py` çalıştırın. Önceden çalıştırılmış çıktı `results.json`, tarayıcı raporu `index.html` dosyasındadır.

**Yorumlama sınırı:** OTD metriği taahhüt edilen gün veya öncesinde teslim oranıdır.
