SELECT status, COUNT(*) AS belge, ROUND(AVG(duration_min),1) AS ort_dakika, ROUND(100.0*SUM(duration_min>30)/COUNT(*),1) AS sla_asimi_pct FROM data GROUP BY status ORDER BY ort_dakika DESC;
