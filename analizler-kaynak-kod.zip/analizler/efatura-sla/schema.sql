CREATE TABLE documents (doc_id INTEGER PRIMARY KEY,provider TEXT,complexity TEXT,observed_age_min REAL);
CREATE TABLE events (doc_id INTEGER,event TEXT,minute REAL);
CREATE TABLE providers (provider TEXT PRIMARY KEY,assignment_mix TEXT);