# e-Fatura işlem SLA analizi

**Durum:** Tamamlanmış, tekrar üretilebilir sentetik veri analizi. Gerçek işletme verisi değildir.

**Soru:** Entegratör işlem süreleri hangi belge durumlarında uzuyor?

**Veri:** `160` sentetik kayıt, alanlar: status, duration_min, channel.

**Yöntem:** SQLite sorgusu `analysis.sql` dosyasındadır. Python 3 ile `python analizler/efatura-sla/run.py` çalıştırın. Önceden çalıştırılmış çıktı `results.json`, tarayıcı raporu `index.html` dosyasındadır.

**Yorumlama sınırı:** 30 dakika varsayımsal demo SLA eşiğidir; resmî GİB hizmet taahhüdü değildir.
