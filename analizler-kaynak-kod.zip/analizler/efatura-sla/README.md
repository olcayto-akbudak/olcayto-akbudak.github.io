# e-Fatura SLA: sansürlü kayıtlar ve vaka karması

Tamamen sentetik, sabit tohumlu portföy çalışması. Gerçek kurum sonucu değildir.

## Soru
Sağlayıcılar arasındaki SLA farkı performanstan mı, belge karmasından mı kaynaklanıyor?

## Yöntem
- 6.000 belge, olay günlüğü ve sağlayıcı tablosu SQL ile birleştirilir. SLA eşiği sentetik 30 dakikadır.
- Tamamlanan belge gerçek süresiyle; bekleyen belge yaşı 30 dakikayı geçtiyse ihlal olarak değerlendirilir. Yaşı küçük bekleyenler henüz değerlendirilemez.
- Sağlayıcılar basit/karmaşık tabakalarında karşılaştırılır; her tabakaya %50 ağırlık verilerek standartlaştırılır. P95 yalnız tamamlanmış belgeler içindir.

## Bulgular
- Ham ihlal: A %15.49, B %7.71. Eşit karmaşıklık karmasıyla A %10.91, B %17.44.
- Tamamlanmamış 629 belge, tamamlanan süre dağılımına katılmadı; yaşına göre SLA paydasında ayrıca ele alındı.

## Karar
Sağlayıcı seçiminde ham ortalama yerine aynı vaka karmasının ihlal oranını, bekleyen yaşını ve tamamlanan P95’i birlikte takip et.

## Sınırlar
- Atama rastgele değildir; karmaşıklık dışındaki karıştırıcılar ölçülmedi. Standartlaştırma tek başına nedensel kanıt değildir.
- Sentetik 30 dakika bir sağlayıcı taahhüdü veya mevzuat sınırı değildir. Tamamlanan P95 tüm belgelerin P95’i olarak yorumlanamaz.

## Çalıştırma
Python 3.10+; paket kökünde `python run.py --study efatura-sla`. CSV tabloları SQLite içine yüklenir, analysis.sql sorguları çalıştırılır ve results.json ile karşılaştırılır. Simülasyon/model çıktıları için `python build_advanced.py`; bütün çıktılar aynı tohumla yeniden üretilir.

## Kontroller
- Her belge için bir SUBMITTED olayı var
- Tamamlanan ve bekleyen sayısı atanan toplamına eşit
- Ham sıralama ile eşit karmaşıklık ağırlıklı sıralama farklı