SELECT COUNT(*) AS kayit, SUM(tax_id='') AS eksik_vkn, SUM(email='') AS eksik_eposta, SUM(city='') AS eksik_sehir, COUNT(tax_id)-COUNT(DISTINCT NULLIF(tax_id,'')) AS yinelenen_vkn FROM data;
