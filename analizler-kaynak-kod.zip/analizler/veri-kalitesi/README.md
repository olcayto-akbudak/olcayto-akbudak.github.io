# Müşteri ana veri kalitesi

**Durum:** Tamamlanmış, tekrar üretilebilir sentetik veri analizi. Gerçek işletme verisi değildir.

**Soru:** Zorunlu alanların eksik ve mükerrer kayıt oranı nedir?

**Veri:** `160` sentetik kayıt, alanlar: customer_id, tax_id, email, city.

**Yöntem:** SQLite sorgusu `analysis.sql` dosyasındadır. Python 3 ile `python analizler/veri-kalitesi/run.py` çalıştırın. Önceden çalıştırılmış çıktı `results.json`, tarayıcı raporu `index.html` dosyasındadır.

**Yorumlama sınırı:** Boş VKN mükerrer hesabından çıkarılır; eşleşme yalnızca birebir tanımlayıcı üzerindendir.
