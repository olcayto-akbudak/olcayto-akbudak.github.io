CREATE TABLE customers (customer_id INTEGER PRIMARY KEY,prediction_month INTEGER,tenure INTEGER);
CREATE TABLE activity (customer_id INTEGER,month INTEGER,visits INTEGER,tickets INTEGER,decline REAL);
CREATE TABLE labels (customer_id INTEGER PRIMARY KEY,outcome_month INTEGER,churn INTEGER);
CREATE TABLE scores (customer_id INTEGER PRIMARY KEY,prediction_month INTEGER,score REAL,split TEXT);