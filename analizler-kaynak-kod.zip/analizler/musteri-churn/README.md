# Müşteri kaybı: zaman ayrımı ve veri sızıntısı

Tamamen sentetik, sabit tohumlu portföy çalışması. Gerçek kurum sonucu değildir.

## Soru
Gelecek aya ait bilgi kullanmadan müşteri kaybını sıralayabilir ve müdahale eşiğini seçebilir miyiz?

## Yöntem
- 5.400 müşteri tek tahmin kesitinde bulunur. Özellikler yalnız önceki aya aittir; sonuç ayı aktiviteleri CSV’de bulunur ama modele girmez.
- Ay 1–5 eğitim, 6–7 doğrulama, 8–9 dokunulmamış test. Ölçekleme yalnız eğitim verisinde öğrenilir; L2 lojistik model standart kitaplıkla eğitilir.
- FP=1, FN=2 örnek maliyetine göre eşik yalnız doğrulamada seçilir. Testte AUC, Brier, kalibrasyon, ilk %10 hassasiyeti ve 300 müşteri bootstrap AUC aralığı raporlanır.

## Bulgular
- Gelecek ay test AUC 0.784; Brier 0.1538, sabit olasılık baz çizgisi 0.1874.
- İlk %10 müşteri diliminde kayıp oranı %63.33; tüm test kümesinde %24.67. Doğrulamada seçilen eşik 0.3.

## Karar
Riski müşteri listesi önceliklendirmek için kullan; maliyet varsayımlarını iş birimiyle belirle ve müdahale etkisini ayrı bir kontrollü deneyle ölç.

## Sınırlar
- Müşteri kimlikleri dönemler arasında tekrar etmez; gerçek panel verisinde müşteri ve zaman bağımlılığı ayrıca ele alınmalıdır.
- Hedef sentetik bir mekanizmayla üretildi. Tahmin başarısı müdahale etkisini veya gerçek müşteri kaybını önleme yeteneğini kanıtlamaz. FP/FN maliyetleri varsayımsaldır.

## Çalıştırma
Python 3.10+; paket kökünde `python run.py --study musteri-churn`. CSV tabloları SQLite içine yüklenir, analysis.sql sorguları çalıştırılır ve results.json ile karşılaştırılır. Simülasyon/model çıktıları için `python build_advanced.py`; bütün çıktılar aynı tohumla yeniden üretilir.

## Kontroller
- Eğitim, doğrulama ve test kimlikleri ayrık
- Özellik ayı sonuç ayından önce
- AUC ve olasılıklar geçerli
- Test kalibrasyon dilimleri tüm test müşterilerini kapsıyor