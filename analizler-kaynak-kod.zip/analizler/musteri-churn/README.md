# Müşteri kayıp riski

**Durum:** Tamamlanmış, tekrar üretilebilir sentetik veri analizi. Gerçek işletme verisi değildir.

**Soru:** Son kullanım süresi ve şikâyet ile hangi segment riskli?

**Veri:** `160` sentetik kayıt, alanlar: segment, days_inactive, complaints, monthly_value.

**Yöntem:** SQLite sorgusu `analysis.sql` dosyasındadır. Python 3 ile `python analizler/musteri-churn/run.py` çalıştırın. Önceden çalıştırılmış çıktı `results.json`, tarayıcı raporu `index.html` dosyasındadır.

**Yorumlama sınırı:** Kayıp tahmini değildir; >60 gün pasif ve ≥2 şikâyet açıklanabilir risk kuralıdır.
