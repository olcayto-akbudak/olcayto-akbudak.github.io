SELECT segment, COUNT(*) AS musteri, SUM(days_inactive>60 AND complaints>=2) AS yuksek_risk, ROUND(AVG(monthly_value),1) AS ort_deger FROM data GROUP BY segment ORDER BY yuksek_risk DESC;
