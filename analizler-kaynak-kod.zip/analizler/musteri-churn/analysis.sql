-- split_summary
SELECT split,COUNT(*) AS customers,ROUND(AVG(churn),4) AS churn_rate,ROUND(AVG(score),4) AS average_score FROM scores JOIN labels USING(customer_id) GROUP BY split;

-- past_only_feature_sample
SELECT c.customer_id,c.prediction_month,c.tenure,a.visits,a.tickets,a.decline FROM customers c JOIN activity a ON a.customer_id=c.customer_id AND a.month=c.prediction_month-1 ORDER BY c.customer_id LIMIT 10;