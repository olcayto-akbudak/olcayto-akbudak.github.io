# Gözlemlenebilirlik yatırımı seçimi

Tamamen sentetik, sabit tohumlu portföy çalışması. Gerçek kurum sonucu değildir.

## Soru
Izleme bileşeni seçimi bütçe, uygulama saati ve ön koşullar birlikte değişince hangi setle dayanıklı kalır?

## Yöntem
- 12 aday iş için maliyet ve uygulama saati tutulur. Dört değer senaryosu aynı adayların olası iş puanlarını içerir. Üç iş başka bir işin seçilmesine bağımlıdır; bağımlı iş tek başına uygulanamaz.
- 4096 alt kümenin tamamı taranır. Maliyet, saat ve ön koşul kısıtlarını sağlayan kümenin dört senaryodaki toplam değerinin en küçüğü amaç fonksiyonudur. Senaryoların ayrı ayrı en iyi setleri birlikte uygulanabilir tek set sayılmaz.
- Baz bütçenin %80, %100 ve %120 seviyelerinde çözüm yeniden bulunur. Eşit değerlerde düşük maliyet ve sonra küçük maskeyle deterministik seçim yapılır. Kaynak artışının marjinal kazanımı bu taramadan değerlendirilir.
- Ortalama değer / maliyet oranına dayalı açgözlü kural aynı saat ve bağımlılık kısıtlarıyla uygulanır. Tam arama sonucu ile fark, basit sıralamanın dayanıklı amaç için kaçırdığı değeri gösterir.
- Birim kimliği, ilişki anahtarı ve satır düzeyi veri sözleşmesinde açıkça tutulur. SQL önce analiz birimini oluşturur; çoklu tablo satırları bağımsız gözlem gibi sayılmaz. Eksik sonuç ve gerçek sıfır aynı anlama gelmez.
- Sonuçlar sabit tohumlu sentetik senaryodan hesaplanır. Kaynak CSV, şema, SQL sorgusu, parametreler ve tam çıktılar aynı pakette bulunur; yeniden üretim karşılaştırması sayfa metnindeki rakamların kaynakla tutarlılığını denetler.

## Bulgular
- Baz bütçede tam arama en kötü senaryo değerini 296.609 yaptı. Seçilen işler: 1,4,5,6,7,9. Maliyet 103/107, saat 52/73.
- Açgözlü seçim değeri 255.549; tam arama farkı 41.060. Bütçe duyarlılığı farklı uygulanabilir kümeleri gösterir.

## Karar
Log ve metrik bağımlılıklarını bütçede koru. Önce küçük kapsamlı bir pilot uygula; baz çizgiyle aynı analiz biriminde karşılaştır. Etki, belirsizlik ve yan etki ölçütlerini ayrı izle. Başarı eşiği ihlal edilirse yayılımı durdur ve veri kalitesi ile varsayımları yeniden değerlendir.

## Sınırlar
- Min-max yaklaşımı senaryoların tamamını eşit olasılıklı saymaz; en kötü değeri korumayı seçer. Senaryo kapsamı yetersizse dayanıklılık yanıltıcı olabilir.
- Değer puanları sentetiktir ve para getirisi değildir. Kaynak miktarı, iş sinerjileri ve senaryo içindeki bağımlılıklar gerçek planlama için ayrıca kalibre edilmelidir. Tam arama bu küçük aday havuzu içindir.
- İzleme kapsamı olay önleme garantisi değildir.
- Bu çalışma üretime hazır bir karar sistemi değildir. Pilot öncesinde veri sahibi, iş birimi ve teknik ekip ölçüm tanımını, yanlış karar maliyetini ve geri dönüş koşulunu birlikte belirlemelidir.

## Çalıştırma
Python 3.10+; paket kökünde `python run.py --study observability-rollout`. CSV tabloları SQLite içine yüklenir, analysis.sql sorguları çalıştırılır ve results.json ile karşılaştırılır. Simülasyon/model çıktıları için `python build_expansion.py`; bütün çıktılar aynı tohumla yeniden üretilir.

## Kontroller
- Tam arama bütün alt kümeleri kapsıyor
- Seçili setler bütçe, saat ve bağımlılığı koruyor
- Bütçe büyüyünce optimum değer azalmaz
- Tam arama aynı kısıtta açgözlüden kötü değil

## Veri sözleşmesi
`contract.json` analiz birimi, kolon tipleri, satır sayıları ve sabit tohumu kaydeder. SQL SQLite sözdizimindedir. Takvim ve oran eşikleri bu sentetik senaryonun varsayımlarıdır.
