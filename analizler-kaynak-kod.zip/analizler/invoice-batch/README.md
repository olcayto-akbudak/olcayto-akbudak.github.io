# Fatura batch boyutu müdahalesi

Tamamen sentetik, sabit tohumlu portföy çalışması. Gerçek kurum sonucu değildir.

## Soru
Kuyruk bekleme süresi değişimi ortak dönem etkisi ve müdahale öncesi trendden ayrılabiliyor mu?

## Yöntem
- 48 analiz biriminin 40 günlük paneli oluşturulur. İlk 20 gün müdahale öncesi, sonraki 20 gün sonrasıdır. Müdahale ve kontrol grupları 24’er birim içerir; ortak günlük şok ve birime özgü seviyeler vardır.
- Tahmin müdahale grubunun önce/sonra farkından kontrol grubunun farkını çıkarır. Ham grup seviyeleri etki olarak yorumlanmaz. Günlük gözlemler aynı birimde bağımlı olduğundan belirsizlik birim düzeyinde hesaplanır.
- 250 bootstrap tekrarında birimlerin tüm zaman farkı birlikte çekilir. Ön dönemin iki yarısı arasında placebo farkı ve günlük trend tablosu hesaplanır; ön dönem sapması paralel trend varsayımı için uyarıdır.
- Bu senaryoda müdahale grubuna günlük 0.018 ek trend verilmiştir. Trend duyarlılığı, gün başına 0–0,06 olası fark için 20 günlük ortalama dönem uzaklığını kullanır. Bilinen sentetik müdahale katsayısı değerlendirme için ayrıca gösterilir.
- Birim kimliği, ilişki anahtarı ve satır düzeyi veri sözleşmesinde açıkça tutulur. SQL önce analiz birimini oluşturur; çoklu tablo satırları bağımsız gözlem gibi sayılmaz. Eksik sonuç ve gerçek sıfır aynı anlama gelmez.
- Sonuçlar sabit tohumlu sentetik senaryodan hesaplanır. Kaynak CSV, şema, SQL sorgusu, parametreler ve tam çıktılar aynı pakette bulunur; yeniden üretim karşılaştırması sayfa metnindeki rakamların kaynakla tutarlılığını denetler.

## Bulgular
- Farkların farkı -1.1057; birim bootstrap %95 aralığı -1.2227–-0.9945. Ön dönem placebo farkı 0.1115.
- Sentetik müdahale katsayısı -1.4100, gruba özgü trend 0.018. Tahminin doğru işareti veya dar aralığı, trend varsayımındaki hatayı ortadan kaldırmaz.

## Karar
Batch değişimini kontrol tenantlarıyla karşılaştır. Önce küçük kapsamlı bir pilot uygula; baz çizgiyle aynı analiz biriminde karşılaştır. Etki, belirsizlik ve yan etki ölçütlerini ayrı izle. Başarı eşiği ihlal edilirse yayılımı durdur ve veri kalitesi ile varsayımları yeniden değerlendir.

## Sınırlar
- Paralel trend yoksa farkların farkı nedensel etki değildir. Bu çalışma varsayım ihlalini görünür kılar; placebo küçük çıksa bile varsayım kanıtlanmış olmaz.
- Birimler arasında yayılım, müdahale zamanındaki seçilim ve eşzamanlı başka değişimler modele dahil değildir. Metrik sentetik süre birimidir; gerçek kurumdaki zaman ölçümü ayrıca tanımlanmalıdır.
- Ortak sağlayıcı kesintisi paralel trendi bozabilir.
- Bu çalışma üretime hazır bir karar sistemi değildir. Pilot öncesinde veri sahibi, iş birimi ve teknik ekip ölçüm tanımını, yanlış karar maliyetini ve geri dönüş koşulunu birlikte belirlemelidir.

## Çalıştırma
Python 3.10+; paket kökünde `python run.py --study invoice-batch`. CSV tabloları SQLite içine yüklenir, analysis.sql sorguları çalıştırılır ve results.json ile karşılaştırılır. Simülasyon/model çıktıları için `python build_expansion.py`; bütün çıktılar aynı tohumla yeniden üretilir.

## Kontroller
- Her birimde tam zaman paneli var
- Gruplar dengeli
- Ön ve son dönem ayrımı tutarlı
- Bootstrap aralığı sıralı

## Veri sözleşmesi
`contract.json` analiz birimi, kolon tipleri, satır sayıları ve sabit tohumu kaydeder. SQL SQLite sözdizimindedir. Takvim ve oran eşikleri bu sentetik senaryonun varsayımlarıdır.
