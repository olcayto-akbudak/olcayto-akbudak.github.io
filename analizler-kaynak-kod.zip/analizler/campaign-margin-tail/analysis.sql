-- net_loss_summary
SELECT policy,COUNT(*) AS scenarios,ROUND(AVG(net_loss),3) AS mean_loss,MAX(net_loss) AS maximum_loss FROM totals GROUP BY policy ORDER BY policy;

-- shock_summary
SELECT policy,common_shock,COUNT(*) AS scenarios,ROUND(AVG(net_loss),3) AS mean_loss FROM totals JOIN scenarios USING(scenario_id) GROUP BY policy,common_shock ORDER BY policy,common_shock;