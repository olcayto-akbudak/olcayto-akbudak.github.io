CREATE TABLE assets (asset_id INTEGER PRIMARY KEY,exposure INTEGER,event_probability REAL);
CREATE TABLE scenarios (scenario_id INTEGER PRIMARY KEY,common_shock INTEGER);
CREATE TABLE losses (scenario_id INTEGER,asset_id INTEGER,policy TEXT,gross_loss INTEGER);
CREATE TABLE totals (scenario_id INTEGER,policy TEXT,net_loss INTEGER);