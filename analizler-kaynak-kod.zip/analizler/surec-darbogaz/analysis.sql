SELECT stage, COUNT(*) AS adim, SUM(duration_min) AS toplam_dakika, ROUND(AVG(duration_min),1) AS ort_dakika, SUM(reworked) AS tekrar_is FROM data GROUP BY stage ORDER BY toplam_dakika DESC;
