# Onay süreci darboğazı

**Durum:** Tamamlanmış, tekrar üretilebilir sentetik veri analizi. Gerçek işletme verisi değildir.

**Soru:** İş akışının hangi aşaması toplam sürenin çoğunu tüketiyor?

**Veri:** `160` sentetik kayıt, alanlar: stage, duration_min, reworked.

**Yöntem:** SQLite sorgusu `analysis.sql` dosyasındadır. Python 3 ile `python analizler/surec-darbogaz/run.py` çalıştırın. Önceden çalıştırılmış çıktı `results.json`, tarayıcı raporu `index.html` dosyasındadır.

**Yorumlama sınırı:** Aşama örnekleri farklı işlem sayıları içerebilir; toplam ve ortalama birlikte değerlendirilir.
