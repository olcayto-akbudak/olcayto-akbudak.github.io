CREATE TABLE units (unit_id INTEGER PRIMARY KEY,segment TEXT,latent_risk REAL);
CREATE TABLE outcomes (unit_id INTEGER,policy TEXT,adverse INTEGER);