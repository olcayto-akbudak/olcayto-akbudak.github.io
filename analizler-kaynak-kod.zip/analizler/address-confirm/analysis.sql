-- policy_summary
SELECT policy,COUNT(*) AS units,SUM(adverse) AS adverse_events,ROUND(100.0*AVG(adverse),3) AS adverse_pct FROM outcomes GROUP BY policy ORDER BY policy;

-- segment_summary
SELECT policy,segment,COUNT(*) AS units,SUM(adverse) AS adverse_events,ROUND(100.0*AVG(adverse),3) AS adverse_pct FROM outcomes JOIN units USING(unit_id) GROUP BY policy,segment ORDER BY policy,segment;