SELECT category, COUNT(*) AS satis, SUM(returned) AS iade, ROUND(100.0*SUM(returned)/COUNT(*),1) AS iade_pct FROM data GROUP BY category ORDER BY iade_pct DESC;
