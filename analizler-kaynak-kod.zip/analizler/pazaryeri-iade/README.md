# Pazaryeri iade nedenleri

**Durum:** Tamamlanmış, tekrar üretilebilir sentetik veri analizi. Gerçek işletme verisi değildir.

**Soru:** Hangi kategori ve nedenlerde iade oranı artıyor?

**Veri:** `160` sentetik kayıt, alanlar: category, reason, returned.

**Yöntem:** SQLite sorgusu `analysis.sql` dosyasındadır. Python 3 ile `python analizler/pazaryeri-iade/run.py` çalıştırın. Önceden çalıştırılmış çıktı `results.json`, tarayıcı raporu `index.html` dosyasındadır.

**Yorumlama sınırı:** İade nedeni yalnızca örnek amaçlıdır; oran kategori bazında hesaplanır.
