# Kampanya A/B testi

**Durum:** Tamamlanmış, tekrar üretilebilir sentetik veri analizi. Gerçek işletme verisi değildir.

**Soru:** Deneme gruplarının dönüşüm oranları nasıl değişiyor?

**Veri:** `400` sentetik kayıt, alanlar: variant, converted, revenue.

**Yöntem:** SQLite sorgusu `analysis.sql` dosyasındadır. Python 3 ile `python analizler/kampanya-ab/run.py` çalıştırın. Önceden çalıştırılmış çıktı `results.json`, tarayıcı raporu `index.html` dosyasındadır.

**Yorumlama sınırı:** Gruplar rastgele sentetik üretilir; oran farkı istatistiksel anlamlılık veya nedensellik kanıtı değildir.
