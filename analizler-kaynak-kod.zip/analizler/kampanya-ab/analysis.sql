SELECT variant, COUNT(*) AS ziyaretci, SUM(converted) AS donusum, ROUND(100.0*AVG(converted),2) AS donusum_pct, SUM(revenue) AS gelir FROM data GROUP BY variant ORDER BY variant;
