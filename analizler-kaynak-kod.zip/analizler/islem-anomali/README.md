# İşlem tutarı aykırı değer

**Durum:** Tamamlanmış, tekrar üretilebilir sentetik veri analizi. Gerçek işletme verisi değildir.

**Soru:** Üç sigma eşiğini aşan işlemler hangi kanalda?

**Veri:** `160` sentetik kayıt, alanlar: channel, amount.

**Yöntem:** SQLite sorgusu `analysis.sql` dosyasındadır. Python 3 ile `python analizler/islem-anomali/run.py` çalıştırın. Önceden çalıştırılmış çıktı `results.json`, tarayıcı raporu `index.html` dosyasındadır.

**Yorumlama sınırı:** Yüksek tutarlar sentetik olarak eklenmiştir; üç sigma işareti dolandırıcılık kanıtı değildir.
