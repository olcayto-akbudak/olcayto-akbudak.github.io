# e-Fatura tekrar gönderim: eşlenmiş politika deneyi

Tamamen sentetik, sabit tohumlu portföy çalışması. Gerçek kurum sonucu değildir.

## Soru
Aynı yanıt kaybı olaylarında UUID koruması mükerrer belge riskini ne kadar değiştiriyor?

## Yöntem
- Aynı 4.000 belge ve aynı sağlayıcı kabul/yanıt kaybı olayları iki politika altında yeniden oynatılır.
- Yerel gönderim denemesi ile sağlayıcıdaki iş etkisi ayrı tablolarda tutulur. Yanıt kaybı kabul edilen işin geri alınması değildir.
- Sağlayıcı etkileri belge/politika seviyesinde önce gruplanır; rapor birleştirmesi bu düzeyde yapılır.

## Bulgular
- Aynı koşullarda 908 ek sağlayıcı belgesi önlendi; her 1.000 belge başına 227.0 mükerrer iş etkisi.
- İki politikada ilk gönderim sonuçları aynıdır; fark yalnız tekrarın engellenmesinden gelir.

## Karar
Timeout sonrası aynı UUID ile otomatik yeniden belge üretme; kalıcı tekillik kontrolünü ve sağlayıcı sorgusuyla mutabakatı kabul ölçütüne dönüştür.

## Sınırlar
- Koruma ideal, kalıcı ve atomik varsayılır. Gerçek dağıtık yarışlar, anahtar süresi ve içerik özeti çakışması bu modelde yoktur.
- Sentetik karşı-olgusal deney gerçek işletme etki tahmini değildir.

## Çalıştırma
Python 3.10+; paket kökünde `python run.py --study idempotency-risk`. CSV tabloları SQLite içine yüklenir, analysis.sql sorguları çalıştırılır ve results.json ile karşılaştırılır. Simülasyon/model çıktıları için `python build_advanced.py`; bütün çıktılar aynı tohumla yeniden üretilir.

## Kontroller
- Korumalı politikada işlenmiş belge başına en fazla bir etki
- Politikalar aynı temel belgelere uygulanmış
- Önlenen etkiler yanıt kayıplarına eşit