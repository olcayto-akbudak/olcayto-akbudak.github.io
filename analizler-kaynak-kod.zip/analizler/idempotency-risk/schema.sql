CREATE TABLE documents (doc_id INTEGER PRIMARY KEY,accepted INTEGER,response_lost INTEGER);
CREATE TABLE attempts (attempt_id INTEGER PRIMARY KEY,doc_id INTEGER,policy TEXT,ordinal INTEGER,blocked INTEGER,transport_result TEXT);
CREATE TABLE provider_effects (attempt_id INTEGER PRIMARY KEY,doc_id INTEGER,policy TEXT);