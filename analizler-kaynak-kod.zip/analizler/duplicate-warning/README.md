# Cari kart mükerrer uyarısı deneyi

Tamamen sentetik, sabit tohumlu portföy çalışması. Gerçek kurum sonucu değildir.

## Soru
Mükerrer kayıt oranı için aday kontrolün etkisi segment ve kontrol maliyeti değişince hâlâ anlamlı mı?

## Yöntem
- Analiz birimi bağımsız işlem örneğidir. 1080 işlem, normal ve yoğun segmentte aynı rastgele olay çekilişiyle iki politikada eşlenir. Temel olay olasılığı 0.143, aday azaltım katsayısı 0.38; bunlar veri üretim varsayımıdır.
- Birim başına olumsuz sonuç 0/1 olarak tutulur. Etki baz çizgi eksi aday politika şeklindedir; pozitif değer daha az olumsuz olay anlamına gelir. Segment ve toplam oranlar ayrı raporlanır.
- 250 bootstrap tekrarında politika satırları ayrı çekilmez; iki sonuç aynı birimle birlikte yeniden örneklenir. Yüzdelik aralık eşlenmiş ortalama farkın belirsizliğini gösterir.
- Kontrol maliyeti her işleme uygulanır. Net örnek değer = önlenen olay × varsayımsal olay maliyeti − işlem sayısı × kontrol maliyeti. Farklı maliyet çiftleri tek bir olumlu senaryoya bağımlılığı gösterir.
- Birim kimliği, ilişki anahtarı ve satır düzeyi veri sözleşmesinde açıkça tutulur. SQL önce analiz birimini oluşturur; çoklu tablo satırları bağımsız gözlem gibi sayılmaz. Eksik sonuç ve gerçek sıfır aynı anlama gelmez.
- Sonuçlar sabit tohumlu sentetik senaryodan hesaplanır. Kaynak CSV, şema, SQL sorgusu, parametreler ve tam çıktılar aynı pakette bulunur; yeniden üretim karşılaştırması sayfa metnindeki rakamların kaynakla tutarlılığını denetler.

## Bulgular
- 1080 eşlenmiş işlemde 64 olumsuz olay önlendi. Azalma 5.926 yüzde puan; %95 bootstrap aralığı 4.54–7.2 yüzde puan.
- Maliyet duyarlılığında net değer -5440 ile 50660.0 arasında değişiyor. Olay azalması tek başına ekonomik onay gerekçesi değildir.

## Karar
Uyarı eşiğini işlem süresiyle birlikte değerlendir. Önce küçük kapsamlı bir pilot uygula; baz çizgiyle aynı analiz biriminde karşılaştır. Etki, belirsizlik ve yan etki ölçütlerini ayrı izle. Başarı eşiği ihlal edilirse yayılımı durdur ve veri kalitesi ile varsayımları yeniden değerlendir.

## Sınırlar
- Aday politikanın faydası veri üretim mekanizmasında varsayılmıştır. Bu eşlenmiş simülasyon gerçek rastgele kontrollü deneyin yerine geçmez. Gerçek uygulamada kullanıcı, gün veya tenant bazında kümelenme değerlendirilmelidir.
- Gizli risk kolonu yalnız sentetik üretim açıklaması içindir; üretimde gözlenebilir özellik veya karar girdisi olarak kullanılamaz.
- Kullanıcının uyarıyı geçme davranışı varsayımsaldır.
- Bu çalışma üretime hazır bir karar sistemi değildir. Pilot öncesinde veri sahibi, iş birimi ve teknik ekip ölçüm tanımını, yanlış karar maliyetini ve geri dönüş koşulunu birlikte belirlemelidir.

## Çalıştırma
Python 3.10+; paket kökünde `python run.py --study duplicate-warning`. CSV tabloları SQLite içine yüklenir, analysis.sql sorguları çalıştırılır ve results.json ile karşılaştırılır. Simülasyon/model çıktıları için `python build_expansion.py`; bütün çıktılar aynı tohumla yeniden üretilir.

## Kontroller
- Her birim iki politikada bir kez bulunur
- Önlenen olay doğrudan politika toplamı farkına eşit
- Eşlenmiş fark ve bootstrap aralığı geçerli

## Veri sözleşmesi
`contract.json` analiz birimi, kolon tipleri, satır sayıları ve sabit tohumu kaydeder. SQL SQLite sözdizimindedir. Takvim ve oran eşikleri bu sentetik senaryonun varsayımlarıdır.
