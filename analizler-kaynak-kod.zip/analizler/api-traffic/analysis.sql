-- forecast_summary
SELECT model,COUNT(*) AS predictions,ROUND(AVG(abs_error),4) AS mae,ROUND(100.0*SUM(abs_error)/NULLIF(SUM(actual),0),4) AS wape_pct,ROUND(AVG(forecast-actual),4) AS bias FROM predictions GROUP BY model ORDER BY model;

-- series_errors
SELECT model,series_id,ROUND(AVG(abs_error),4) AS mae,ROUND(100.0*SUM(abs_error)/NULLIF(SUM(actual),0),4) AS wape_pct FROM predictions GROUP BY model,series_id ORDER BY model,series_id;