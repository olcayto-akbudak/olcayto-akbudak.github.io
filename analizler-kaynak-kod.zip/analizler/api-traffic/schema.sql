CREATE TABLE series (series_id INTEGER PRIMARY KEY,segment TEXT);
CREATE TABLE observations (series_id INTEGER,day INTEGER,volume INTEGER);
CREATE TABLE predictions (series_id INTEGER,day INTEGER,model TEXT,actual INTEGER,forecast REAL,abs_error REAL);