# P2P süreç madenciliği: tekrar işleme ve bekleme

Tamamen sentetik, sabit tohumlu portföy çalışması. Gerçek kurum sonucu değildir.

## Soru
Ödeme süresini hangi aşama uzatıyor; tekrar işleme etkisi öncelik farkından ayrılabiliyor mu?

## Yöntem
- 3.000 vaka ve sıralı olay tablosu. LAG pencere fonksiyonu ile her aktiviteye kadar geçen süre hesaplanır.
- Birden fazla INVOICE_RECEIVED olayı tekrar işleme işaretidir. Vaka süresi ilk PO_CREATED ile PAID arasıdır; olay satırları bağımsız vaka gibi sayılmaz.
- Acil/normal tabakalarında tekrar işleme farkı, vaka bazında 300 bootstrap örnekle %95 aralıkla raporlanır.

## Bulgular
- 16,653 olay, 3.000 vaka seviyesine indirgendi; tekrar işleme 551 vakada bulundu.
- Tabaka içi süre farkı: acil 49.73 saat, normal 47.58 saat.

## Karar
Aktivite beklemelerini vaka seviyesinde ölç; tekrar işleme kuyruğunu öncelik ve şube tabakalarında incele, nedensellik için ayrıca kontrollü müdahale tasarla.

## Sınırlar
- Bootstrap vakaların bağımsız olduğunu varsayar; aynı tedarikçiye bağlı kümelenme modellenmedi.
- Tekrar işleme gözlemsel bir sınıftır. Süre farkı nedensel maliyet veya kontrol ihlali kanıtı değildir.

## Çalıştırma
Python 3.10+; paket kökünde `python run.py --study p2p-rework`. CSV tabloları SQLite içine yüklenir, analysis.sql sorguları çalıştırılır ve results.json ile karşılaştırılır. Simülasyon/model çıktıları için `python build_advanced.py`; bütün çıktılar aynı tohumla yeniden üretilir.

## Kontroller
- Her vaka tek başlangıç ve ödeme olayı içeriyor
- Olay zamanı vaka içinde monoton
- Bootstrap aralıkları sıralı