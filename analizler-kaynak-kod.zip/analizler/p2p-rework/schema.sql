CREATE TABLE cases (case_id INTEGER PRIMARY KEY,branch TEXT,priority TEXT);
CREATE TABLE events (case_id INTEGER,event_id INTEGER PRIMARY KEY,activity TEXT,hour REAL);