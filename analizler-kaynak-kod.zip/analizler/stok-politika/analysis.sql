-- policy_totals
SELECT policy,COUNT(*) AS skus,SUM(requested) AS requested,SUM(filled) AS filled,SUM(lost) AS lost,ROUND(100.0*SUM(filled)/SUM(requested),2) AS fill_rate_pct,ROUND(SUM(holding_try),2) AS holding_try,SUM(orders) AS orders FROM outcomes GROUP BY policy;

-- paired_sku_tradeoff
WITH p AS (SELECT sku,MAX(CASE WHEN policy='Ortalama talep' THEN lost END) AS base_lost,MAX(CASE WHEN policy='Servis tamponu' THEN lost END) AS buffer_lost,MAX(CASE WHEN policy='Ortalama talep' THEN holding_try END) AS base_holding,MAX(CASE WHEN policy='Servis tamponu' THEN holding_try END) AS buffer_holding FROM outcomes GROUP BY sku) SELECT sku,base_lost-buffer_lost AS saved_units,ROUND(buffer_holding-base_holding,2) AS extra_holding_try FROM p ORDER BY saved_units DESC LIMIT 12;