CREATE TABLE skus (sku INTEGER PRIMARY KEY,unit_cost_try INTEGER);
CREATE TABLE demand (sku INTEGER,day INTEGER,units INTEGER);
CREATE TABLE lead_time (sku INTEGER,day INTEGER,days INTEGER);
CREATE TABLE daily_inventory (policy TEXT,sku INTEGER,day INTEGER,requested INTEGER,filled INTEGER,ending_stock INTEGER,order_units INTEGER);
CREATE TABLE outcomes (policy TEXT,sku INTEGER,requested INTEGER,filled INTEGER,lost INTEGER,holding_try REAL,orders INTEGER);