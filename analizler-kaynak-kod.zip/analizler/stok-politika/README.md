# Stok politikası: kesikli talep ve ileri dönem testi

Tamamen sentetik, sabit tohumlu portföy çalışması. Gerçek kurum sonucu değildir.

## Soru
Servis tamponu kayıp talebi azaltırken ne kadar ek stok maliyeti yaratıyor?

## Yöntem
- 60 ürünün 180 günlük sıfır ağırlıklı talebi ve sipariş anında bilinen değişken tedarik süreleri. İlk 120 gün başlangıç hesabı, sonraki 60 gün ileri dönem testidir.
- İki politika aynı talep ve tedarik süresi yolunu kullanır. Günlük giriş, talep, stok, açık sipariş ve stok pozisyonu izlenir. Kayıp talep geri siparişe çevrilmez.
- 60 günlük kayan tahmin yalnız o güne kadar açığa çıkan veriyi kullanır. Servis tamponu talep ve tedarik süresi varyansını içerir; 1,65 katsayısı yalnız aday politikadır, garanti değildir.
- Servis farkı ürün bazında eşlenir; 300 ürün bootstrap ile ortalama kazanım aralığı. Elde tutma maliyeti günlük stok × birim maliyet × 0,0005 varsayımıdır.

## Bulgular
- Aynı talep yollarında ürün başına ortalama 9.85 kayıp talep birimi önlendi; %95 bootstrap aralığı 7.69–12.21.
- Kazanç ve ilave elde tutma maliyeti birlikte verilir; daha çok stok her ürün için aynı faydayı yaratmaz.

## Karar
Tek bir servis hedefini tüm ürünlere uygulama; ürün bazında kayıp talep kazanımını, ilave stok maliyetini ve iş marjını karşılaştırarak pilot kapsamını seç.

## Sınırlar
- Her ürün için tek sentetik talep yolu vardır; bootstrap ürün karması belirsizliğini gösterir, alternatif gelecek senaryolarının tamamını temsil etmez.
- Başlangıç stoğu politikalara göre farklıdır; sonuç toplam politika karşılaştırmasıdır. Satın alma nakdi, sipariş sabit maliyeti ve kayıp satış marjı modele dahil değildir.
- Tedarik süreleri sipariş anında doğru biliniyor varsayılır; gecikme sürprizi yoktur. Süre örnekleri bağımsızdır; sezon, ortak tedarikçi kesintisi ve kapasite sınırı modellenmez.

## Çalıştırma
Python 3.10+; paket kökünde `python run.py --study stok-politika`. CSV tabloları SQLite içine yüklenir, analysis.sql sorguları çalıştırılır ve results.json ile karşılaştırılır. Simülasyon/model çıktıları için `python build_advanced.py`; bütün çıktılar aynı tohumla yeniden üretilir.

## Kontroller
- Karşılaştırmada talep yolu aynı
- Talep karşılanan ve kayıp miktara eşit
- Negatif stok veya fazla karşılama yok
- Test dönemi gün 121–180