# Sevkiyat adedi ileri dönem testi

Tamamen sentetik, sabit tohumlu portföy çalışması. Gerçek kurum sonucu değildir.

## Soru
Sevk hacminde doğrulamada seçilen tahmin modeli gelecek dönemde basit haftalık baz çizgiyi geçiyor mu?

## Yöntem
- Altı serinin 180 günlük hacmi üretilir; haftalık desen, seri seviyesi, gürültü ve bazı senaryolarda sıfır günler vardır. Gün 130 sonrası düzey değişimi veri üretiminde kullanılır, tahmin modeline gelecek bilgisi olarak verilmez.
- Gün 1–90 başlangıç geçmişi, 91–120 doğrulama, 121–180 ileri dönem testidir. Mevsim ortalaması için 2, 4, 8 haftalık pencereler yalnız doğrulama MAE ile seçilir; testte yeniden model seçimi yapılmaz.
- Her test gününde yalnız önceki günlere ait gerçekleşmeler kullanılır. Önceki test gününün ortaya çıkmış verisi sonraki tahminde kullanılabilir; bu kayan başlangıç değerlendirmesidir, sabit başlangıçtan 60 gün tahmini değildir.
- Haftalık naive baz çizgi geçen haftanın aynı gününü kullanır. MAE, toplam mutlak hatanın toplam gerçekleşmeye bölündüğü WAPE ve imzalı sapma birlikte ölçülür. Sıfır gözlemler yüzdesel tekil hata hesabıyla atılmaz.
- Birim kimliği, ilişki anahtarı ve satır düzeyi veri sözleşmesinde açıkça tutulur. SQL önce analiz birimini oluşturur; çoklu tablo satırları bağımsız gözlem gibi sayılmaz. Eksik sonuç ve gerçek sıfır aynı anlama gelmez.
- Sonuçlar sabit tohumlu sentetik senaryodan hesaplanır. Kaynak CSV, şema, SQL sorgusu, parametreler ve tam çıktılar aynı pakette bulunur; yeniden üretim karşılaştırması sayfa metnindeki rakamların kaynakla tutarlılığını denetler.

## Bulgular
- İleri dönem testinde mevsim ortalaması WAPE %34.66; haftalık naive %35.9515. MAE sırasıyla 19.6243 ve 20.3556.
- Pencere seçimi seri başına doğrulamada yapıldı: 8, 8, 8, 4, 8, 8 hafta. Baz çizgiye üstünlük her senaryoda garanti edilmez.

## Karar
Yükleme planını haftalık naive baz çizgisine karşı ölç. Önce küçük kapsamlı bir pilot uygula; baz çizgiyle aynı analiz biriminde karşılaştır. Etki, belirsizlik ve yan etki ölçütlerini ayrı izle. Başarı eşiği ihlal edilirse yayılımı durdur ve veri kalitesi ile varsayımları yeniden değerlendir.

## Sınırlar
- Sentetik dönem değişimi ve gürültü gerçek talebi temsil etmez. Hacim tahmininin iyi olması kapasite veya personel kararının optimal olduğu anlamına gelmez.
- Seriler bağımsız üretilmiştir; ortak müşteri, kampanya ve tatil etkileri yoktur. Gerçek kullanımda sezon dışı test, veri kayması ve tahmin belirsizliği ayrıca değerlendirilmelidir.
- Ağırlık ve güzergah bazlı kapasite yoktur.
- Bu çalışma üretime hazır bir karar sistemi değildir. Pilot öncesinde veri sahibi, iş birimi ve teknik ekip ölçüm tanımını, yanlış karar maliyetini ve geri dönüş koşulunu birlikte belirlemelidir.

## Çalıştırma
Python 3.10+; paket kökünde `python run.py --study shipment-count`. CSV tabloları SQLite içine yüklenir, analysis.sql sorguları çalıştırılır ve results.json ile karşılaştırılır. Simülasyon/model çıktıları için `python build_expansion.py`; bütün çıktılar aynı tohumla yeniden üretilir.

## Kontroller
- İleri dönem test günleri korunuyor
- Her model aynı gerçekleşmeleri kullanıyor
- Tahminler ve mutlak hatalar geçerli
- Pencere yalnız doğrulama aralığında seçiliyor

## Veri sözleşmesi
`contract.json` analiz birimi, kolon tipleri, satır sayıları ve sabit tohumu kaydeder. SQL SQLite sözdizimindedir. Takvim ve oran eşikleri bu sentetik senaryonun varsayımlarıdır.
