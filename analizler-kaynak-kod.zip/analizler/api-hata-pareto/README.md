# API hata Pareto analizi

**Durum:** Tamamlanmış, tekrar üretilebilir sentetik veri analizi. Gerçek işletme verisi değildir.

**Soru:** Hata yükünün çoğunu hangi uç noktalar oluşturuyor?

**Veri:** `160` sentetik kayıt, alanlar: endpoint, http_status, latency_ms.

**Yöntem:** SQLite sorgusu `analysis.sql` dosyasındadır. Python 3 ile `python analizler/api-hata-pareto/run.py` çalıştırın. Önceden çalıştırılmış çıktı `results.json`, tarayıcı raporu `index.html` dosyasındadır.

**Yorumlama sınırı:** HTTP 4xx/5xx hata kabul edilir; uç nokta ağırlıkları sentetiktir.
