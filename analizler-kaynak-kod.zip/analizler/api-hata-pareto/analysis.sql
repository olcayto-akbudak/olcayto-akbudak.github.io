SELECT endpoint, COUNT(*) AS istek, SUM(http_status>=400) AS hata, ROUND(100.0*SUM(http_status>=400)/COUNT(*),1) AS hata_orani_pct FROM data GROUP BY endpoint ORDER BY hata DESC;
