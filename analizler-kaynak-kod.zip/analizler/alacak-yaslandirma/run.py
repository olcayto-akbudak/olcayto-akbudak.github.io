"""Run this case study with Python 3 standard library only."""
import csv, json, sqlite3
from pathlib import Path
p=Path(__file__).parent
with (p/'data.csv').open(encoding='utf-8', newline='') as f:
    reader=csv.DictReader(f); rows=list(reader); columns=reader.fieldnames
conn=sqlite3.connect(':memory:')
conn.execute('CREATE TABLE data ('+', '.join('"'+c+'" '+('REAL' if all(row[c].replace('.','',1).replace('-','',1).isdigit() for row in rows) else 'TEXT') for c in columns)+')')
conn.executemany('INSERT INTO data VALUES ('+','.join('?' for _ in columns)+')',[[row[c] for c in columns] for row in rows])
result=conn.execute((p/'analysis.sql').read_text(encoding='utf-8')).fetchall()
headers=[x[0] for x in conn.execute((p/'analysis.sql').read_text(encoding='utf-8')).description]
print(json.dumps({'source_rows':len(rows),'columns':headers,'results':[dict(zip(headers,row)) for row in result]},ensure_ascii=False,indent=2))
