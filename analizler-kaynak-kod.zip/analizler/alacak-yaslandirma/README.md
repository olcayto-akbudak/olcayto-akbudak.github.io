# Alacak yaşlandırma analizi

**Durum:** Tamamlanmış, tekrar üretilebilir sentetik veri analizi. Gerçek işletme verisi değildir.

**Soru:** Vadesi geçen alacak hangi yaş aralıklarında birikiyor?

**Veri:** `160` sentetik kayıt, alanlar: customer_segment, days_overdue, balance.

**Yöntem:** SQLite sorgusu `analysis.sql` dosyasındadır. Python 3 ile `python analizler/alacak-yaslandirma/run.py` çalıştırın. Önceden çalıştırılmış çıktı `results.json`, tarayıcı raporu `index.html` dosyasındadır.

**Yorumlama sınırı:** Bakiye ve gecikme simüle edilmiştir; finansal karar amacıyla kullanılmaz.
