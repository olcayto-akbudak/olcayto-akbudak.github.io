# e-İrsaliye gecikme analizi

**Durum:** Tamamlanmış, tekrar üretilebilir sentetik veri analizi. Gerçek işletme verisi değildir.

**Soru:** Hangi sevkiyat bölgelerinde belge gecikmesi yoğunlaşıyor?

**Veri:** `160` sentetik kayıt, alanlar: region, delay_min, carrier.

**Yöntem:** SQLite sorgusu `analysis.sql` dosyasındadır. Python 3 ile `python analizler/eirsaliye-gecikme/run.py` çalıştırın. Önceden çalıştırılmış çıktı `results.json`, tarayıcı raporu `index.html` dosyasındadır.

**Yorumlama sınırı:** Gecikme, oluşturma ve teslim kaydı arasındaki simüle edilmiş farktır.
