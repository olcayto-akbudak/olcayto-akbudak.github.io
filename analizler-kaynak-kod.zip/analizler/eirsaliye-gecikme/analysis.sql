SELECT region, COUNT(*) AS sevkiyat, ROUND(AVG(delay_min),1) AS ort_gecikme, SUM(delay_min>30) AS geciken FROM data GROUP BY region ORDER BY ort_gecikme DESC;
