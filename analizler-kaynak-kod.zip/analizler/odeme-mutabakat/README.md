# Ödeme mutabakat farkları

**Durum:** Tamamlanmış, tekrar üretilebilir sentetik veri analizi. Gerçek işletme verisi değildir.

**Soru:** ERP tutarı ile ödeme sağlayıcı tutarı nerede ayrışıyor?

**Veri:** `160` sentetik kayıt, alanlar: provider, erp_amount, paid_amount.

**Yöntem:** SQLite sorgusu `analysis.sql` dosyasındadır. Python 3 ile `python analizler/odeme-mutabakat/run.py` çalıştırın. Önceden çalıştırılmış çıktı `results.json`, tarayıcı raporu `index.html` dosyasındadır.

**Yorumlama sınırı:** Tutarlar sentetiktir; mutabakat toleransı sıfır kabul edilir.
