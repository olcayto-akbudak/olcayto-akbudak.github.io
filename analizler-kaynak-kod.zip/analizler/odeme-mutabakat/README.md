# Ödeme mutabakatı: çoklu iade, taksit ve kur

Tamamen sentetik, sabit tohumlu portföy çalışması. Gerçek kurum sonucu değildir.

## Soru
Çoklu iadeler ve parçalı ödemeler eşleşirken hangi farklar gerçek, hangileri birleşim hatası?

## Yöntem
- 3.500 ödeme; ayrı iade, taksit, döviz ve test etiketi tabloları. Para kendi para biriminde tam sayı kuruşla tutulur.
- İade ve taksitler ödeme kimliğinde ayrı ayrı toplanır, sonra ana ödemeye LEFT JOIN yapılır. Beklenen net = brüt − komisyon − iadeler.
- Tolerans bir kuruştur. Kur yalnız TRY rapor sunumu için sabittir; eksik ve fazla tutarlar mutlak maruziyette birbirini götürmez. Test etiketi karar sorgusunda kullanılmaz.

## Bulgular
- Doğrudan birleşim brüt toplamı 2.373 katına şişirdi; önce toplama yaklaşımı 3.500 ödeme düzeyini korudu.
- Bekleyen, eksik ve fazla ödemeler ayrı izlenir. İmzalı farkla birlikte mutlak fark da raporlanır.

## Karar
Önce ödeme düzeyindeki tekilliği doğrula; bekleyenleri ayrı kuyruğa al, mutlak maruziyet ve neden bazlı fark listesini incele.

## Sınırlar
- Tarihsel kur, valör günü ve geç gelen kayıt yoktur. Sabit örnek kur gerçek değerleme için kullanılamaz.
- Ödeme kimliği eşleşmesi kesin varsayılır. Açıklama üzerinden olasılıklı eşleştirme ve müşteri hesabı mahsuplaşması kapsam dışıdır.

## Çalıştırma
Python 3.10+; paket kökünde `python run.py --study odeme-mutabakat`. CSV tabloları SQLite içine yüklenir, analysis.sql sorguları çalıştırılır ve results.json ile karşılaştırılır. Simülasyon/model çıktıları için `python build_advanced.py`; bütün çıktılar aynı tohumla yeniden üretilir.

## Kontroller
- Tüm sentetik etiketler SQL sınıflandırmasıyla eşleşiyor
- İade ve taksit toplamları kaynak kuruş tutarlarını koruyor
- Doğrudan çoklu birleşim toplamı şişiriyor