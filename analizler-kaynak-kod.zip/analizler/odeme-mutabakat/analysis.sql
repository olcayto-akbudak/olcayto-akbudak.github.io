SELECT provider, COUNT(*) AS kayit, SUM(ABS(erp_amount-paid_amount)>0) AS farkli, SUM(ABS(erp_amount-paid_amount)) AS mutlak_fark FROM data GROUP BY provider ORDER BY mutlak_fark DESC;
