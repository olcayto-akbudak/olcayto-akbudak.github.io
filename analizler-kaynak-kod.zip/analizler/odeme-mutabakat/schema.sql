CREATE TABLE payments (payment_id INTEGER PRIMARY KEY,currency TEXT,gross_minor INTEGER,fee_minor INTEGER);
CREATE TABLE refunds (refund_id INTEGER PRIMARY KEY,payment_id INTEGER,amount_minor INTEGER);
CREATE TABLE settlements (settlement_id INTEGER PRIMARY KEY,payment_id INTEGER,amount_minor INTEGER);
CREATE TABLE fx (currency TEXT PRIMARY KEY,try_rate REAL);
CREATE TABLE scenario_truth (payment_id INTEGER PRIMARY KEY,label TEXT);