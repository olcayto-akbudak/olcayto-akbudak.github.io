# API kapasitesi: kesinti, kuyruk ve yeniden deneme

Tamamen sentetik, sabit tohumlu portföy çalışması. Gerçek kurum sonucu değildir.

## Soru
45 saniyelik sağlayıcı kesintisinde yeniden deneme politikası başarıyı ve kuyruk yükünü nasıl etkiliyor?

## Yöntem
- 5.000 aynı geliş zamanı ve servis süresi, üç politika altında ayrık olay simülasyonuyla işlenir. Sekiz worker, 200–245. saniye arası kesinti ve en fazla altı deneme varsayılır.
- Başlangıç zamanı en erken müsait worker ile planlanan olayın maksimumudur. Yeniden deneme aynı iş kimliğini korur; kuyruk ve servis beklemesi gecikmeye dahildir.
- Üstel bekleme 1,2,4,8,16 saniye + U(0,1) jitter kullanır. Sonuç gecikmesi başarılı isteklerde P95; tüm isteklerde 30 saniye aşımı ayrıca raporlanır.

## Bulgular
- Politika başına 5.000 temel istek, toplam 16,667 sağlayıcı denemesi simüle edildi.
- Başarı, deneme çoğalması ve kuyruk zirvesi birlikte raporlanır; yalnız en yüksek başarı oranı bir politika seçmek için yeterli değildir.

## Karar
Yeniden deneme bütçesini başarı ve iş son tarihiyle birlikte belirle; aynı iş kimliği, kuyruk yaşı ve deneme çoğalması için ölçüm ekle.

## Sınırlar
- Kesinti sabit bir zaman aralığıdır; trafik ve servis süreleri sentetiktir. Modelde rate limit, gerçek ağ gecikmesi, devre kesici veya öncelik yoktur.
- Kuyruk zirvesi yalnız olay işleme anlarında ölçülür. Sonlu deneme bütçesi nedeniyle başarısız kalan istekler otomatik kurtarılmış sayılmaz.

## Çalıştırma
Python 3.10+; paket kökünde `python run.py --study api-kapasite`. CSV tabloları SQLite içine yüklenir, analysis.sql sorguları çalıştırılır ve results.json ile karşılaştırılır. Simülasyon/model çıktıları için `python build_advanced.py`; bütün çıktılar aynı tohumla yeniden üretilir.

## Kontroller
- Her politikada her istek için tam bir sonuç
- Deneme sayısı sonuç tablosuyla tutarlı
- En fazla altı deneme sınırı korunmuş