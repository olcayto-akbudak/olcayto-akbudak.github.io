CREATE TABLE arrivals (request_id INTEGER PRIMARY KEY,arrival_s REAL,service_s REAL);
CREATE TABLE attempts (policy TEXT,request_id INTEGER,attempt_no INTEGER,start_s REAL,service_s REAL,failed INTEGER);
CREATE TABLE outcomes (policy TEXT,request_id INTEGER,attempts INTEGER,latency_s REAL,success INTEGER,deadline_missed INTEGER);