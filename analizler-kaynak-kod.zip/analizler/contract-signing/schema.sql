CREATE TABLE units (unit_id INTEGER PRIMARY KEY,group_name TEXT);
CREATE TABLE followup (unit_id INTEGER PRIMARY KEY,observed_hours REAL,event INTEGER);