-- censor_summary
SELECT group_name,COUNT(*) AS units,SUM(event) AS events,SUM(1-event) AS censored,ROUND(AVG(CASE WHEN event=1 THEN observed_hours END),4) AS completed_mean_hours FROM units JOIN followup USING(unit_id) GROUP BY group_name ORDER BY group_name;

-- observed_bands
SELECT group_name,CAST(observed_hours/12 AS INTEGER) AS time_band,COUNT(*) AS units,SUM(event) AS events FROM units JOIN followup USING(unit_id) GROUP BY group_name,time_band ORDER BY group_name,time_band;