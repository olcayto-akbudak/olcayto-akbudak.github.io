SELECT shift, COUNT(*) AS siparis, ROUND(AVG(pick_min+pack_min+ship_min),1) AS toplam_dakika, ROUND(AVG(pick_min),1) AS toplama_dakika FROM data GROUP BY shift ORDER BY toplam_dakika DESC;
