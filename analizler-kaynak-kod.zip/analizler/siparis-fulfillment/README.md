# Sipariş hazırlama darboğazı

**Durum:** Tamamlanmış, tekrar üretilebilir sentetik veri analizi. Gerçek işletme verisi değildir.

**Soru:** Sipariş hazırlamada en fazla gecikme hangi vardiyada?

**Veri:** `160` sentetik kayıt, alanlar: shift, pick_min, pack_min, ship_min.

**Yöntem:** SQLite sorgusu `analysis.sql` dosyasındadır. Python 3 ile `python analizler/siparis-fulfillment/run.py` çalıştırın. Önceden çalıştırılmış çıktı `results.json`, tarayıcı raporu `index.html` dosyasındadır.

**Yorumlama sınırı:** Vardiyalar ve süreler kurgu veridir; ölçüm sistemi yerine geçmez.
