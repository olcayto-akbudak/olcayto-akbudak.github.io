# Sepet birliktelik analizi

**Durum:** Tamamlanmış, tekrar üretilebilir sentetik veri analizi. Gerçek işletme verisi değildir.

**Soru:** Ürün çiftlerinin birlikte satın alınma sıklığı nedir?

**Veri:** `193` sentetik kayıt, alanlar: order_id, product.

**Yöntem:** SQLite sorgusu `analysis.sql` dosyasındadır. Python 3 ile `python analizler/sepet-birliktelik/run.py` çalıştırın. Önceden çalıştırılmış çıktı `results.json`, tarayıcı raporu `index.html` dosyasındadır.

**Yorumlama sınırı:** Aynı siparişte tekil ürünler bulunur; metrik birliktelik adedidir, nedensel ilişki değildir.
