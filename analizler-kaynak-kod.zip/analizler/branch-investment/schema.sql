CREATE TABLE items (item_id INTEGER PRIMARY KEY,cost INTEGER,hours INTEGER);
CREATE TABLE scenario_values (item_id INTEGER,scenario INTEGER,value REAL);
CREATE TABLE dependencies (item_id INTEGER,requires_id INTEGER);