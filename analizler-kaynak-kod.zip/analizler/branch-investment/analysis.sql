-- scenario_summary
SELECT scenario,COUNT(*) AS items,ROUND(SUM(value),3) AS unconstrained_value FROM scenario_values GROUP BY scenario ORDER BY scenario;

-- item_summary
SELECT item_id,cost,hours,ROUND(AVG(value),3) AS average_value FROM items JOIN scenario_values USING(item_id) GROUP BY item_id,cost,hours ORDER BY item_id;