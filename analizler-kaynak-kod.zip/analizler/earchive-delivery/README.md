# e-Arşiv teslimat süresi dağılımı

Tamamen sentetik, sabit tohumlu portföy çalışması. Gerçek kurum sonucu değildir.

## Soru
Teslimat teyidi için henüz sonuçlanmayan kayıtları atmak gecikme değerlendirmesini nasıl değiştiriyor?

## Yöntem
- 600 birim A/B kohortlarında izlenir. Sonuç zamanı ve bağımsız gözlem sonu üretilir; gözlenen süre ikisinin küçüğüdür. Olay göstergesi sonucun gözlem penceresi içinde gerçekleşip gerçekleşmediğini bildirir.
- Kaplan–Meier hesabında aynı zamandaki olaylar sansürlerden önce risk kümesine uygulanır. Sansürlü kayıt olay olmuş gibi sayılmaz ve listeden doğrudan atılmaz. Tamamlananların ortalaması yalnız tamamlanan alt kümeyi anlatır.
- 48 saatlik kısıtlı ortalama olay bekleme süresi (RMST), olaysız kalma eğrisinin 0–48 arasındaki alanıdır. Eğri %50’yi geçmezse medyan hesaplanamaz; boş değer sıfıra çevrilmez.
- Kohortlar içinde 120 birim bootstrap ile B eksi A RMST farkının yüzdelik aralığı hesaplanır. Kuyruk farkı ve olay türü birlikte yorumlanmalıdır; yeniden açılma çalışmasında olay oluşması olumsuz, diğerlerinde süreç sonlanmasıdır.
- Birim kimliği, ilişki anahtarı ve satır düzeyi veri sözleşmesinde açıkça tutulur. SQL önce analiz birimini oluşturur; çoklu tablo satırları bağımsız gözlem gibi sayılmaz. Eksik sonuç ve gerçek sıfır aynı anlama gelmez.
- Sonuçlar sabit tohumlu sentetik senaryodan hesaplanır. Kaynak CSV, şema, SQL sorgusu, parametreler ve tam çıktılar aynı pakette bulunur; yeniden üretim karşılaştırması sayfa metnindeki rakamların kaynakla tutarlılığını denetler.

## Bulgular
- A kohortu RMST 9.2988 saat, B 13.3539 saat. Farkın %95 aralığı 2.8377–5.0917 saat.
- 600 gözlemin 36 tanesi sağ sansürlü. Tamamlanan ortalama ile bütün kohortun bekleme eğrisi ayrı sonuçlardır.

## Karar
Teyit gelmeyen kayıtları yaşa göre inceleme kuyruğuna al. Önce küçük kapsamlı bir pilot uygula; baz çizgiyle aynı analiz biriminde karşılaştır. Etki, belirsizlik ve yan etki ölçütlerini ayrı izle. Başarı eşiği ihlal edilirse yayılımı durdur ve veri kalitesi ile varsayımları yeniden değerlendir.

## Sınırlar
- Bağımsız sansür varsayımı ihlal edilirse eğri yanlı olabilir. Uzun süreçlerin özellikle gözlem dışına çıkması için başka bir model gerekir.
- Kohort ataması gerçek rastgele deney değildir; kohort farkı nedensel performans kanıtı olarak sunulmaz. 48 saatlik ufuk mevzuat veya hizmet taahhüdü değildir.
- Teslimat teyidi hukuki teslim ispatı olarak yorumlanamaz.
- Bu çalışma üretime hazır bir karar sistemi değildir. Pilot öncesinde veri sahibi, iş birimi ve teknik ekip ölçüm tanımını, yanlış karar maliyetini ve geri dönüş koşulunu birlikte belirlemelidir.

## Çalıştırma
Python 3.10+; paket kökünde `python run.py --study earchive-delivery`. CSV tabloları SQLite içine yüklenir, analysis.sql sorguları çalıştırılır ve results.json ile karşılaştırılır. Simülasyon/model çıktıları için `python build_expansion.py`; bütün çıktılar aynı tohumla yeniden üretilir.

## Kontroller
- Her birimde tek izleme kaydı var
- Olay ve sansür kohort toplamını koruyor
- Eğri monoton ve olasılık sınırında
- RMST ufku aşmıyor

## Veri sözleşmesi
`contract.json` analiz birimi, kolon tipleri, satır sayıları ve sabit tohumu kaydeder. SQL SQLite sözdizimindedir. Takvim ve oran eşikleri bu sentetik senaryonun varsayımlarıdır.
