# Satış kanalı kârlılık analizi

**Durum:** Tamamlanmış, tekrar üretilebilir sentetik veri analizi. Gerçek işletme verisi değildir.

**Soru:** Komisyon ve iadeler sonrasında hangi kanal daha kârlı?

**Veri:** `160` sentetik kayıt, alanlar: channel, revenue, cost, commission, refunded.

**Yöntem:** SQLite sorgusu `analysis.sql` dosyasındadır. Python 3 ile `python analizler/satis-kanal-karliligi/run.py` çalıştırın. Önceden çalıştırılmış çıktı `results.json`, tarayıcı raporu `index.html` dosyasındadır.

**Yorumlama sınırı:** İade durumunda gelirin tamamı geri alınır; maliyet ve komisyon gideri korunur.
