CREATE TABLE records (record_id INTEGER PRIMARY KEY,normalized_name TEXT,email TEXT,city TEXT,split TEXT);
CREATE TABLE identity_truth (record_id INTEGER PRIMARY KEY,entity_id INTEGER);
CREATE TABLE candidate_scores (left_id INTEGER,right_id INTEGER,split TEXT,score REAL,same_entity INTEGER,suggested_match INTEGER);