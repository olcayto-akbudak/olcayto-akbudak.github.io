-- split_confusion
SELECT split,COUNT(*) AS candidate_pairs,SUM(same_entity) AS true_pairs,SUM(suggested_match AND same_entity) AS tp,SUM(suggested_match AND NOT same_entity) AS fp,SUM(NOT suggested_match AND same_entity) AS fn FROM candidate_scores GROUP BY split;

-- blocking_sample
SELECT a.record_id AS left_id,b.record_id AS right_id FROM records a JOIN records b ON a.city=b.city AND a.split=b.split AND substr(a.normalized_name,1,instr(a.normalized_name,' ')-1)=substr(b.normalized_name,1,instr(b.normalized_name,' ')-1) AND a.record_id<b.record_id ORDER BY a.record_id,b.record_id LIMIT 10;