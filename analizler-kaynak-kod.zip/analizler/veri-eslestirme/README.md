# Veri kalitesi: kayıt eşleştirme ve yanlış birleşme

Tamamen sentetik, sabit tohumlu portföy çalışması. Gerçek kurum sonucu değildir.

## Soru
Benzer kayıtları birleştirirken kaç gerçek eşleşme kaçıyor ve zincirleme yanlış birleşme riski ne?

## Yöntem
- 2.000 sentetik kimliğe ait 4.000 kayıt; ad, e-posta ve bölge değişimleri. Adaylar aynı bölge ve aynı ilk ad bloğunda üretilir.
- Kimlikler eğitim/doğrulama/test arasında ayrıdır. Etiketler yalnız değerlendirmede kullanılır; skor %65 ad + %35 e-posta benzerliğidir. Eğitimli model değil, sabit bir benzerlik kuralıdır.
- Eşik doğrulamada yanlış birleşmeye 10, kaçan eşleşmeye 1 örnek maliyetle seçilir. Testte aday içi recall ile uçtan uca recall ayrı verilir.
- Önerilen eşleşmelerin bağlı bileşenleri kontrol edilerek farklı kimliklerin aynı kümeye girmesi sayılır. Çift seviyesinde precision küme güvenliğini tek başına kanıtlamaz.

## Bulgular
- Test aday üretimi gerçek çiftlerin %91.25 kadarını buldu. Seçilen eşik 0.99; uçtan uca recall %60.25.
- Testte 0 yanlış çift önerisi ve 0 farklı kimlik içeren bağlı bileşen bulundu; bu kayıtlar otomatik birleştirme için güvenli kabul edilmez.

## Karar
Benzerlik skorunu inceleme kuyruğu üretmek için kullan; düşük riskli çiftlerde dahi bağlı bileşen kontrolü ve kullanıcı onayı olmadan kalıcı birleştirme yapma.

## Sınırlar
- Sentetik isim tekrarları ve hata biçimleri gerçek nüfusu temsil etmez. Doğrulama maliyetleri varsayımsaldır.
- Farklı bölgeler blok dışında kaldığından gerçek eşleşmeler kaçabilir. Test havuzları ayrı üretildi; üretimde bölgeler ve dönemler arası aday kapsamı ayrıca ölçülmelidir.
- Bağlı bileşenler yalnız risk analizi için oluşturulur; gerçek müşteri kaydı birleştirilmez.

## Çalıştırma
Python 3.10+; paket kökünde `python run.py --study veri-eslestirme`. CSV tabloları SQLite içine yüklenir, analysis.sql sorguları çalıştırılır ve results.json ile karşılaştırılır. Simülasyon/model çıktıları için `python build_advanced.py`; bütün çıktılar aynı tohumla yeniden üretilir.

## Kontroller
- 4.000 kayıt ve 2.000 kimlik korunuyor
- Aday çiftleri tekil ve yönü sıralı
- Eşik test etiketleri kullanılmadan seçilmiş
- Aday içi recall ile uçtan uca recall ayrılıyor