# Destek talebi önceliklendirme

**Durum:** Tamamlanmış, tekrar üretilebilir sentetik veri analizi. Gerçek işletme verisi değildir.

**Soru:** Hangi talep türü açık bilet yükünü büyütüyor?

**Veri:** `160` sentetik kayıt, alanlar: topic, severity, hours_open, resolved.

**Yöntem:** SQLite sorgusu `analysis.sql` dosyasındadır. Python 3 ile `python analizler/destek-oncelik/run.py` çalıştırın. Önceden çalıştırılmış çıktı `results.json`, tarayıcı raporu `index.html` dosyasındadır.

**Yorumlama sınırı:** Şiddet 1–3 olarak kodlanır; 3 en kritik düzeydir.
