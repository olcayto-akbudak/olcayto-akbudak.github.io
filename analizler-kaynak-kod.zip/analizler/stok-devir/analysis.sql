SELECT category, ROUND(SUM(cost_sold)*1.0/SUM(avg_inventory),2) AS devir_orani, SUM(cost_sold) AS satis_maliyeti, SUM(avg_inventory) AS ort_stok FROM data GROUP BY category ORDER BY devir_orani ASC;
