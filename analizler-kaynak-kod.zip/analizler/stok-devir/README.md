# Stok devir göstergesi

**Durum:** Tamamlanmış, tekrar üretilebilir sentetik veri analizi. Gerçek işletme verisi değildir.

**Soru:** Hangi kategoride stok hareketi daha yavaş?

**Veri:** `160` sentetik kayıt, alanlar: category, cost_sold, avg_inventory.

**Yöntem:** SQLite sorgusu `analysis.sql` dosyasındadır. Python 3 ile `python analizler/stok-devir/run.py` çalıştırın. Önceden çalıştırılmış çıktı `results.json`, tarayıcı raporu `index.html` dosyasındadır.

**Yorumlama sınırı:** Tek dönem maliyet/stok oranıdır; yıllıklandırılmış stok devir hızı değildir.
