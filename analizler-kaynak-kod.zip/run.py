"""Execute saved SQL on the CSV sources; verify deterministic full regeneration."""
import argparse,csv,json,sqlite3,subprocess,sys,tempfile,shutil
from pathlib import Path

ROOT=Path(__file__).resolve().parent

def check_study(folder):
    db=sqlite3.connect(':memory:');db.executescript((folder/'schema.sql').read_text(encoding='utf-8'))
    for file in sorted(folder.glob('*.csv')):
        with file.open(encoding='utf-8',newline='') as f:
            rows=csv.reader(f);columns=next(rows);db.executemany('INSERT INTO '+file.stem+' VALUES ('+','.join('?' for _ in columns)+')',rows)
    expected=json.loads((folder/'results.json').read_text(encoding='utf-8'));count=0
    for section in (folder/'analysis.sql').read_text(encoding='utf-8').split('\n\n'):
        title,query=section.split('\n',1);key=title.removeprefix('-- ')
        cur=db.execute(query);result=[dict(zip([c[0] for c in cur.description],row)) for row in cur]
        assert result==expected[key],f'{folder.name}: {key} differs from results.json'
        count+=1
    db.close();return count

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--study');parser.add_argument('--verify',action='store_true',help='Rebuild all SQL, model and simulation results in a temporary directory and compare every CSV/JSON.');args=parser.parse_args()
    folders=[ROOT/'analizler'/args.study] if args.study else sorted((ROOT/'analizler').iterdir());total=0
    for folder in folders:
        n=check_study(folder);total+=n;print('PASS',folder.name,n,'SQL queries')
    if args.verify:
        with tempfile.TemporaryDirectory() as temp:
            temp=Path(temp)
            for name in ['build_advanced.py']:
                shutil.copy2(ROOT/name,temp/name)
            subprocess.run([sys.executable,str(temp/'build_advanced.py')],check=True)
            files=[ROOT/'catalog.json']+sorted((ROOT/'analizler').rglob('*.csv'))+sorted((ROOT/'analizler').rglob('results.json'))
            for file in files:
                other=temp/file.relative_to(ROOT)
                assert file.read_bytes()==other.read_bytes(),'Regeneration differs: '+str(file.relative_to(ROOT))
            print('PASS full deterministic regeneration:',len(files),'CSV/JSON files')
    print('PASS',total,'SQL result comparisons')

if __name__=='__main__':main()
