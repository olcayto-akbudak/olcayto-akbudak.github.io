"""Reproducible portfolio studies. Python standard library only; all data synthetic."""
import csv, hashlib, heapq, html, json, math, random, shutil, sqlite3, statistics, zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'analizler'
SEED = 20261002
studies = []

def pct(n,d): return round(100*n/d,2) if d else None
def quantile(xs,p):
    xs=sorted(xs)
    if not xs: return None
    pos=(len(xs)-1)*p;lo=int(pos);hi=min(lo+1,len(xs)-1)
    return round(xs[lo]+(xs[hi]-xs[lo])*(pos-lo),3)
def ci(xs,seed=42,rounds=300):
    rng=random.Random(seed)
    means=[statistics.mean(rng.choices(xs,k=len(xs))) for _ in range(rounds)]
    return [quantile(means,.025),quantile(means,.975)]
def sqlrows(db,query):
    cur=db.execute(query)
    return [dict(zip([x[0] for x in cur.description],row)) for row in cur]
def save(slug,title,category,question,tables,queries,extra,method,findings,limits,checks,decision):
    folder=OUT/slug;folder.mkdir(parents=True,exist_ok=True)
    db=sqlite3.connect(':memory:')
    for name,(columns,rows) in tables.items():
        db.execute('CREATE TABLE '+name+' ('+','.join(f'{k} {t}' for k,t in columns)+')')
        db.executemany('INSERT INTO '+name+' VALUES ('+','.join('?' for _ in columns)+')',rows)
        with (folder/(name+'.csv')).open('w',newline='',encoding='utf-8') as f:
            w=csv.writer(f);w.writerow([k for k,t in columns]);w.writerows(rows)
    results={name:sqlrows(db,q) for name,q in queries.items()};results.update(extra)
    for name,ok in checks: assert ok,slug+': '+name
    schema='\n'.join('CREATE TABLE '+name+' ('+','.join(f'{k} {t}' for k,t in cols)+');' for name,(cols,rows) in tables.items())
    (folder/'schema.sql').write_text(schema,encoding='utf-8')
    (folder/'analysis.sql').write_text('\n\n'.join('-- '+n+'\n'+q+';' for n,q in queries.items()),encoding='utf-8')
    (folder/'results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
    record=dict(slug=slug,title=title,category=category,question=question,tables={n:len(r) for n,(c,r) in tables.items()},method=method,findings=findings,limits=limits,checks=[n for n,ok in checks],decision=decision,results=results,sql=queries)
    studies.append(record)
    (folder/'README.md').write_text('# '+title+'\n\nTamamen sentetik, sabit tohumlu portföy çalışması. Gerçek kurum sonucu değildir.\n\n## Soru\n'+question+'\n\n## Yöntem\n'+'\n'.join('- '+s for s in method)+'\n\n## Bulgular\n'+'\n'.join('- '+s for s in findings)+'\n\n## Karar\n'+decision+'\n\n## Sınırlar\n'+'\n'.join('- '+s for s in limits)+'\n\n## Çalıştırma\nPython 3.10+; paket kökünde `python run.py --study '+slug+'`. CSV tabloları SQLite içine yüklenir, analysis.sql sorguları çalıştırılır ve results.json ile karşılaştırılır. Simülasyon/model çıktıları için `python build_advanced.py`; bütün çıktılar aynı tohumla yeniden üretilir.\n\n## Kontroller\n'+'\n'.join('- '+n for n,ok in checks),encoding='utf-8')
    db.close()

def invoice():
    rng=random.Random(SEED+1);docs=[];events=[];providers=[('A','Karmaşık ağırlıklı'),('B','Basit ağırlıklı')]
    for i in range(1,6001):
        provider='A' if i<=3000 else 'B';complexity='Karmaşık' if rng.random() < (.75 if provider=='A' else .25) else 'Basit'
        # Conditional A latency is better, but A receives more complex documents.
        duration=rng.lognormvariate(math.log((22 if complexity=='Karmaşık' else 5)*(1 if provider=='A' else 1.2)),.5)
        age=rng.uniform(8,100);done=duration<=age
        docs.append((i,provider,complexity,round(age,3)))
        events.append((i,'SUBMITTED',0))
        if done:events.append((i,'COMPLETED',round(duration,3)))
    tables={'documents':([('doc_id','INTEGER PRIMARY KEY'),('provider','TEXT'),('complexity','TEXT'),('observed_age_min','REAL')],docs),'events':([('doc_id','INTEGER'),('event','TEXT'),('minute','REAL')],events),'providers':([('provider','TEXT PRIMARY KEY'),('assignment_mix','TEXT')],providers)}
    base="WITH e AS (SELECT doc_id,MAX(CASE WHEN event='COMPLETED' THEN minute END) AS completion FROM events GROUP BY doc_id), d AS (SELECT documents.*,completion,CASE WHEN completion IS NOT NULL THEN completion>30 WHEN observed_age_min>=30 THEN 1 ELSE NULL END AS breach FROM documents JOIN e USING(doc_id)) "
    q1=base+"SELECT provider,COUNT(*) AS assigned,COUNT(completion) AS completed,SUM(completion IS NULL) AS pending,COUNT(breach) AS assessable,SUM(breach) AS breached,ROUND(100.0*SUM(breach)/COUNT(breach),2) AS breach_pct FROM d GROUP BY provider"
    q2=base+"SELECT provider,complexity,COUNT(*) AS assigned,COUNT(breach) AS assessable,ROUND(100.0*SUM(breach)/COUNT(breach),2) AS breach_pct FROM d GROUP BY provider,complexity"
    db=sqlite3.connect(':memory:');db.execute('CREATE TABLE documents(doc_id,provider,complexity,observed_age_min)');db.executemany('INSERT INTO documents VALUES (?,?,?,?)',docs);db.execute('CREATE TABLE events(doc_id,event,minute)');db.executemany('INSERT INTO events VALUES (?,?,?)',events)
    raw=sqlrows(db,q1);strata=sqlrows(db,q2)
    standardized=[{'provider':p,'standardized_breach_pct':round(statistics.mean(r['breach_pct'] for r in strata if r['provider']==p),2),'weight_complex':.5,'weight_simple':.5} for p in ['A','B']]
    dist=[]
    for p in ['A','B']:
        ids={d[0] for d in docs if d[1]==p};dur=[x[2] for x in events if x[0] in ids and x[1]=='COMPLETED'];dist.append({'provider':p,'completed_p50_min':quantile(dur,.5),'completed_p95_min':quantile(dur,.95)})
    db.close()
    checks=[('Her belge için bir SUBMITTED olayı var',sum(e[1]=='SUBMITTED' for e in events)==len(docs)),('Tamamlanan ve bekleyen sayısı atanan toplamına eşit',all(r['completed']+r['pending']==r['assigned'] for r in raw)),('Ham sıralama ile eşit karmaşıklık ağırlıklı sıralama farklı',raw[0]['breach_pct']>raw[1]['breach_pct'] and standardized[0]['standardized_breach_pct']<standardized[1]['standardized_breach_pct'])]
    save('efatura-sla','e-Fatura SLA: sansürlü kayıtlar ve vaka karması','Entegrasyon','Sağlayıcılar arasındaki SLA farkı performanstan mı, belge karmasından mı kaynaklanıyor?',tables,{'provider_sla':q1,'complexity_strata':q2},{'standardized_mix':standardized,'completed_latency':dist},['6.000 belge, olay günlüğü ve sağlayıcı tablosu SQL ile birleştirilir. SLA eşiği sentetik 30 dakikadır.','Tamamlanan belge gerçek süresiyle; bekleyen belge yaşı 30 dakikayı geçtiyse ihlal olarak değerlendirilir. Yaşı küçük bekleyenler henüz değerlendirilemez.','Sağlayıcılar basit/karmaşık tabakalarında karşılaştırılır; her tabakaya %50 ağırlık verilerek standartlaştırılır. P95 yalnız tamamlanmış belgeler içindir.'],[f"Ham ihlal: A %{raw[0]['breach_pct']}, B %{raw[1]['breach_pct']}. Eşit karmaşıklık karmasıyla A %{standardized[0]['standardized_breach_pct']}, B %{standardized[1]['standardized_breach_pct']}.",f"Tamamlanmamış {sum(r['pending'] for r in raw)} belge, tamamlanan süre dağılımına katılmadı; yaşına göre SLA paydasında ayrıca ele alındı."],['Atama rastgele değildir; karmaşıklık dışındaki karıştırıcılar ölçülmedi. Standartlaştırma tek başına nedensel kanıt değildir.','Sentetik 30 dakika bir sağlayıcı taahhüdü veya mevzuat sınırı değildir. Tamamlanan P95 tüm belgelerin P95’i olarak yorumlanamaz.'],checks,'Sağlayıcı seçiminde ham ortalama yerine aynı vaka karmasının ihlal oranını, bekleyen yaşını ve tamamlanan P95’i birlikte takip et.')

def retries():
    rng=random.Random(SEED+2);docs=[];attempts=[];side=[];seq=0
    for i in range(1,4001):
        accepted=rng.random()>.08;lost=accepted and rng.random()<.24
        docs.append((i,int(accepted),int(lost)))
        for policy in ['Kontrolsüz tekrar','UUID koruması']:
            n=2 if lost else 1
            for j in range(n):
                seq+=1;blocked=policy=='UUID koruması' and j==1
                attempts.append((seq,i,policy,j+1,int(blocked),'BLOCKED' if blocked else 'TIMEOUT' if j==0 and lost else 'ACCEPTED' if accepted else 'REJECTED'))
                if accepted and not blocked:side.append((seq,i,policy))
    t={'documents':([('doc_id','INTEGER PRIMARY KEY'),('accepted','INTEGER'),('response_lost','INTEGER')],docs),'attempts':([('attempt_id','INTEGER PRIMARY KEY'),('doc_id','INTEGER'),('policy','TEXT'),('ordinal','INTEGER'),('blocked','INTEGER'),('transport_result','TEXT')],attempts),'provider_effects':([('attempt_id','INTEGER PRIMARY KEY'),('doc_id','INTEGER'),('policy','TEXT')],side)}
    q="WITH d AS (SELECT doc_id,policy,COUNT(*) AS provider_docs FROM provider_effects GROUP BY doc_id,policy), a AS (SELECT policy,COUNT(*) AS attempts,SUM(blocked) AS blocked FROM attempts GROUP BY policy) SELECT a.policy,a.attempts,a.blocked,SUM(d.provider_docs) AS provider_docs,SUM(d.provider_docs-1) AS duplicate_docs FROM a JOIN d USING(policy) GROUP BY a.policy"
    dup=sum(d[1] and d[2] for d in docs);effects={p:sum(x[2]==p for x in side) for p in ['Kontrolsüz tekrar','UUID koruması']}
    save('idempotency-risk','e-Fatura tekrar gönderim: eşlenmiş politika deneyi','Entegrasyon','Aynı yanıt kaybı olaylarında UUID koruması mükerrer belge riskini ne kadar değiştiriyor?',t,{'policy_effects':q},{'paired_effect':[{'matched_documents':4000,'prevented_duplicates':dup,'prevented_per_1000_documents':round(dup/4,2),'provider_call_difference':effects['Kontrolsüz tekrar']-effects['UUID koruması']}]},['Aynı 4.000 belge ve aynı sağlayıcı kabul/yanıt kaybı olayları iki politika altında yeniden oynatılır.','Yerel gönderim denemesi ile sağlayıcıdaki iş etkisi ayrı tablolarda tutulur. Yanıt kaybı kabul edilen işin geri alınması değildir.','Sağlayıcı etkileri belge/politika seviyesinde önce gruplanır; rapor birleştirmesi bu düzeyde yapılır.'],[f"Aynı koşullarda {dup} ek sağlayıcı belgesi önlendi; her 1.000 belge başına {round(dup/4,2)} mükerrer iş etkisi.",'İki politikada ilk gönderim sonuçları aynıdır; fark yalnız tekrarın engellenmesinden gelir.'],['Koruma ideal, kalıcı ve atomik varsayılır. Gerçek dağıtık yarışlar, anahtar süresi ve içerik özeti çakışması bu modelde yoktur.','Sentetik karşı-olgusal deney gerçek işletme etki tahmini değildir.'],[('Korumalı politikada işlenmiş belge başına en fazla bir etki',len({x[1] for x in side if x[2]=='UUID koruması'})==effects['UUID koruması']),('Politikalar aynı temel belgelere uygulanmış',len(attempts)==8000+2*dup),('Önlenen etkiler yanıt kayıplarına eşit',effects['Kontrolsüz tekrar']-effects['UUID koruması']==dup)],'Timeout sonrası aynı UUID ile otomatik yeniden belge üretme; kalıcı tekillik kontrolünü ve sağlayıcı sorgusuyla mutabakatı kabul ölçütüne dönüştür.')

def capacity():
    rng=random.Random(SEED+3);arrivals=[(i,round(rng.uniform(0,600),3),round(rng.uniform(.12,.65),3)) for i in range(1,5001)];arrivals.sort(key=lambda x:x[1]);rows=[];attempt_rows=[];meta=[]
    for policy in ['Tek deneme','Sabit 1 saniye','Üstel + jitter']:
        rngp=random.Random(SEED+33);queue=[];servers=[0.0]*8;heapq.heapify(servers);peak=0;max_end=0
        for i,t,s in arrivals:heapq.heappush(queue,(t,i,1,t,s))
        while queue:
            scheduled,i,n,original,service=heapq.heappop(queue);free=heapq.heappop(servers);start=max(free,scheduled);end=start+service;heapq.heappush(servers,end)
            fail=200<=start<245
            attempt_rows.append((policy,i,n,round(start,3),round(end-start,3),int(fail)))
            peak=max(peak,sum(v<=start for v,*rest in queue));max_end=max(max_end,end)
            if fail and policy!='Tek deneme' and n<6:
                wait=1 if policy=='Sabit 1 saniye' else min(32,2**(n-1))+rngp.uniform(0,1)
                heapq.heappush(queue,(end+wait,i,n+1,original,service))
            else: rows.append((policy,i,n,round(end-original,3),int(not fail),int(end-original>30)))
        lat=[r[3] for r in rows if r[0]==policy and r[4]];meta.append({'policy':policy,'successful_p95_s':quantile(lat,.95),'peak_waiting_events':peak,'last_completion_s':round(max_end,3)})
    t={'arrivals':([('request_id','INTEGER PRIMARY KEY'),('arrival_s','REAL'),('service_s','REAL')],arrivals),'attempts':([('policy','TEXT'),('request_id','INTEGER'),('attempt_no','INTEGER'),('start_s','REAL'),('service_s','REAL'),('failed','INTEGER')],attempt_rows),'outcomes':([('policy','TEXT'),('request_id','INTEGER'),('attempts','INTEGER'),('latency_s','REAL'),('success','INTEGER'),('deadline_missed','INTEGER')],rows)}
    q="SELECT policy,COUNT(*) AS requests,SUM(success) AS success,SUM(deadline_missed) AS over_30_s,SUM(attempts) AS provider_attempts,ROUND(1.0*SUM(attempts)/COUNT(*),3) AS amplification FROM outcomes GROUP BY policy"
    save('api-kapasite','API kapasitesi: kesinti, kuyruk ve yeniden deneme','Entegrasyon','45 saniyelik sağlayıcı kesintisinde yeniden deneme politikası başarıyı ve kuyruk yükünü nasıl etkiliyor?',t,{'policy_summary':q},{'latency_and_queue':meta},['5.000 aynı geliş zamanı ve servis süresi, üç politika altında ayrık olay simülasyonuyla işlenir. Sekiz worker, 200–245. saniye arası kesinti ve en fazla altı deneme varsayılır.','Başlangıç zamanı en erken müsait worker ile planlanan olayın maksimumudur. Yeniden deneme aynı iş kimliğini korur; kuyruk ve servis beklemesi gecikmeye dahildir.','Üstel bekleme 1,2,4,8,16 saniye + U(0,1) jitter kullanır. Sonuç gecikmesi başarılı isteklerde P95; tüm isteklerde 30 saniye aşımı ayrıca raporlanır.'],[f"Politika başına 5.000 temel istek, toplam {len(attempt_rows):,} sağlayıcı denemesi simüle edildi.",'Başarı, deneme çoğalması ve kuyruk zirvesi birlikte raporlanır; yalnız en yüksek başarı oranı bir politika seçmek için yeterli değildir.'],['Kesinti sabit bir zaman aralığıdır; trafik ve servis süreleri sentetiktir. Modelde rate limit, gerçek ağ gecikmesi, devre kesici veya öncelik yoktur.','Kuyruk zirvesi yalnız olay işleme anlarında ölçülür. Sonlu deneme bütçesi nedeniyle başarısız kalan istekler otomatik kurtarılmış sayılmaz.'],[('Her politikada her istek için tam bir sonuç',len(rows)==15000 and len({(r[0],r[1]) for r in rows})==15000),('Deneme sayısı sonuç tablosuyla tutarlı',sum(r[2] for r in rows)==len(attempt_rows)),('En fazla altı deneme sınırı korunmuş',max(r[2] for r in rows)<=6)],'Yeniden deneme bütçesini başarı ve iş son tarihiyle birlikte belirle; aynı iş kimliği, kuyruk yaşı ve deneme çoğalması için ölçüm ekle.')

def reconciliation():
    rng=random.Random(SEED+4);payments=[];refunds=[];settlements=[];rates=[('TRY',1.0),('EUR',38.0),('USD',35.0)];truth=[];rid=0;sid=0
    for i in range(1,3501):
        currency=rng.choice(rates);gross=rng.randint(5000,200000);fee=round(gross*.025);refund=round(gross*rng.uniform(.1,.7)) if rng.random()<.2 else 0
        payments.append((i,currency[0],gross,fee));parts=rng.randint(1,3) if refund else 0;remaining=refund
        for j in range(parts):
            rid+=1;v=remaining if j==parts-1 else remaining//2;refunds.append((rid,i,v));remaining-=v
        expected=gross-fee-refund;kind=rng.choices(['Tam','Eksik','Fazla','Bekliyor'],[.83,.07,.05,.05])[0]
        actual=expected if kind=='Tam' else expected-rng.randint(100,1000) if kind=='Eksik' else expected+rng.randint(100,1000) if kind=='Fazla' else 0
        truth.append((i,kind));remaining=actual;parts=0 if kind=='Bekliyor' else rng.randint(1,3)
        for j in range(parts):
            sid+=1;v=remaining if j==parts-1 else remaining//2;settlements.append((sid,i,v));remaining-=v
    t={'payments':([('payment_id','INTEGER PRIMARY KEY'),('currency','TEXT'),('gross_minor','INTEGER'),('fee_minor','INTEGER')],payments),'refunds':([('refund_id','INTEGER PRIMARY KEY'),('payment_id','INTEGER'),('amount_minor','INTEGER')],refunds),'settlements':([('settlement_id','INTEGER PRIMARY KEY'),('payment_id','INTEGER'),('amount_minor','INTEGER')],settlements),'fx':([('currency','TEXT PRIMARY KEY'),('try_rate','REAL')],rates),'scenario_truth':([('payment_id','INTEGER PRIMARY KEY'),('label','TEXT')],truth)}
    base="WITH r AS (SELECT payment_id,SUM(amount_minor) AS refund FROM refunds GROUP BY payment_id), s AS (SELECT payment_id,SUM(amount_minor) AS paid FROM settlements GROUP BY payment_id), d AS (SELECT p.*,gross_minor-fee_minor-COALESCE(refund,0) AS expected,COALESCE(paid,0) AS paid,CASE WHEN s.payment_id IS NULL THEN 'Bekliyor' WHEN ABS(COALESCE(paid,0)-(gross_minor-fee_minor-COALESCE(refund,0)))<=1 THEN 'Tam' WHEN paid<gross_minor-fee_minor-COALESCE(refund,0) THEN 'Eksik' ELSE 'Fazla' END AS classification FROM payments p LEFT JOIN r USING(payment_id) LEFT JOIN s USING(payment_id)) "
    q=base+"SELECT classification,COUNT(*) AS payments,ROUND(SUM((paid-expected)/100.0*try_rate),2) AS signed_difference_try,ROUND(SUM(ABS(paid-expected)/100.0*try_rate),2) AS absolute_difference_try FROM d JOIN fx USING(currency) GROUP BY classification"
    q2=base+"SELECT payment_id,currency,expected,paid,paid-expected AS difference_minor,classification FROM d WHERE classification!='Tam' ORDER BY ABS(paid-expected) DESC LIMIT 12"
    db=sqlite3.connect(':memory:')
    for n,(cols,rows) in t.items():db.execute('CREATE TABLE '+n+' ('+','.join(k+' '+ty for k,ty in cols)+')');db.executemany('INSERT INTO '+n+' VALUES ('+','.join('?' for _ in cols)+')',rows)
    mismatches=db.execute(base+"SELECT COUNT(*) FROM d JOIN scenario_truth USING(payment_id) WHERE classification!=label").fetchone()[0]
    # Deliberately demonstrate fan-out risk; never use the inflated number as a business result.
    naive=db.execute('SELECT SUM(gross_minor) FROM payments LEFT JOIN refunds USING(payment_id) LEFT JOIN settlements USING(payment_id)').fetchone()[0];correct=sum(p[2] for p in payments)
    checks=[('Tüm sentetik etiketler SQL sınıflandırmasıyla eşleşiyor',mismatches==0),('İade ve taksit toplamları kaynak kuruş tutarlarını koruyor',all(r[2]>=0 for r in refunds+settlements)),('Doğrudan çoklu birleşim toplamı şişiriyor',naive>correct)]
    save('odeme-mutabakat','Ödeme mutabakatı: çoklu iade, taksit ve kur','Veri ve finans','Çoklu iadeler ve parçalı ödemeler eşleşirken hangi farklar gerçek, hangileri birleşim hatası?',t,{'classified_exposure':q,'largest_cases':q2},{'join_control':[{'correct_gross_minor':correct,'naive_join_gross_minor':naive,'inflation_factor':round(naive/correct,3),'classification_mismatches':mismatches}]},['3.500 ödeme; ayrı iade, taksit, döviz ve test etiketi tabloları. Para kendi para biriminde tam sayı kuruşla tutulur.','İade ve taksitler ödeme kimliğinde ayrı ayrı toplanır, sonra ana ödemeye LEFT JOIN yapılır. Beklenen net = brüt − komisyon − iadeler.','Tolerans bir kuruştur. Kur yalnız TRY rapor sunumu için sabittir; eksik ve fazla tutarlar mutlak maruziyette birbirini götürmez. Test etiketi karar sorgusunda kullanılmaz.'],[f"Doğrudan birleşim brüt toplamı {round(naive/correct,3)} katına şişirdi; önce toplama yaklaşımı 3.500 ödeme düzeyini korudu.",'Bekleyen, eksik ve fazla ödemeler ayrı izlenir. İmzalı farkla birlikte mutlak fark da raporlanır.'],['Tarihsel kur, valör günü ve geç gelen kayıt yoktur. Sabit örnek kur gerçek değerleme için kullanılamaz.','Ödeme kimliği eşleşmesi kesin varsayılır. Açıklama üzerinden olasılıklı eşleştirme ve müşteri hesabı mahsuplaşması kapsam dışıdır.'],checks,'Önce ödeme düzeyindeki tekilliği doğrula; bekleyenleri ayrı kuyruğa al, mutlak maruziyet ve neden bazlı fark listesini incele.')
    db.close()

def process():
    rng=random.Random(SEED+5);cases=[];events=[];durations={};rework_d=[];clean_d=[]
    for i in range(1,3001):
        priority='Acil' if rng.random()<.3 else 'Normal';branch=rng.choice(['Kuzey','Güney','Merkez']);rework=rng.random()<(.3 if branch=='Güney' else .14)
        cases.append((i,branch,priority));time=0;stages=[('PO_CREATED',0),('APPROVED',rng.uniform(2,14)),('GOODS_RECEIVED',rng.uniform(12,70)),('INVOICE_RECEIVED',rng.uniform(4,24))]
        for stage,wait in stages:
            time+=wait*(.55 if priority=='Acil' else 1);events.append((i,len(events)+1,stage,round(time,3)))
        if rework:
            for stage in ['BLOCKED','CORRECTED','INVOICE_RECEIVED']:
                time+=rng.uniform(3,30);events.append((i,len(events)+1,stage,round(time,3)))
        time+=rng.uniform(10,40);events.append((i,len(events)+1,'PAID',round(time,3)));durations[i]=time
        (rework_d if rework else clean_d).append(time)
    t={'cases':([('case_id','INTEGER PRIMARY KEY'),('branch','TEXT'),('priority','TEXT')],cases),'events':([('case_id','INTEGER'),('event_id','INTEGER PRIMARY KEY'),('activity','TEXT'),('hour','REAL')],events)}
    base="WITH ordered AS (SELECT *,LAG(hour) OVER(PARTITION BY case_id ORDER BY hour,event_id) AS previous_hour FROM events), a AS (SELECT case_id,MAX(hour)-MIN(hour) AS duration,SUM(activity='INVOICE_RECEIVED')>1 AS rework FROM events GROUP BY case_id) "
    q=base+"SELECT branch,priority,rework,COUNT(*) AS cases,ROUND(AVG(duration),2) AS avg_hours FROM cases JOIN a USING(case_id) GROUP BY branch,priority,rework"
    q2=base+"SELECT activity,COUNT(*) AS transitions,ROUND(AVG(hour-previous_hour),2) AS average_wait_h FROM ordered WHERE previous_hour IS NOT NULL GROUP BY activity ORDER BY average_wait_h DESC"
    paired=[]
    for pri in ['Acil','Normal']:
        ids={i for i,b,p in cases if p==pri};rw=[durations[i] for i in ids if sum(e[0]==i and e[2]=='INVOICE_RECEIVED' for e in events)>1];cl=[durations[i] for i in ids if i not in {e[0] for e in events if e[2]=='CORRECTED'}]
        rr=random.Random(SEED+55);deltas=[statistics.mean(rr.choices(rw,k=len(rw)))-statistics.mean(rr.choices(cl,k=len(cl))) for _ in range(300)]
        paired.append({'priority':pri,'rework_minus_clean_h':round(statistics.mean(rw)-statistics.mean(cl),2),'bootstrap_low_h':quantile(deltas,.025),'bootstrap_high_h':quantile(deltas,.975),'bootstrap_resamples':300})
    save('p2p-rework','P2P süreç madenciliği: tekrar işleme ve bekleme','Operasyon','Ödeme süresini hangi aşama uzatıyor; tekrar işleme etkisi öncelik farkından ayrılabiliyor mu?',t,{'branch_priority_rework':q,'stage_wait':q2},{'stratified_uncertainty':paired},['3.000 vaka ve sıralı olay tablosu. LAG pencere fonksiyonu ile her aktiviteye kadar geçen süre hesaplanır.','Birden fazla INVOICE_RECEIVED olayı tekrar işleme işaretidir. Vaka süresi ilk PO_CREATED ile PAID arasıdır; olay satırları bağımsız vaka gibi sayılmaz.','Acil/normal tabakalarında tekrar işleme farkı, vaka bazında 300 bootstrap örnekle %95 aralıkla raporlanır.'],[f"{len(events):,} olay, 3.000 vaka seviyesine indirgendi; tekrar işleme {len(rework_d)} vakada bulundu.",f"Tabaka içi süre farkı: acil {paired[0]['rework_minus_clean_h']} saat, normal {paired[1]['rework_minus_clean_h']} saat."],['Bootstrap vakaların bağımsız olduğunu varsayar; aynı tedarikçiye bağlı kümelenme modellenmedi.','Tekrar işleme gözlemsel bir sınıftır. Süre farkı nedensel maliyet veya kontrol ihlali kanıtı değildir.'],[('Her vaka tek başlangıç ve ödeme olayı içeriyor',sum(e[2]=='PO_CREATED' for e in events)==3000 and sum(e[2]=='PAID' for e in events)==3000),('Olay zamanı vaka içinde monoton',all(all(a[3]<=b[3] for a,b in zip(es,es[1:])) for es in [[e for e in events if e[0]==i] for i in range(1,3001)])),('Bootstrap aralıkları sıralı',all(r['bootstrap_low_h']<=r['bootstrap_high_h'] for r in paired))],'Aktivite beklemelerini vaka seviyesinde ölç; tekrar işleme kuyruğunu öncelik ve şube tabakalarında incele, nedensellik için ayrıca kontrollü müdahale tasarla.')

def sigmoid(x):return 1/(1+math.exp(-max(-30,min(30,x))))
def auc(y,p):
    groups={}
    for label,score in zip(y,p):groups.setdefault(score,[]).append(label)
    rank=1;posrank=0
    for score,labels in sorted(groups.items()):
        posrank+=sum(labels)*(rank+(len(labels)-1)/2);rank+=len(labels)
    pos=sum(y);neg=len(y)-pos
    return (posrank-pos*(pos+1)/2)/(pos*neg) if pos and neg else None
def churn():
    rng=random.Random(SEED+6);customers=[];activity=[];labels=[];features=[]
    for i in range(1,5401):
        month=1+(i-1)//600;visits=rng.randint(0,30);tickets=rng.randint(0,8);tenure=rng.randint(1,48);decline=round(rng.uniform(-1,1),5);prob=sigmoid(-1.3-.06*visits+.18*tickets-.014*tenure+1.5*decline+.07*(month-1));y=int(rng.random()<prob)
        customers.append((i,month,tenure));activity.extend([(i,month-1,visits,tickets,round(decline,5)),(i,month,0 if y else rng.randint(1,20),rng.randint(0,5),0.0)])
        labels.append((i,month,y));features.append((i,month,[visits,tickets,tenure,decline],y))
    train=[r for r in features if r[1]<=5];valid=[r for r in features if r[1] in [6,7]];test=[r for r in features if r[1]>=8]
    means=[statistics.mean(r[2][j] for r in train) for j in range(4)];scales=[statistics.pstdev(r[2][j] for r in train) for j in range(4)]
    def vector(r):return [1]+[(r[2][j]-means[j])/scales[j] for j in range(4)]
    w=[0]*5
    for epoch in range(350):
        grad=[0]*5
        for r in train:
            x=vector(r);err=sigmoid(sum(a*b for a,b in zip(w,x)))-r[3]
            for j in range(5):grad[j]+=err*x[j]
        w=[v-.15*(grad[j]/len(train)+(.01*v if j else 0)) for j,v in enumerate(w)]
    def predict(r):return sigmoid(sum(a*b for a,b in zip(w,vector(r))))
    vp=[predict(r) for r in valid];vy=[r[3] for r in valid];thresholds=[]
    for threshold in [x/100 for x in range(10,81,5)]:
        tp=sum(y and p>=threshold for y,p in zip(vy,vp));fp=sum(not y and p>=threshold for y,p in zip(vy,vp));fn=sum(y and p<threshold for y,p in zip(vy,vp));thresholds.append((2*fn+fp,threshold))
    threshold=min(thresholds)[1];p=[predict(r) for r in test];y=[r[3] for r in test];base=statistics.mean(r[3] for r in train);n=len(y);tp=sum(a and b>=threshold for a,b in zip(y,p));fp=sum(not a and b>=threshold for a,b in zip(y,p));fn=sum(a and b<threshold for a,b in zip(y,p));top=sorted(zip(p,y),reverse=True)[:n//10];bins=[]
    for lo in [0,.2,.4,.6,.8]:
        pairs=[(a,b) for a,b in zip(p,y) if lo<=a<lo+.2]
        if pairs:bins.append({'score_band':f'{lo:.1f}–{lo+.2:.1f}','n':len(pairs),'mean_prediction':round(statistics.mean(a for a,b in pairs),3),'observed_churn':round(statistics.mean(b for a,b in pairs),3)})
    metrics=[{'split':'Gelecek aylar 8–9','n':n,'auc':round(auc(y,p),3),'brier':round(statistics.mean((a-b)**2 for a,b in zip(p,y)),4),'baseline_brier':round(statistics.mean((base-b)**2 for b in y),4),'top_decile_precision_pct':pct(sum(b for a,b in top),len(top)),'prevalence_pct':pct(sum(y),n),'threshold_validation':threshold,'tp':tp,'fp':fp,'fn':fn,'cost_fp_1_fn_2':fp+2*fn}]
    bootstrap=[];rr=random.Random(SEED+66)
    for _ in range(300):
        sample=rr.choices(list(zip(y,p)),k=n);v=auc([a for a,b in sample],[b for a,b in sample]);bootstrap.append(v)
    scored=[(r[0],r[1],round(predict(r),8),'train' if r[1]<=5 else 'validation' if r[1]<=7 else 'test') for r in features]
    t={'customers':([('customer_id','INTEGER PRIMARY KEY'),('prediction_month','INTEGER'),('tenure','INTEGER')],customers),'activity':([('customer_id','INTEGER'),('month','INTEGER'),('visits','INTEGER'),('tickets','INTEGER'),('decline','REAL')],activity),'labels':([('customer_id','INTEGER PRIMARY KEY'),('outcome_month','INTEGER'),('churn','INTEGER')],labels),'scores':([('customer_id','INTEGER PRIMARY KEY'),('prediction_month','INTEGER'),('score','REAL'),('split','TEXT')],scored)}
    q="SELECT split,COUNT(*) AS customers,ROUND(AVG(churn),4) AS churn_rate,ROUND(AVG(score),4) AS average_score FROM scores JOIN labels USING(customer_id) GROUP BY split"
    q2="SELECT c.customer_id,c.prediction_month,c.tenure,a.visits,a.tickets,a.decline FROM customers c JOIN activity a ON a.customer_id=c.customer_id AND a.month=c.prediction_month-1 ORDER BY c.customer_id LIMIT 10"
    save('musteri-churn','Müşteri kaybı: zaman ayrımı ve veri sızıntısı','Müşteri ve pazar','Gelecek aya ait bilgi kullanmadan müşteri kaybını sıralayabilir ve müdahale eşiğini seçebilir miyiz?',t,{'split_summary':q,'past_only_feature_sample':q2},{'holdout_metrics':metrics,'calibration':bins,'auc_bootstrap':[{'resamples':300,'low':quantile(bootstrap,.025),'high':quantile(bootstrap,.975)}],'model':[{'weights':w,'training_means':means,'training_scales':scales,'l2':.01,'epochs':350}]},['5.400 müşteri tek tahmin kesitinde bulunur. Özellikler yalnız önceki aya aittir; sonuç ayı aktiviteleri CSV’de bulunur ama modele girmez.','Ay 1–5 eğitim, 6–7 doğrulama, 8–9 dokunulmamış test. Ölçekleme yalnız eğitim verisinde öğrenilir; L2 lojistik model standart kitaplıkla eğitilir.','FP=1, FN=2 örnek maliyetine göre eşik yalnız doğrulamada seçilir. Testte AUC, Brier, kalibrasyon, ilk %10 hassasiyeti ve 300 müşteri bootstrap AUC aralığı raporlanır.'],[f"Gelecek ay test AUC {metrics[0]['auc']}; Brier {metrics[0]['brier']}, sabit olasılık baz çizgisi {metrics[0]['baseline_brier']}.",f"İlk %10 müşteri diliminde kayıp oranı %{metrics[0]['top_decile_precision_pct']}; tüm test kümesinde %{metrics[0]['prevalence_pct']}. Doğrulamada seçilen eşik {threshold}."],['Müşteri kimlikleri dönemler arasında tekrar etmez; gerçek panel verisinde müşteri ve zaman bağımlılığı ayrıca ele alınmalıdır.','Hedef sentetik bir mekanizmayla üretildi. Tahmin başarısı müdahale etkisini veya gerçek müşteri kaybını önleme yeteneğini kanıtlamaz. FP/FN maliyetleri varsayımsaldır.'],[('Eğitim, doğrulama ve test kimlikleri ayrık',len({r[0] for r in train+valid+test})==5400),('Özellik ayı sonuç ayından önce',all(a[1]<c[1] for c in customers for a in activity if a[0]==c[0] and a[1]==c[1]-1)),('AUC ve olasılıklar geçerli',0<=metrics[0]['auc']<=1 and all(0<=a<=1 for a in p)),('Test kalibrasyon dilimleri tüm test müşterilerini kapsıyor',sum(b['n'] for b in bins)==1200)],'Riski müşteri listesi önceliklendirmek için kullan; maliyet varsayımlarını iş birimiyle belirle ve müdahale etkisini ayrı bir kontrollü deneyle ölç.')

def inventory():
    rng=random.Random(SEED+7);skus=[];demand=[];leads=[];outcomes=[];periods=[]
    for sku in range(1,61):
        rate=rng.uniform(.15,.8);scale=rng.randint(2,9);unit_cost=rng.randint(50,250);skus.append((sku,unit_cost))
        ds=[rng.randint(1,scale) if rng.random()<rate else 0 for _ in range(180)];ls=[rng.randint(2,8) for _ in range(180)]
        demand.extend((sku,day+1,x) for day,x in enumerate(ds));leads.extend((sku,day+1,x) for day,x in enumerate(ls))
        for policy in ['Ortalama talep','Servis tamponu']:
            hist=ds[:120];avg=statistics.mean(hist);std=statistics.pstdev(hist);lt=statistics.mean(ls[:120]);buffer=0 if policy=='Ortalama talep' else 1.65*math.sqrt(lt*std*std+avg*avg*statistics.pvariance(ls[:120]))
            reorder=math.ceil(avg*lt+buffer);target=max(reorder+1,math.ceil(avg*(lt+7)+buffer));onhand=target;orders=[];lost=0;served=0;total=0;holding=0;order_count=0
            for day in range(121,181):
                arrivals=sum(q for due,q in orders if due==day);onhand+=arrivals;orders=[(due,q) for due,q in orders if due>day]
                requested=ds[day-1];filled=min(requested,onhand);onhand-=filled;served+=filled;lost+=requested-filled;total+=requested;holding+=onhand*unit_cost*.0005
                position=onhand+sum(q for due,q in orders)
                quantity=target-position if position<=reorder else 0
                if quantity:orders.append((day+ls[day-1],quantity));order_count+=1
                periods.append((policy,sku,day,requested,filled,onhand,quantity))
                # Rolling estimate uses only observations already revealed on this day.
                hist=ds[max(0,day-60):day];avg=statistics.mean(hist);std=statistics.pstdev(hist);lt=statistics.mean(ls[max(0,day-60):day]);buffer=0 if policy=='Ortalama talep' else 1.65*math.sqrt(lt*std*std+avg*avg*statistics.pvariance(ls[max(0,day-60):day]));reorder=math.ceil(avg*lt+buffer);target=max(reorder+1,math.ceil(avg*(lt+7)+buffer))
            outcomes.append((policy,sku,total,served,lost,round(holding,2),order_count))
    t={'skus':([('sku','INTEGER PRIMARY KEY'),('unit_cost_try','INTEGER')],skus),'demand':([('sku','INTEGER'),('day','INTEGER'),('units','INTEGER')],demand),'lead_time':([('sku','INTEGER'),('day','INTEGER'),('days','INTEGER')],leads),'daily_inventory':([('policy','TEXT'),('sku','INTEGER'),('day','INTEGER'),('requested','INTEGER'),('filled','INTEGER'),('ending_stock','INTEGER'),('order_units','INTEGER')],periods),'outcomes':([('policy','TEXT'),('sku','INTEGER'),('requested','INTEGER'),('filled','INTEGER'),('lost','INTEGER'),('holding_try','REAL'),('orders','INTEGER')],outcomes)}
    q="SELECT policy,COUNT(*) AS skus,SUM(requested) AS requested,SUM(filled) AS filled,SUM(lost) AS lost,ROUND(100.0*SUM(filled)/SUM(requested),2) AS fill_rate_pct,ROUND(SUM(holding_try),2) AS holding_try,SUM(orders) AS orders FROM outcomes GROUP BY policy"
    q2="WITH p AS (SELECT sku,MAX(CASE WHEN policy='Ortalama talep' THEN lost END) AS base_lost,MAX(CASE WHEN policy='Servis tamponu' THEN lost END) AS buffer_lost,MAX(CASE WHEN policy='Ortalama talep' THEN holding_try END) AS base_holding,MAX(CASE WHEN policy='Servis tamponu' THEN holding_try END) AS buffer_holding FROM outcomes GROUP BY sku) SELECT sku,base_lost-buffer_lost AS saved_units,ROUND(buffer_holding-base_holding,2) AS extra_holding_try FROM p ORDER BY saved_units DESC LIMIT 12"
    deltas=[next(r[4] for r in outcomes if r[0]=='Ortalama talep' and r[1]==sku)-next(r[4] for r in outcomes if r[0]=='Servis tamponu' and r[1]==sku) for sku in range(1,61)];interval=ci(deltas,SEED+77)
    save('stok-politika','Stok politikası: kesikli talep ve ileri dönem testi','Operasyon','Servis tamponu kayıp talebi azaltırken ne kadar ek stok maliyeti yaratıyor?',t,{'policy_totals':q,'paired_sku_tradeoff':q2},{'paired_uncertainty':[{'mean_saved_units_per_sku':round(statistics.mean(deltas),3),'bootstrap_low':interval[0],'bootstrap_high':interval[1],'bootstrap_resamples':300,'test_days':60}]},['60 ürünün 180 günlük sıfır ağırlıklı talebi ve sipariş anında bilinen değişken tedarik süreleri. İlk 120 gün başlangıç hesabı, sonraki 60 gün ileri dönem testidir.','İki politika aynı talep ve tedarik süresi yolunu kullanır. Günlük giriş, talep, stok, açık sipariş ve stok pozisyonu izlenir. Kayıp talep geri siparişe çevrilmez.','60 günlük kayan tahmin yalnız o güne kadar açığa çıkan veriyi kullanır. Servis tamponu talep ve tedarik süresi varyansını içerir; 1,65 katsayısı yalnız aday politikadır, garanti değildir.','Servis farkı ürün bazında eşlenir; 300 ürün bootstrap ile ortalama kazanım aralığı. Elde tutma maliyeti günlük stok × birim maliyet × 0,0005 varsayımıdır.'],[f"Aynı talep yollarında ürün başına ortalama {round(statistics.mean(deltas),2)} kayıp talep birimi önlendi; %95 bootstrap aralığı {interval[0]}–{interval[1]}.",'Kazanç ve ilave elde tutma maliyeti birlikte verilir; daha çok stok her ürün için aynı faydayı yaratmaz.'],['Her ürün için tek sentetik talep yolu vardır; bootstrap ürün karması belirsizliğini gösterir, alternatif gelecek senaryolarının tamamını temsil etmez.','Başlangıç stoğu politikalara göre farklıdır; sonuç toplam politika karşılaştırmasıdır. Satın alma nakdi, sipariş sabit maliyeti ve kayıp satış marjı modele dahil değildir.','Tedarik süreleri sipariş anında doğru biliniyor varsayılır; gecikme sürprizi yoktur. Süre örnekleri bağımsızdır; sezon, ortak tedarikçi kesintisi ve kapasite sınırı modellenmez.'],[('Karşılaştırmada talep yolu aynı',all(len({r[2] for r in outcomes if r[1]==sku})==1 for sku in range(1,61))),('Talep karşılanan ve kayıp miktara eşit',all(r[2]==r[3]+r[4] for r in outcomes)),('Negatif stok veya fazla karşılama yok',all(r[5]>=0 and 0<=r[4]<=r[3] for r in periods)),('Test dönemi gün 121–180',min(r[2] for r in periods)==121 and max(r[2] for r in periods)==180)],'Tek bir servis hedefini tüm ürünlere uygulama; ürün bazında kayıp talep kazanımını, ilave stok maliyetini ve iş marjını karşılaştırarak pilot kapsamını seç.')

def entity():
    from difflib import SequenceMatcher
    rng=random.Random(SEED+8);records=[];truth=[];buckets={};identity={};partition={}
    for i in range(1,2001):
        split='train' if i<=1200 else 'validation' if i<=1600 else 'test';city='Bolge'+str(i%10);base=f'Kisi{i%75} Aile{i%50}';mail=f'kisi{i}@example.invalid'
        for j in range(2):
            rid=2*i-1+j;name=base if not j or rng.random()>.35 else base[:-1]+'x';email=mail if not j or rng.random()>.4 else f'kisi{i}x@example.invalid'
            if j and rng.random()<.08:city2='Bolge'+str((i+1)%10)
            else:city2=city
            records.append((rid,name.lower(),email,city2,split));truth.append((rid,i));identity[rid]=i;partition[rid]=split;buckets.setdefault((split,city2,name.split()[0].lower()),[]).append(records[-1])
    pairs=[];positive_candidates=0
    for key,group in buckets.items():
        for index,a in enumerate(group):
            for b in group[index+1:]:
                name_score=SequenceMatcher(None,a[1],b[1]).ratio();email_score=SequenceMatcher(None,a[2],b[2]).ratio();score=round(.65*name_score+.35*email_score,6);same=int(identity[a[0]]==identity[b[0]]);positive_candidates+=same;pairs.append((a[0],b[0],key[0],score,same))
    val=[p for p in pairs if p[2]=='validation'];costs=[]
    for threshold in [x/1000 for x in range(900,1001,5)]:
        fp=sum(not p[4] and p[3]>=threshold for p in val);fn=sum(p[4] and p[3]<threshold for p in val);costs.append((10*fp+fn,threshold))
    threshold=min(costs)[1];test=[p for p in pairs if p[2]=='test'];tp=sum(p[4] and p[3]>=threshold for p in test);fp=sum(not p[4] and p[3]>=threshold for p in test);fn=sum(p[4] and p[3]<threshold for p in test);candidate_true=sum(p[4] for p in test)
    parents={r[0]:r[0] for r in records if r[4]=='test'}
    def find(x):
        while parents[x]!=x:parents[x]=parents[parents[x]];x=parents[x]
        return x
    for a,b,split,s,real in test:
        if s>=threshold:parents[find(a)]=find(b)
    groups={}
    for rid in parents:groups.setdefault(find(rid),set()).add(identity[rid])
    impure=sum(len(ids)>1 for ids in groups.values());scored=[(a,b,sp,s,truthlabel,int(s>=threshold)) for a,b,sp,s,truthlabel in pairs]
    t={'records':([('record_id','INTEGER PRIMARY KEY'),('normalized_name','TEXT'),('email','TEXT'),('city','TEXT'),('split','TEXT')],records),'identity_truth':([('record_id','INTEGER PRIMARY KEY'),('entity_id','INTEGER')],truth),'candidate_scores':([('left_id','INTEGER'),('right_id','INTEGER'),('split','TEXT'),('score','REAL'),('same_entity','INTEGER'),('suggested_match','INTEGER')],scored)}
    q="SELECT split,COUNT(*) AS candidate_pairs,SUM(same_entity) AS true_pairs,SUM(suggested_match AND same_entity) AS tp,SUM(suggested_match AND NOT same_entity) AS fp,SUM(NOT suggested_match AND same_entity) AS fn FROM candidate_scores GROUP BY split"
    q2="SELECT a.record_id AS left_id,b.record_id AS right_id FROM records a JOIN records b ON a.city=b.city AND a.split=b.split AND substr(a.normalized_name,1,instr(a.normalized_name,' ')-1)=substr(b.normalized_name,1,instr(b.normalized_name,' ')-1) AND a.record_id<b.record_id ORDER BY a.record_id,b.record_id LIMIT 10"
    metrics=[{'threshold_validation':threshold,'test_true_duplicate_pairs':400,'candidate_true_pairs':candidate_true,'blocking_recall_pct':pct(candidate_true,400),'precision_pct':pct(tp,tp+fp),'recall_within_candidates_pct':pct(tp,tp+fn),'end_to_end_recall_pct':pct(tp,400),'tp':tp,'fp':fp,'fn_within_candidates':fn,'missed_by_blocking':400-candidate_true,'impure_connected_components':impure}]
    save('veri-eslestirme','Veri kalitesi: kayıt eşleştirme ve yanlış birleşme','Veri ve finans','Benzer kayıtları birleştirirken kaç gerçek eşleşme kaçıyor ve zincirleme yanlış birleşme riski ne?',t,{'split_confusion':q,'blocking_sample':q2},{'test_matching':metrics},['2.000 sentetik kimliğe ait 4.000 kayıt; ad, e-posta ve bölge değişimleri. Adaylar aynı bölge ve aynı ilk ad bloğunda üretilir.','Kimlikler eğitim/doğrulama/test arasında ayrıdır. Etiketler yalnız değerlendirmede kullanılır; skor %65 ad + %35 e-posta benzerliğidir. Eğitimli model değil, sabit bir benzerlik kuralıdır.','Eşik doğrulamada yanlış birleşmeye 10, kaçan eşleşmeye 1 örnek maliyetle seçilir. Testte aday içi recall ile uçtan uca recall ayrı verilir.','Önerilen eşleşmelerin bağlı bileşenleri kontrol edilerek farklı kimliklerin aynı kümeye girmesi sayılır. Çift seviyesinde precision küme güvenliğini tek başına kanıtlamaz.'],[f"Test aday üretimi gerçek çiftlerin %{pct(candidate_true,400)} kadarını buldu. Seçilen eşik {threshold}; uçtan uca recall %{pct(tp,400)}.",f"Testte {fp} yanlış çift önerisi ve {impure} farklı kimlik içeren bağlı bileşen bulundu; bu kayıtlar otomatik birleştirme için güvenli kabul edilmez."],['Sentetik isim tekrarları ve hata biçimleri gerçek nüfusu temsil etmez. Doğrulama maliyetleri varsayımsaldır.','Farklı bölgeler blok dışında kaldığından gerçek eşleşmeler kaçabilir. Test havuzları ayrı üretildi; üretimde bölgeler ve dönemler arası aday kapsamı ayrıca ölçülmelidir.','Bağlı bileşenler yalnız risk analizi için oluşturulur; gerçek müşteri kaydı birleştirilmez.'],[('4.000 kayıt ve 2.000 kimlik korunuyor',len(records)==4000 and len(set(identity.values()))==2000),('Aday çiftleri tekil ve yönü sıralı',len({(p[0],p[1]) for p in pairs})==len(pairs) and all(p[0]<p[1] for p in pairs)),('Eşik test etiketleri kullanılmadan seçilmiş',all(p[2]=='validation' for p in val)),('Aday içi recall ile uçtan uca recall ayrılıyor',tp<=candidate_true<=400)],'Benzerlik skorunu inceleme kuyruğu üretmek için kullan; düşük riskli çiftlerde dahi bağlı bileşen kontrolü ve kullanıcı onayı olmadan kalıcı birleştirme yapma.')

if __name__=='__main__':
    OUT.mkdir(exist_ok=True)
    for fn in [invoice,retries,capacity,reconciliation,process,churn,inventory,entity]:
        fn();print('OK',studies[-1]['slug'],sum(studies[-1]['tables'].values()),'rows')
    (ROOT/'catalog.json').write_text(json.dumps(studies,ensure_ascii=False,indent=2),encoding='utf-8')
    print('All',sum(len(s['checks']) for s in studies),'study checks passed.')
