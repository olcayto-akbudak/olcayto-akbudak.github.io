"""Reproduce independent synthetic cases using reusable, documented methods."""
import json, math, random, statistics
from pathlib import Path
import build_advanced as base
from specs import specifications

ROOT=Path(__file__).resolve().parent
BASE=json.loads((ROOT/'baseline.json').read_text(encoding='utf-8'))

def quantile(values,p):
    xs=sorted(values); position=(len(xs)-1)*p; low=int(position)
    return xs[low]+(xs[min(low+1,len(xs)-1)]-xs[low])*(position-low)

def interval(values,rng,rounds=250):
    means=[statistics.mean(rng.choices(values,k=len(values))) for _ in range(rounds)]
    return [round(quantile(means,.025),4),round(quantile(means,.975),4)]

def store(s,tables,queries,extra,method,findings,limits,checks,question):
    method += ['Birim kimliği, ilişki anahtarı ve satır düzeyi veri sözleşmesinde açıkça tutulur. SQL önce analiz birimini oluşturur; çoklu tablo satırları bağımsız gözlem gibi sayılmaz. Eksik sonuç ve gerçek sıfır aynı anlama gelmez.',
               'Sonuçlar sabit tohumlu sentetik senaryodan hesaplanır. Kaynak CSV, şema, SQL sorgusu, parametreler ve tam çıktılar aynı pakette bulunur; yeniden üretim karşılaştırması sayfa metnindeki rakamların kaynakla tutarlılığını denetler.']
    limits += [s['risk']+'.','Bu çalışma üretime hazır bir karar sistemi değildir. Pilot öncesinde veri sahibi, iş birimi ve teknik ekip ölçüm tanımını, yanlış karar maliyetini ve geri dönüş koşulunu birlikte belirlemelidir.']
    decision=s['decision']+'. Önce küçük kapsamlı bir pilot uygula; baz çizgiyle aynı analiz biriminde karşılaştır. Etki, belirsizlik ve yan etki ölçütlerini ayrı izle. Başarı eşiği ihlal edilirse yayılımı durdur ve veri kalitesi ile varsayımları yeniden değerlendir.'
    base.save(s['slug'],s['title'],s['category'],question,tables,queries,extra,method,findings,limits,checks,decision)
    rec=base.studies[-1];rec.update(family=s['family'],unit=s['unit'],seed=s['seed'],method_short=SHORT[s['family']])
    folder=base.OUT/s['slug']
    (folder/'contract.json').write_text(json.dumps({'seed':s['seed'],'family':s['family'],'variant':s['variant'],'unit':s['unit'],'data_type':'synthetic','schema':{n:cols for n,(cols,rows) in tables.items()},'source_rows':rec['tables']},ensure_ascii=False,indent=2),encoding='utf-8')
    readme=(folder/'README.md').read_text(encoding='utf-8').replace('`python build_advanced.py`','`python build_expansion.py`')
    readme+='\n\n## Veri sözleşmesi\n`contract.json` analiz birimi, kolon tipleri, satır sayıları ve sabit tohumu kaydeder. SQL SQLite sözdizimindedir. Takvim ve oran eşikleri bu sentetik senaryonun varsayımlarıdır.\n'
    (folder/'README.md').write_text(readme,encoding='utf-8')

SHORT={'experiment':'Eşlenmiş politika · bootstrap · maliyet duyarlılığı','did':'Panel veri · farkların farkı · placebo · küme bootstrap','survival':'Kaplan–Meier · sağ sansür · RMST · risk kümesi','optimization':'Tam arama · min-max · bağımlılık · bütçe duyarlılığı','forecast':'İleri dönem · kayan başlangıç · baz çizgi · WAPE','risk':'Ortak şok · eşlenmiş senaryo · VaR / CVaR · prim duyarlılığı'}

def experiment(s,rng):
    j=s['variant'];n=800+j*40;units=[];events=[];paired=[]
    p=.08+j*.009;eff=.18+(j%5)*.1
    for i in range(n):
        segment='Yoğun' if i%3==0 else 'Normal';risk=min(.8,p*(1.8 if segment=='Yoğun' else .75));u=rng.random()
        a=int(u<risk);b=int(u<risk*(1-eff));units.append((i,segment,round(risk,6)))
        events.extend([(i,'Baz çizgi',a),(i,'Aday politika',b)]);paired.append(a-b)
    q='SELECT policy,segment,COUNT(*) AS units,SUM(adverse) AS adverse_events,ROUND(100.0*AVG(adverse),3) AS adverse_pct FROM outcomes JOIN units USING(unit_id) GROUP BY policy,segment ORDER BY policy,segment'
    overall='SELECT policy,COUNT(*) AS units,SUM(adverse) AS adverse_events,ROUND(100.0*AVG(adverse),3) AS adverse_pct FROM outcomes GROUP BY policy ORDER BY policy'
    lo,hi=interval(paired,rng);avoided=sum(paired);cost=[]
    for loss in [50,200,800]:
        for overhead in [.5,2,8]:cost.append({'olay_maliyeti':loss,'birim_kontrol_maliyeti':overhead,'onlenen_olay':avoided,'net_ornek_deger':round(avoided*loss-n*overhead,2)})
    t={'units':([('unit_id','INTEGER PRIMARY KEY'),('segment','TEXT'),('latent_risk','REAL')],units),'outcomes':([('unit_id','INTEGER'),('policy','TEXT'),('adverse','INTEGER')],events)}
    checks=[('Her birim iki politikada bir kez bulunur',len(events)==2*n and len(set((x[0],x[1]) for x in events))==2*n),('Önlenen olay doğrudan politika toplamı farkına eşit',avoided==sum(x[2] for x in events if x[1]=='Baz çizgi')-sum(x[2] for x in events if x[1]=='Aday politika')),('Eşlenmiş fark ve bootstrap aralığı geçerli',all(x in (0,1) for x in paired) and 0<=lo<=hi<=1)]
    store(s,t,{'policy_summary':overall,'segment_summary':q},{'paired_effect':[{'birim':n,'onlenen_olay':avoided,'azalma_yuzde_puan':round(100*statistics.mean(paired),3),'alt_95_yuzde_puan':round(lo*100,3),'ust_95_yuzde_puan':round(hi*100,3)}],'cost_sensitivity':cost},
    [f'Analiz birimi bağımsız işlem örneğidir. {n} işlem, normal ve yoğun segmentte aynı rastgele olay çekilişiyle iki politikada eşlenir. Temel olay olasılığı {p:.3f}, aday azaltım katsayısı {eff:.2f}; bunlar veri üretim varsayımıdır.',
     'Birim başına olumsuz sonuç 0/1 olarak tutulur. Etki baz çizgi eksi aday politika şeklindedir; pozitif değer daha az olumsuz olay anlamına gelir. Segment ve toplam oranlar ayrı raporlanır.',
     '250 bootstrap tekrarında politika satırları ayrı çekilmez; iki sonuç aynı birimle birlikte yeniden örneklenir. Yüzdelik aralık eşlenmiş ortalama farkın belirsizliğini gösterir.',
     'Kontrol maliyeti her işleme uygulanır. Net örnek değer = önlenen olay × varsayımsal olay maliyeti − işlem sayısı × kontrol maliyeti. Farklı maliyet çiftleri tek bir olumlu senaryoya bağımlılığı gösterir.'],
    [f'{n} eşlenmiş işlemde {avoided} olumsuz olay önlendi. Azalma {round(100*statistics.mean(paired),3)} yüzde puan; %95 bootstrap aralığı {round(lo*100,3)}–{round(hi*100,3)} yüzde puan.',f'Maliyet duyarlılığında net değer {min(x["net_ornek_deger"] for x in cost)} ile {max(x["net_ornek_deger"] for x in cost)} arasında değişiyor. Olay azalması tek başına ekonomik onay gerekçesi değildir.'],
    ['Aday politikanın faydası veri üretim mekanizmasında varsayılmıştır. Bu eşlenmiş simülasyon gerçek rastgele kontrollü deneyin yerine geçmez. Gerçek uygulamada kullanıcı, gün veya tenant bazında kümelenme değerlendirilmelidir.','Gizli risk kolonu yalnız sentetik üretim açıklaması içindir; üretimde gözlenebilir özellik veya karar girdisi olarak kullanılamaz.'],checks,f'{s["unit"].capitalize()} için aday kontrolün etkisi segment ve kontrol maliyeti değişince hâlâ anlamlı mı?')

def did(s,rng):
    j=s['variant'];units=[];obs=[];effects=[];placebos=[];slope=.018*(j%4);effect=-(1.2+j*.21)
    for i in range(48):
        tr=int(i<24);level=rng.uniform(8,20);units.append((i,tr,'Kuzey' if i%2 else 'Güney'));ys=[]
        for day in range(40):
            y=level+.08*day+math.sin(day/4)+tr*slope*day+(effect if tr and day>=20 else 0)+rng.gauss(0,.7)
            obs.append((i,day,int(day>=20),round(y,5)));ys.append(y)
        delta=statistics.mean(ys[20:])-statistics.mean(ys[:20]);placebo=statistics.mean(ys[10:20])-statistics.mean(ys[:10]);effects.append((tr,delta));placebos.append((tr,placebo))
    treated=[v for tr,v in effects if tr];control=[v for tr,v in effects if not tr];estimate=statistics.mean(treated)-statistics.mean(control)
    boot=[statistics.mean(rng.choices(treated,k=24))-statistics.mean(rng.choices(control,k=24)) for _ in range(250)];lo=quantile(boot,.025);hi=quantile(boot,.975)
    placebo=statistics.mean(v for tr,v in placebos if tr)-statistics.mean(v for tr,v in placebos if not tr)
    q='SELECT treated,post,COUNT(DISTINCT unit_id) AS units,COUNT(*) AS observations,ROUND(AVG(outcome),4) AS average FROM observations JOIN units USING(unit_id) GROUP BY treated,post ORDER BY treated,post'
    q2='SELECT treated,day,ROUND(AVG(outcome),4) AS average FROM observations JOIN units USING(unit_id) GROUP BY treated,day ORDER BY treated,day'
    t={'units':([('unit_id','INTEGER PRIMARY KEY'),('treated','INTEGER'),('region','TEXT')],units),'observations':([('unit_id','INTEGER'),('day','INTEGER'),('post','INTEGER'),('outcome','REAL')],obs)}
    sensitivity=[{'varsayilan_gunluk_trend_farki':v,'trend_duzeltilmis_fark':round(estimate-20*v,4)} for v in [0,.02,.04,.06]]
    store(s,t,{'period_summary':q,'daily_panel':q2},{'did_result':[{'farklarin_farki':round(estimate,4),'alt_95':round(lo,4),'ust_95':round(hi,4),'once_donem_placebo':round(placebo,4),'uretilen_mudahale_etkisi':round(effect,4),'uretilen_trend_farki':slope}],'trend_sensitivity':sensitivity},
    ['48 analiz biriminin 40 günlük paneli oluşturulur. İlk 20 gün müdahale öncesi, sonraki 20 gün sonrasıdır. Müdahale ve kontrol grupları 24’er birim içerir; ortak günlük şok ve birime özgü seviyeler vardır.',
     'Tahmin müdahale grubunun önce/sonra farkından kontrol grubunun farkını çıkarır. Ham grup seviyeleri etki olarak yorumlanmaz. Günlük gözlemler aynı birimde bağımlı olduğundan belirsizlik birim düzeyinde hesaplanır.',
     '250 bootstrap tekrarında birimlerin tüm zaman farkı birlikte çekilir. Ön dönemin iki yarısı arasında placebo farkı ve günlük trend tablosu hesaplanır; ön dönem sapması paralel trend varsayımı için uyarıdır.',
     f'Bu senaryoda müdahale grubuna günlük {slope:.3f} ek trend verilmiştir. Trend duyarlılığı, gün başına 0–0,06 olası fark için 20 günlük ortalama dönem uzaklığını kullanır. Bilinen sentetik müdahale katsayısı değerlendirme için ayrıca gösterilir.'],
    [f'Farkların farkı {estimate:.4f}; birim bootstrap %95 aralığı {lo:.4f}–{hi:.4f}. Ön dönem placebo farkı {placebo:.4f}.',f'Sentetik müdahale katsayısı {effect:.4f}, gruba özgü trend {slope:.3f}. Tahminin doğru işareti veya dar aralığı, trend varsayımındaki hatayı ortadan kaldırmaz.'],
    ['Paralel trend yoksa farkların farkı nedensel etki değildir. Bu çalışma varsayım ihlalini görünür kılar; placebo küçük çıksa bile varsayım kanıtlanmış olmaz.','Birimler arasında yayılım, müdahale zamanındaki seçilim ve eşzamanlı başka değişimler modele dahil değildir. Metrik sentetik süre birimidir; gerçek kurumdaki zaman ölçümü ayrıca tanımlanmalıdır.'],
    [('Her birimde tam zaman paneli var',len(obs)==48*40 and len({(x[0],x[1]) for x in obs})==48*40),('Gruplar dengeli',sum(x[1] for x in units)==24),('Ön ve son dönem ayrımı tutarlı',all(x[2]==int(x[1]>=20) for x in obs)),('Bootstrap aralığı sıralı',lo<=hi)],f'{s["unit"].capitalize()} değişimi ortak dönem etkisi ve müdahale öncesi trendden ayrılabiliyor mu?')

def km(rows,horizon=48):
    at=len(rows);surv=1.;last=0.;area=0.;curve=[]
    for time in sorted({t for t,e in rows if t<=horizon}):
        area+=surv*(time-last);d=sum(t==time and e for t,e in rows);c=sum(t==time and not e for t,e in rows)
        if d:surv*=1-d/at
        curve.append({'zaman_saat':time,'risk_kumesi':at,'olay':d,'sansur':c,'olaysiz_kalma':round(surv,6)})
        at-=d+c;last=time
    area+=surv*(horizon-last)
    return curve,area,surv

def survival(s,rng):
    j=s['variant'];rows=[];units=[]
    for i in range(600):
        group='A' if i<300 else 'B';scale=(10+j*1.1)*(1.3 if group=='B' else 1);duration=rng.weibullvariate(scale,1.25+(j%3)*.25);censor=rng.uniform(12,60)
        t=round(min(duration,censor),3);event=int(duration<=censor);rows.append((i,t,event));units.append((i,group))
    out=[];curves=[];groups=[]
    for group in ['A','B']:
        ids={i for i,g in units if g==group};data=[(t,e) for i,t,e in rows if i in ids];curve,area,sv=km(data);curves.extend(dict(grup=group,**r) for r in curve);groups.append(data)
        med=next((x['zaman_saat'] for x in curve if x['olaysiz_kalma']<=.5),None)
        out.append({'grup':group,'gözlem':len(data),'olay':sum(e for t,e in data),'sansur':sum(not e for t,e in data),'KM_medyan_saat':med,'RMST_48_saat':round(area,4),'48_saat_olaysiz_oran':round(sv,4)})
    boot=[km(rng.choices(groups[1],k=300))[1]-km(rng.choices(groups[0],k=300))[1] for _ in range(120)]
    lo=quantile(boot,.025);hi=quantile(boot,.975)
    q='SELECT group_name,COUNT(*) AS units,SUM(event) AS events,SUM(1-event) AS censored,ROUND(AVG(CASE WHEN event=1 THEN observed_hours END),4) AS completed_mean_hours FROM units JOIN followup USING(unit_id) GROUP BY group_name ORDER BY group_name'
    q2='SELECT group_name,CAST(observed_hours/12 AS INTEGER) AS time_band,COUNT(*) AS units,SUM(event) AS events FROM units JOIN followup USING(unit_id) GROUP BY group_name,time_band ORDER BY group_name,time_band'
    t={'units':([('unit_id','INTEGER PRIMARY KEY'),('group_name','TEXT')],units),'followup':([('unit_id','INTEGER PRIMARY KEY'),('observed_hours','REAL'),('event','INTEGER')],rows)}
    store(s,t,{'censor_summary':q,'observed_bands':q2},{'survival_summary':out,'rmst_difference':[{'B_eksi_A_saat':round(out[1]['RMST_48_saat']-out[0]['RMST_48_saat'],4),'alt_95':round(lo,4),'ust_95':round(hi,4),'ufuk_saat':48}],'km_curve':curves},
    ['600 birim A/B kohortlarında izlenir. Sonuç zamanı ve bağımsız gözlem sonu üretilir; gözlenen süre ikisinin küçüğüdür. Olay göstergesi sonucun gözlem penceresi içinde gerçekleşip gerçekleşmediğini bildirir.',
     'Kaplan–Meier hesabında aynı zamandaki olaylar sansürlerden önce risk kümesine uygulanır. Sansürlü kayıt olay olmuş gibi sayılmaz ve listeden doğrudan atılmaz. Tamamlananların ortalaması yalnız tamamlanan alt kümeyi anlatır.',
     '48 saatlik kısıtlı ortalama olay bekleme süresi (RMST), olaysız kalma eğrisinin 0–48 arasındaki alanıdır. Eğri %50’yi geçmezse medyan hesaplanamaz; boş değer sıfıra çevrilmez.',
     'Kohortlar içinde 120 birim bootstrap ile B eksi A RMST farkının yüzdelik aralığı hesaplanır. Kuyruk farkı ve olay türü birlikte yorumlanmalıdır; yeniden açılma çalışmasında olay oluşması olumsuz, diğerlerinde süreç sonlanmasıdır.'],
    [f'A kohortu RMST {out[0]["RMST_48_saat"]} saat, B {out[1]["RMST_48_saat"]} saat. Farkın %95 aralığı {lo:.4f}–{hi:.4f} saat.',f'600 gözlemin {sum(not e for i,t,e in rows)} tanesi sağ sansürlü. Tamamlanan ortalama ile bütün kohortun bekleme eğrisi ayrı sonuçlardır.'],
    ['Bağımsız sansür varsayımı ihlal edilirse eğri yanlı olabilir. Uzun süreçlerin özellikle gözlem dışına çıkması için başka bir model gerekir.','Kohort ataması gerçek rastgele deney değildir; kohort farkı nedensel performans kanıtı olarak sunulmaz. 48 saatlik ufuk mevzuat veya hizmet taahhüdü değildir.'],
    [('Her birimde tek izleme kaydı var',len(rows)==600 and len(set(r[0] for r in rows))==600),('Olay ve sansür kohort toplamını koruyor',all(x['olay']+x['sansur']==300 for x in out)),('Eğri monoton ve olasılık sınırında',all(0<=x['olaysiz_kalma']<=1 for x in curves) and all(all(a['olaysiz_kalma']>=b['olaysiz_kalma'] for a,b in zip([x for x in curves if x['grup']==g],[x for x in curves if x['grup']==g][1:])) for g in ['A','B'])),('RMST ufku aşmıyor',all(0<=x['RMST_48_saat']<=48 for x in out))],f'{s["unit"].capitalize()} için henüz sonuçlanmayan kayıtları atmak gecikme değerlendirmesini nasıl değiştiriyor?')

def optimization(s,rng):
    j=s['variant'];items=[];values=[];deps=[]
    for i in range(12):
        cost=rng.randint(8,25);hours=rng.randint(4,18);items.append((i,cost,hours));central=rng.randint(18,65)
        for scenario in range(4):values.append((i,scenario,round(central*rng.uniform(.4,1.6),3)))
        if i in [3,7,11]:deps.append((i,i-1))
    lookup={(i,k):v for i,k,v in values};budget=80+j*3;time=55+j*2
    def score(mask):return min(sum(lookup[i,k] for i in range(12) if mask>>i&1) for k in range(4))
    def feasible(mask,b,t):return sum(c for i,c,h in items if mask>>i&1)<=b and sum(h for i,c,h in items if mask>>i&1)<=t and all(not(mask>>i&1) or mask>>d&1 for i,d in deps)
    results=[]
    for mult in [.8,1,1.2]:
        b=int(budget*mult);t=int(time*mult);valid=[m for m in range(4096) if feasible(m,b,t)];best=max(valid,key=lambda m:(score(m),-sum(c for i,c,h in items if m>>i&1),-m))
        results.append({'butce':b,'saat':t,'secili_isler':','.join(str(i) for i in range(12) if best>>i&1),'harcanan':sum(c for i,c,h in items if best>>i&1),'kullanilan_saat':sum(h for i,c,h in items if best>>i&1),'en_kotu_deger':round(score(best),3),'uygun_kombinasyon':len(valid),'mask':best})
    greedy=0
    for i,c,h in sorted(items,key=lambda r:-(sum(lookup[r[0],k] for k in range(4))/4)/r[1]):
        trial=greedy|1<<i
        for node,parent in deps:
            if node==i:trial|=1<<parent
        if feasible(trial,budget,time):greedy=trial
    q='SELECT scenario,COUNT(*) AS items,ROUND(SUM(value),3) AS unconstrained_value FROM scenario_values GROUP BY scenario ORDER BY scenario'
    q2='SELECT item_id,cost,hours,ROUND(AVG(value),3) AS average_value FROM items JOIN scenario_values USING(item_id) GROUP BY item_id,cost,hours ORDER BY item_id'
    t={'items':([('item_id','INTEGER PRIMARY KEY'),('cost','INTEGER'),('hours','INTEGER')],items),'scenario_values':([('item_id','INTEGER'),('scenario','INTEGER'),('value','REAL')],values),'dependencies':([('item_id','INTEGER'),('requires_id','INTEGER')],deps)}
    store(s,t,{'scenario_summary':q,'item_summary':q2},{'budget_sensitivity':[{k:v for k,v in x.items() if k!='mask'} for x in results],'greedy_comparison':[{'exact_worst':results[1]['en_kotu_deger'],'greedy_worst':round(score(greedy),3),'worst_value_gap':round(results[1]['en_kotu_deger']-score(greedy),3)}]},
    ['12 aday iş için maliyet ve uygulama saati tutulur. Dört değer senaryosu aynı adayların olası iş puanlarını içerir. Üç iş başka bir işin seçilmesine bağımlıdır; bağımlı iş tek başına uygulanamaz.',
     '4096 alt kümenin tamamı taranır. Maliyet, saat ve ön koşul kısıtlarını sağlayan kümenin dört senaryodaki toplam değerinin en küçüğü amaç fonksiyonudur. Senaryoların ayrı ayrı en iyi setleri birlikte uygulanabilir tek set sayılmaz.',
     'Baz bütçenin %80, %100 ve %120 seviyelerinde çözüm yeniden bulunur. Eşit değerlerde düşük maliyet ve sonra küçük maskeyle deterministik seçim yapılır. Kaynak artışının marjinal kazanımı bu taramadan değerlendirilir.',
     'Ortalama değer / maliyet oranına dayalı açgözlü kural aynı saat ve bağımlılık kısıtlarıyla uygulanır. Tam arama sonucu ile fark, basit sıralamanın dayanıklı amaç için kaçırdığı değeri gösterir.'],
    [f'Baz bütçede tam arama en kötü senaryo değerini {results[1]["en_kotu_deger"]} yaptı. Seçilen işler: {results[1]["secili_isler"]}. Maliyet {results[1]["harcanan"]}/{budget}, saat {results[1]["kullanilan_saat"]}/{time}.',f'Açgözlü seçim değeri {score(greedy):.3f}; tam arama farkı {results[1]["en_kotu_deger"]-score(greedy):.3f}. Bütçe duyarlılığı farklı uygulanabilir kümeleri gösterir.'],
    ['Min-max yaklaşımı senaryoların tamamını eşit olasılıklı saymaz; en kötü değeri korumayı seçer. Senaryo kapsamı yetersizse dayanıklılık yanıltıcı olabilir.','Değer puanları sentetiktir ve para getirisi değildir. Kaynak miktarı, iş sinerjileri ve senaryo içindeki bağımlılıklar gerçek planlama için ayrıca kalibre edilmelidir. Tam arama bu küçük aday havuzu içindir.'],
    [('Tam arama bütün alt kümeleri kapsıyor',2**len(items)==4096),('Seçili setler bütçe, saat ve bağımlılığı koruyor',all(feasible(x['mask'],x['butce'],x['saat']) for x in results)),('Bütçe büyüyünce optimum değer azalmaz',all(a['en_kotu_deger']<=b['en_kotu_deger'] for a,b in zip(results,results[1:]))),('Tam arama aynı kısıtta açgözlüden kötü değil',results[1]['en_kotu_deger']+1e-6>=score(greedy))],f'{s["unit"].capitalize()} seçimi bütçe, uygulama saati ve ön koşullar birlikte değişince hangi setle dayanıklı kalır?')

def forecast(s,rng):
    j=s['variant'];series=[];obs=[];pred=[];selection=[]
    def estimate(xs,day,weeks):
        history=[xs[t] for t in range(max(0,day-weeks*7),day) if t%7==day%7]
        return statistics.mean(history)
    for k in range(6):
        series.append((k,'Yoğun' if k<2 else 'Normal'));xs=[]
        for day in range(180):
            level=18+k*7+j*2;season=1.35 if day%7 in (4,5) else .85;shift=(1+.015*j) if day>=130 else 1
            value=max(0,round((level+day*.03*(j%3))*season*shift+rng.gauss(0,4+j*.4)))
            if j%4==0 and rng.random()<.12:value=0
            xs.append(value);obs.append((k,day+1,value))
        validation=[]
        for weeks in [2,4,8]:validation.append((sum(abs(xs[d]-estimate(xs,d,weeks)) for d in range(90,120)),weeks))
        chosen=min(validation)[1];selection.append({'seri':k,'dogrulamada_secilen_hafta':chosen,'dogrulama_MAE':round(min(validation)[0]/30,4)})
        for day in range(120,180):
            for name,yhat in [('Haftalık naive',xs[day-7]),('Doğrulanan mevsim ortalaması',estimate(xs,day,chosen))]:pred.append((k,day+1,name,xs[day],round(yhat,6),round(abs(xs[day]-yhat),6)))
    q='SELECT model,COUNT(*) AS predictions,ROUND(AVG(abs_error),4) AS mae,ROUND(100.0*SUM(abs_error)/NULLIF(SUM(actual),0),4) AS wape_pct,ROUND(AVG(forecast-actual),4) AS bias FROM predictions GROUP BY model ORDER BY model'
    q2='SELECT model,series_id,ROUND(AVG(abs_error),4) AS mae,ROUND(100.0*SUM(abs_error)/NULLIF(SUM(actual),0),4) AS wape_pct FROM predictions GROUP BY model,series_id ORDER BY model,series_id'
    t={'series':([('series_id','INTEGER PRIMARY KEY'),('segment','TEXT')],series),'observations':([('series_id','INTEGER'),('day','INTEGER'),('volume','INTEGER')],obs),'predictions':([('series_id','INTEGER'),('day','INTEGER'),('model','TEXT'),('actual','INTEGER'),('forecast','REAL'),('abs_error','REAL')],pred)}
    totals=[]
    for name in ['Haftalık naive','Doğrulanan mevsim ortalaması']:
        ps=[x for x in pred if x[2]==name];totals.append({'model':name,'MAE':round(statistics.mean(x[5] for x in ps),4),'WAPE_yuzde':round(100*sum(x[5] for x in ps)/sum(x[3] for x in ps),4),'sapma':round(statistics.mean(x[4]-x[3] for x in ps),4)})
    store(s,t,{'forecast_summary':q,'series_errors':q2},{'model_selection':selection,'computed_metrics':totals},
    ['Altı serinin 180 günlük hacmi üretilir; haftalık desen, seri seviyesi, gürültü ve bazı senaryolarda sıfır günler vardır. Gün 130 sonrası düzey değişimi veri üretiminde kullanılır, tahmin modeline gelecek bilgisi olarak verilmez.',
     'Gün 1–90 başlangıç geçmişi, 91–120 doğrulama, 121–180 ileri dönem testidir. Mevsim ortalaması için 2, 4, 8 haftalık pencereler yalnız doğrulama MAE ile seçilir; testte yeniden model seçimi yapılmaz.',
     'Her test gününde yalnız önceki günlere ait gerçekleşmeler kullanılır. Önceki test gününün ortaya çıkmış verisi sonraki tahminde kullanılabilir; bu kayan başlangıç değerlendirmesidir, sabit başlangıçtan 60 gün tahmini değildir.',
     'Haftalık naive baz çizgi geçen haftanın aynı gününü kullanır. MAE, toplam mutlak hatanın toplam gerçekleşmeye bölündüğü WAPE ve imzalı sapma birlikte ölçülür. Sıfır gözlemler yüzdesel tekil hata hesabıyla atılmaz.'],
    [f'İleri dönem testinde mevsim ortalaması WAPE %{totals[1]["WAPE_yuzde"]}; haftalık naive %{totals[0]["WAPE_yuzde"]}. MAE sırasıyla {totals[1]["MAE"]} ve {totals[0]["MAE"]}.',f'Pencere seçimi seri başına doğrulamada yapıldı: {", ".join(str(x["dogrulamada_secilen_hafta"]) for x in selection)} hafta. Baz çizgiye üstünlük her senaryoda garanti edilmez.'],
    ['Sentetik dönem değişimi ve gürültü gerçek talebi temsil etmez. Hacim tahmininin iyi olması kapasite veya personel kararının optimal olduğu anlamına gelmez.','Seriler bağımsız üretilmiştir; ortak müşteri, kampanya ve tatil etkileri yoktur. Gerçek kullanımda sezon dışı test, veri kayması ve tahmin belirsizliği ayrıca değerlendirilmelidir.'],
    [('İleri dönem test günleri korunuyor',min(x[1] for x in pred)==121 and max(x[1] for x in pred)==180),('Her model aynı gerçekleşmeleri kullanıyor',len(pred)==6*60*2 and all(len({x[3] for x in pred if x[0]==k and x[1]==d})==1 for k in range(6) for d in range(121,181))),('Tahminler ve mutlak hatalar geçerli',all(x[4]>=0 and x[5]>=0 for x in pred)),('Pencere yalnız doğrulama aralığında seçiliyor',all(x['dogrulamada_secilen_hafta'] in [2,4,8] for x in selection))],f'{s["unit"].capitalize()} hacminde doğrulamada seçilen tahmin modeli gelecek dönemde basit haftalık baz çizgiyi geçiyor mu?')

def tail(values):
    xs=sorted(values);k=math.ceil(.95*len(xs));return xs[k-1],statistics.mean(xs[k-1:])

def risk(s,rng):
    j=s['variant'];assets=[];losses=[];scenarios=[];totals=[]
    for a in range(12):assets.append((a,rng.randint(1000,6000),round(.02+.002*j+.003*(a%4),5)))
    reduction=.25+.05*(j%5);premium=500+j*70
    for scenario in range(800):
        common=rng.random();shock=int(common<.09+.003*j);scenarios.append((scenario,shock));raw=0;mit=0
        for a,exposure,p in assets:
            hit=rng.random()<min(.9,p*(4 if shock else 1));severity=min(2.5,rng.paretovariate(2.4)/2);loss=round(exposure*severity) if hit else 0
            reduced=round(loss*(1-reduction));losses.extend([(scenario,a,'Baz çizgi',loss),(scenario,a,'Aday önlem',reduced)]);raw+=loss;mit+=reduced
        totals.extend([(scenario,'Baz çizgi',raw),(scenario,'Aday önlem',mit+premium)])
    metrics=[]
    for name in ['Baz çizgi','Aday önlem']:
        xs=[v for i,n,v in totals if n==name];var,cvar=tail(xs);metrics.append({'politika':name,'ortalama_net_kayip':round(statistics.mean(xs),3),'VaR_95':var,'CVaR_95':round(cvar,3),'en_buyuk_kayip':max(xs)})
    diffs=[totals[2*i][2]-totals[2*i+1][2] for i in range(800)];lo,hi=interval(diffs,rng)
    sensitivities=[{'sabit_prim':p,'ortalama_net_kazanc':round(statistics.mean(diffs)+premium-p,3)} for p in [premium/2,premium,premium*2]]
    q='SELECT policy,COUNT(*) AS scenarios,ROUND(AVG(net_loss),3) AS mean_loss,MAX(net_loss) AS maximum_loss FROM totals GROUP BY policy ORDER BY policy'
    q2='SELECT policy,common_shock,COUNT(*) AS scenarios,ROUND(AVG(net_loss),3) AS mean_loss FROM totals JOIN scenarios USING(scenario_id) GROUP BY policy,common_shock ORDER BY policy,common_shock'
    t={'assets':([('asset_id','INTEGER PRIMARY KEY'),('exposure','INTEGER'),('event_probability','REAL')],assets),'scenarios':([('scenario_id','INTEGER PRIMARY KEY'),('common_shock','INTEGER')],scenarios),'losses':([('scenario_id','INTEGER'),('asset_id','INTEGER'),('policy','TEXT'),('gross_loss','INTEGER')],losses),'totals':([('scenario_id','INTEGER'),('policy','TEXT'),('net_loss','INTEGER')],totals)}
    store(s,t,{'net_loss_summary':q,'shock_summary':q2},{'tail_metrics':metrics,'paired_savings':[{'ortalama_net_kazanc':round(statistics.mean(diffs),3),'alt_95':lo,'ust_95':hi,'sabit_prim':premium}],'premium_sensitivity':sensitivities},
    ['12 maruziyetin 800 ortak senaryosu üretilir. Senaryodaki ortak şok olay olasılığını dört katına çıkarır; maruziyetleri bağımsız toplamaktan farklı bir yoğunlaşma yapısı oluşur. Şok dışında olaylar koşullu bağımsızdır.',
     f'Olay şiddeti ağır kuyruklu Pareto çekilişiyle üretilir ve 2,5 kat maruziyette sınırlandırılır. Aday önlem aynı olayları kullanarak brüt kaybı %{100*reduction:.0f} azaltır; her senaryoda {premium} örnek para birimi prim eklenir.',
     'Net kayıp brüt kayıp artı sabit primdir. %95 VaR sıralı örneğin nearest-rank eşiğidir. CVaR bu eşikten başlayan üst kuyruk sıralarının ortalamasıdır; kesikli örnekte bağlar ve kuyruk satır sayısı tanımın parçasıdır.',
     'Baz çizgi ve aday aynı senaryo kimliğinde eşlenir. 250 senaryo bootstrap yalnız ortalama net kazanım aralığı üretir; kuyruk metrikleri için güven aralığı iddia edilmez. Prim yarım, baz ve iki kat değerlerinde yeniden değerlendirilir.'],
    [f'Baz çizgi ortalama net kayıp {metrics[0]["ortalama_net_kayip"]}, aday {metrics[1]["ortalama_net_kayip"]}. CVaR sırasıyla {metrics[0]["CVaR_95"]} ve {metrics[1]["CVaR_95"]}.',f'Ortalama net kazanım {statistics.mean(diffs):.3f}; %95 senaryo bootstrap aralığı {lo}–{hi}. Prim düşüşü veya artışı ekonomik kararı değiştirebilir; uç kayıp ve ortalama aynı karar ölçütü değildir.'],
    ['Şok olasılığı, Pareto kuyruğu ve önlem katsayısı varsayımsaldır. Sonuçların doğrulanması yalnız hesaplamanın yeniden üretilebildiğini gösterir; gerçek risk kalibrasyonu olduğunu göstermez.','800 senaryo çok nadir felaketleri yeterince temsil etmeyebilir. CVaR, senaryo kümesinin dışında kalan kayıplar için üst sınır veya garanti değildir. Örnek para birimi gerçek kurum maliyeti değildir.'],
    [('Her senaryoda iki politika var',len(totals)==1600 and len({(r[0],r[1]) for r in totals})==1600),('Kayıplar ve maruziyetler negatif değil',all(r[3]>=0 for r in losses)),('Aday brüt kayıp baz çizgiyi aşmıyor',all(losses[i][3]>=losses[i+1][3] for i in range(0,len(losses),2))),('CVaR VaR eşiğinden küçük değil',all(x['CVaR_95']>=x['VaR_95'] for x in metrics))],f'{s["unit"].capitalize()} için önlem primi ortak şok ve ağır kuyruk altında ekonomik olarak dayanıklı mı?')

def main():
    base.studies.clear()
    for i,s in enumerate(specifications()):
        s['seed']=20261003+137*i
        globals()[s['family']](s,random.Random(s['seed']))
        print('OK',s['slug'],flush=True)
    catalog=BASE+base.studies
    assert len(catalog)==80 and len({x['slug'] for x in catalog})==80
    (ROOT/'catalog.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2),encoding='utf-8')
    print('PASS',len(base.studies),'new cases;',sum(len(x['checks']) for x in catalog),'invariants')

if __name__=='__main__':main()
