"""Distinct synthetic decision cases. No employer or customer records."""
# slug | title | category | outcome/unit | operational decision | interpretation risk
GROUPS = {
'experiment': '''
webhook-ack|Webhook ACK politikası ve kayıp olay|Entegrasyon|kayıp olay oranı|ACK öncesi kalıcı kayıt politikasını pilotla|Olayların aynı kaynağa bağlı olması bağımsızlığı bozar
alias-cache|Alias önbelleği yenileme deneyi|Entegrasyon|yanlış alıcı oranı|Önbellek TTL adayını hata ve sorgu bütçesiyle değerlendir|Gerçek alias değişim sıklığı sentetik örnekten farklıdır
ubl-preflight|UBL ön kontrolünün retlere etkisi|Entegrasyon|ret oranı|Ön kontrolü aşamalı etkinleştir ve kaçan hataları izle|Kural kapsamı resmi UBL uygunluğu anlamına gelmez
etag-conflict|ETag zorunluluğu ve çakışan güncelleme|Entegrasyon|kaybolan güncelleme oranı|If-Match politikasını istemci uyum testleriyle devreye al|Eski istemcilerin davranışı ayrıca ölçülmelidir
kiosk-confirm|Kiosk ödeme teyit ekranı deneyi|Operasyon|tekrar ödeme girişimi oranı|Teyit akışını kullanıcı görevi testinde karşılaştır|Davranış üretimi gerçek kullanıcı araştırması değildir
checkout-validation|Sipariş formu doğrulama deneyi|Müşteri ve pazar|hatalı sipariş oranı|Alan kontrollerini dönüşüm ve hata maliyetiyle seç|Dönüşüm kaybı ikinci bir deney gerektirir
refund-review|İade inceleme kapısı deneyi|Veri ve finans|yanlış iade oranı|Yüksek tutarlı iadelerde ikinci göz kontrolünü pilotla|Finansal suistimal etiketi gerçek suç tespiti değildir
duplicate-warning|Cari kart mükerrer uyarısı deneyi|Veri ve finans|mükerrer kayıt oranı|Uyarı eşiğini işlem süresiyle birlikte değerlendir|Kullanıcının uyarıyı geçme davranışı varsayımsaldır
address-confirm|Teslimat adresi teyit deneyi|Müşteri ve pazar|adres hatası oranı|Adres teyidini yoğun bölgelerde kontrollü dene|Bölgesel dağılım örneği gerçek nüfusu temsil etmez
ticket-template|Destek talebi şablonu deneyi|Operasyon|eksik bilgi oranı|Şablonu gerekli alan ve başvuru yüküyle değerlendir|Talep sahiplerinin deneyim seviyesi kontrol edilmemiştir
import-preview|Excel aktarımı önizleme deneyi|Veri ve finans|yanlış eşleme oranı|Kolon önizlemesini veri sahibinin onayına bağla|Hata türleri tüm gerçek Excel dosyalarını kapsamaz
token-refresh|Token yenileme penceresi deneyi|Entegrasyon|yetkisiz çağrı oranı|Yenileme tamponunu çağrı ve hata bütçesiyle seç|Kimlik sağlayıcının gerçek saat sapması ayrı ölçülür
''',
'did': '''
branch-rollout|Şube sürüm geçişi: farkların farkı|Operasyon|işlem süresi|Kademeli sürüm geçişini şube paneliyle değerlendir|Eşzamanlı donanım değişikliği etkiyi karıştırır
invoice-batch|Fatura batch boyutu müdahalesi|Entegrasyon|kuyruk bekleme süresi|Batch değişimini kontrol tenantlarıyla karşılaştır|Ortak sağlayıcı kesintisi paralel trendi bozabilir
warehouse-slot|Depo yerleşim değişikliği|Operasyon|toplama süresi|Yerleşim pilotunu benzer depolarla eşleştir|Ürün karması değişirse ölçülen fark yanıltır
support-triage|Destek ön sınıflandırma müdahalesi|Operasyon|çözüm süresi|Ön sınıflandırmayı ekip yüküne göre pilotla|Talep karmaşıklığı dönemler arasında değişebilir
menu-cache|QR menü önbellek geçişi|Entegrasyon|yanıt süresi|Geçişi ortak gün etkilerini kontrol ederek değerlendir|Ağ altyapısı ile yazılım etkisi ayrışmayabilir
supplier-routing|Tedarikçi sipariş yönlendirmesi|Operasyon|teslimat gecikmesi|Yönlendirmeyi ürün ve depo katmanında izle|Tedarikçi seçimi rastgele değildir
approval-policy|Satın alma onay limiti değişimi|Veri ve finans|onay süresi|Onay limiti pilotunda kontrol istisnalarını ayrı izle|İşlem tutarları müdahaleden sonra değişebilir
invoice-reminder|Alacak hatırlatma programı|Veri ve finans|tahsilat gecikmesi|Hatırlatmayı karşılaştırma müşteri kümeleriyle değerlendir|Tahsilat mevsimselliği müdahale etkisi değildir
partner-onboarding|Partner onboarding rehberi|Müşteri ve pazar|aktivasyon süresi|Rehberi sürüm ve müşteri türüne göre pilotla|Müşteri seçimi öncesindeki farklar kalabilir
price-display|Fiyat gösterimi sadeleştirmesi|Müşteri ve pazar|sipariş tamamlama süresi|Gösterimi şube ve dönem karşılaştırmasıyla incele|Eşzamanlı kampanya etkisi ayrıştırılmalıdır
inventory-count|Sayım akışı saat kesiti müdahalesi|Veri ve finans|mutabakat süresi|Hareket kesitini dönem sınırı testleriyle doğrula|Bu çalışma stok miktarının doğruluğunu tek başına kanıtlamaz
release-gate|Sürüm kabul kapısı müdahalesi|Entegrasyon|olay çözüm süresi|Kabul kapısını riskli modüllerde kademeli uygula|Test kapsamı ve ekip değişimi kontrol edilmelidir
''',
'survival': '''
einvoice-response|e-Fatura yanıt süresi ve sansür|Entegrasyon|belge yanıtı|Bekleyen belge yaşını tamamlananlardan ayrı raporla|Gerçek işlem statüleri bu örnekte modellenmez
earchive-delivery|e-Arşiv teslimat süresi dağılımı|Entegrasyon|teslimat teyidi|Teyit gelmeyen kayıtları yaşa göre inceleme kuyruğuna al|Teslimat teyidi hukuki teslim ispatı olarak yorumlanamaz
waybill-confirm|e-İrsaliye teyit süresi dağılımı|Entegrasyon|teyit olayı|Teyit gecikmesini belge karmasına göre izle|Mevzuat yanıt süreleri için resmi kaynak gerekir
incident-recovery|Kesinti toparlanma süresi|Operasyon|hizmet toparlanması|Açık olayları kapanmış olay ortalamasından ayır|Olayın kapanış tanımı ekipler arasında farklı olabilir
payment-settlement|Ödeme valör süresi ve bekleyenler|Veri ve finans|hesaba geçiş|Nakit planında bekleyen yaş dağılımını kullan|Banka tatilleri ve gerçek sözleşmeler modellenmez
refund-completion|İade sonuçlanma süresi|Veri ve finans|iade tamamlanması|İade kuyruğunu gözlem penceresiyle birlikte raporla|İade iptali rakip risk olarak ele alınmamıştır
customer-activation|Müşteri ilk aktivasyon süresi|Müşteri ve pazar|ilk kullanım|Aktivasyon desteğini henüz aktivasyon yapmayan kohortta planla|Vazgeçme ayrı bir rakip risk olabilir
supplier-resolution|Tedarikçi uygunsuzluğu kapanış süresi|Operasyon|uygunsuzluk kapanışı|Açık uygunsuzlukları yaş ve önem derecesiyle takip et|Önem derecesi bağımsız sansür varsayımını bozabilir
contract-signing|Partner sözleşme tamamlama süresi|Müşteri ve pazar|süreç tamamlanması|Takip kapasitesini bekleyen kohort yaşına göre planla|İmzalanmama nedeni modelde ayrıştırılmaz
schema-migration|Şema geçişi tamamlama süresi|Entegrasyon|tenant geçişi|Geçiş dalgalarını henüz bitmemiş tenantlarla değerlendir|Büyük tenantların geç başlaması seçim yanlılığı yaratır
stock-clearance|Stok eritme süresi ve gözlem sonu|Operasyon|stok tükenmesi|Eritme hedefini tamamlanmamış ürünlerle birlikte değerlendir|Yeniden tedarik ve ürün ikamesi kapsam dışıdır
ticket-reopen|Destek yeniden açılma zaman analizi|Operasyon|yeniden açılma|Kalıcı çözümü yeniden açılmama eğrisiyle izleyerek değerlendir|Olayın burada oluşması olumsuz sonuçtur; tamamlanma sayılmaz
''',
'optimization': '''
test-budget|Risk ağırlıklı test portföyü seçimi|Entegrasyon|test paketi|Test saatini kritik bağımlılıkları koruyarak dağıt|Kapsam puanı gerçek hata bulma olasılığı değildir
integration-roadmap|Entegrasyon yol haritası optimizasyonu|Entegrasyon|entegrasyon işi|Kaynak bütçesini en kötü senaryo değeriyle karşılaştır|İş değeri paydaş tahminiyle güncellenmelidir
warehouse-upgrade|Depo iyileştirme portföyü|Operasyon|depo müdahalesi|Saat ve bütçe kısıtında dayanıklı müdahale setini seç|Uygulama süreleri deterministik varsayılmıştır
supplier-audit|Tedarikçi denetim kapsamı seçimi|Operasyon|denetim paketi|Denetim kapasitesini kritik tedarik bağımlılıklarıyla planla|Puanlar uygunsuzluk kanıtı değildir
data-remediation|Veri düzeltme işlerinin önceliği|Veri ve finans|veri düzeltme işi|Düzeltme bütçesini kayıp senaryolarına göre sırala|Kayıtlar arasındaki ortak hata kökü ayrıca araştırılır
security-controls|Entegrasyon kontrol portföyü|Entegrasyon|kontrol paketi|Bağımlı kontrolleri bir paket halinde değerlendir|Sentetik puanlar güvenlik sertifikasyonu sağlamaz
branch-investment|Şube yatırım portföyü|Operasyon|şube yatırımı|Finansman ve uygulama saatini birlikte sınırla|Yatırım getirisi gerçek piyasa tahmini değildir
campaign-budget|Kampanya portföyü dayanıklılığı|Müşteri ve pazar|kampanya paketi|Kanallar arasında en kötü değer senaryosunu koru|Kampanyalar arasında müşteri örtüşmesi modellenmez
training-allocation|Analist eğitim kapasitesi dağılımı|Operasyon|eğitim paketi|Ön koşulları koruyarak eğitim setini seç|Beceri puanı iş performansını doğrudan ölçmez
observability-rollout|Gözlemlenebilirlik yatırımı seçimi|Entegrasyon|izleme bileşeni|Log ve metrik bağımlılıklarını bütçede koru|İzleme kapsamı olay önleme garantisi değildir
cash-collection|Tahsilat aksiyonu kapasite seçimi|Veri ve finans|aksiyon paketi|Tahsilat operasyonunu bütçe ve süreyle planla|Borçlu değerlendirmesi veya gerçek kredi kararı değildir
product-discovery|Ürün keşif araştırmaları seçimi|Müşteri ve pazar|araştırma işi|Araştırma bütçesini senaryo değerine göre dağıt|Değer puanı araştırmanın gerçek etkisi değildir
''',
'forecast': '''
api-traffic|API çağrı hacmi ileri dönem testi|Entegrasyon|çağrı|Kapasite tamponunu dönem dışı hata ile belirle|Kesinti ile bastırılmış trafik gerçek talebi gizler
invoice-volume|Fatura hacmi takvim tahmini|Entegrasyon|belge|Ay sonu kapasitesini haftalık desenle kıyasla|Gerçek ay sonu takvimi ayrıca eklenmelidir
order-arrival|Sipariş geliş hacmi tahmini|Operasyon|sipariş|Vardiya planını ileri gün hatasıyla değerlendir|Sipariş değeri ve işlem karmaşıklığı kapsam dışıdır
support-volume|Destek talebi hacim tahmini|Operasyon|talep|Destek vardiyalarına tahmin hatası payı ekle|Yeni sürüm sıçramaları geçmiş desenden tahmin edilemeyebilir
refund-volume|İade hacmi dönem dışı testi|Veri ve finans|iade|Mutabakat kapasitesini hata dilimine göre planla|İade tutarı ve hacmi ayrı metriklerdir
warehouse-load|Depo toplama yükü tahmini|Operasyon|satır|Personel planında satır sayısı ve hata payını kullan|Ürün boyutu ve mesafe modele dahil değildir
menu-demand|QR menü istek hacmi tahmini|Entegrasyon|istek|Önbellek kapasitesini görünmeyen gelecek günlerde değerlendir|Bot trafiği ve gerçek müşteri ayrılmamıştır
partner-activation|Partner aktivasyon hacmi tahmini|Müşteri ve pazar|aktivasyon|Onboarding kapasitesini ileri dönem sonuçlarıyla planla|Satış kampanyaları dışsal değişken olarak yoktur
shipment-count|Sevkiyat adedi ileri dönem testi|Operasyon|sevk|Yükleme planını haftalık naive baz çizgisine karşı ölç|Ağırlık ve güzergah bazlı kapasite yoktur
import-jobs|Excel aktarım işi yükü tahmini|Veri ve finans|aktarım|Aktarım işçisi kapasitesini tahmin hata bütçesiyle planla|Dosya boyutu ile iş adedi doğrusal olmayabilir
payment-count|Ödeme işlem hacmi ileri dönem testi|Veri ve finans|ödeme|Mutabakat batch kapasitesini ileri dönem ölçümüyle seç|İşlem tutarı ve risk profili hacimden bağımsızdır
campaign-orders|Kampanya siparişi tahmin sağlamlığı|Müşteri ve pazar|sipariş|Kampanya planında baz çizgi üstünlüğünü doğrula|Kampanya etkisini nedensel olarak ayırmaz
''',
'risk': '''
fx-settlement-risk|Dövizli mutabakat stres senaryosu|Veri ve finans|kur farkı|Kur ve tahsilat şokunu ortak senaryoda değerlendir|Gerçek kur öngörüsü veya yatırım tavsiyesi değildir
provider-outage-loss|Sağlayıcı kesintisi kayıp kuyruğu|Entegrasyon|kesinti kaybı|Kesinti yedeğinin maliyetini kuyruk riskiyle karşılaştır|İş kaybı tutarları sentetik varsayımlardır
supplier-delay-loss|Tedarik gecikmesi marj riski|Operasyon|gecikme kaybı|Yedek tedarik primini uç senaryo kaybıyla kıyasla|Tedarikçi korelasyonu gerçek veriyle kalibre edilmelidir
return-margin-risk|İade dalgası marj dayanıklılığı|Müşteri ve pazar|marj kaybı|İade tamponunu beklenen ve uç kayıpla değerlendir|İade davranışı gerçek tüketici örneği değildir
fraud-review-capacity|Şüpheli ödeme inceleme kapasitesi|Veri ve finans|inceleme kaybı|İnceleme primini gecikme ve kaçan olay maliyetiyle kıyasla|Sentetik olaylar gerçek kişilerin risk sınıfı değildir
cloud-cost-tail|Bulut maliyeti uç senaryo analizi|Entegrasyon|bütçe aşımı|Kapasite rezervini uç maliyet ve kullanım kaybıyla karşılaştır|Sağlayıcı fiyatları yerine örnek maliyetler kullanılır
inventory-shortage-risk|Stok yokluğu kayıp stres testi|Operasyon|kayıp marj|Tampon stok primini ortak talep şokuyla değerlendir|Ürün ikamesi ve kayıp müşteri etkisi yoktur
campaign-margin-tail|Kampanya marjı uç kayıp analizi|Müşteri ve pazar|marj sapması|Kampanya rezervini net kuyruk kaybına göre seç|Gerçek fiyat esnekliği modellenmemiştir
receivable-delay-risk|Alacak gecikmesi nakit stres testi|Veri ve finans|nakit açığı|Nakit tamponunu ortak gecikme şokunda karşılaştır|Gerçek borçlu puanlaması veya kredi kararı değildir
release-incident-risk|Sürüm olay maliyeti stres testi|Entegrasyon|olay maliyeti|Sürüm öncesi rezervi ağır kuyruk senaryosuyla değerlendir|Olay olasılıkları gerçek sürüm başarısını öngörmez
warehouse-disruption|Depo kesintisi operasyon riski|Operasyon|operasyon kaybı|Yedek operasyon primini ortak aksama senaryosuyla kıyasla|Fiziksel afet riski ve güvenlik analizi değildir
partner-churn-tail|Partner kaybı gelir stres testi|Müşteri ve pazar|gelir kaybı|Partner yoğunlaşmasını ortak şok varsayımıyla değerlendir|Gerçek müşteri kaybı veya değer tahmini değildir
'''
}

def specifications():
    result=[]
    for family,lines in GROUPS.items():
        for j,line in enumerate(lines.strip().splitlines()):
            slug,title,category,unit,decision,risk=line.split('|')
            result.append(dict(family=family,variant=j,slug=slug,title=title,category=category,unit=unit,decision=decision,risk=risk))
    assert len(result)==72 and len({s['slug'] for s in result})==72
    return result
