"""Independent analytic edge cases for the reusable statistical engines."""
import unittest,random
from build_expansion import km,tail,interval,quantile
from specs import specifications

class Methods(unittest.TestCase):
    def test_complete_events_km_area_equals_mean_capped_time(self):
        curve,area,survival=km([(2,1),(4,1)],horizon=8)
        self.assertEqual(area,3)
        self.assertEqual(survival,0)
        self.assertEqual([x['risk_kumesi'] for x in curve],[2,1])
    def test_all_censored_has_no_invented_event(self):
        curve,area,survival=km([(2,0),(4,0)],horizon=8)
        self.assertEqual((area,survival),(8,1))
        self.assertTrue(all(x['olay']==0 for x in curve))
    def test_tied_event_and_censor_use_same_risk_set(self):
        curve,area,survival=km([(2,1),(2,0),(4,1)],horizon=8)
        self.assertEqual(curve[0]['risk_kumesi'],3)
        self.assertAlmostEqual(curve[0]['olaysiz_kalma'],2/3,places=6)
        self.assertAlmostEqual(area,2+2*2/3)
    def test_horizon_truncates_future_events(self):
        self.assertEqual(km([(100,1)],horizon=48)[1:],(48,1))
    def test_tail_nearest_rank_and_upper_slice(self):
        self.assertEqual(tail(list(range(1,101))),(95,97.5))
    def test_tail_zero_loss(self):
        self.assertEqual(tail([0]*100),(0,0))
    def test_bootstrap_constant_difference(self):
        self.assertEqual(interval([2]*20,random.Random(1)),[2,2])
    def test_quantile_interpolation(self):
        self.assertEqual(quantile([0,10],.25),2.5)
    def test_case_identities_and_method_coverage(self):
        specs=specifications()
        self.assertEqual(len(specs),72)
        self.assertEqual(len({x['slug'] for x in specs}),72)
        self.assertEqual(len({x['family'] for x in specs}),6)

if __name__=='__main__':unittest.main()
