"""Build 20 reproducible, synthetic-data SQL analysis case studies."""
from __future__ import annotations
import csv, html, json, random, sqlite3
from pathlib import Path

ROOT = Path(__file__).parent
OUT = ROOT / 'analizler'
R = random.Random(20260927)
CASES = []
def add(slug, title, question, columns, rows, sql, note):
    CASES.append(dict(slug=slug,title=title,question=question,columns=columns,rows=rows,sql=sql.strip(),note=note))

def records(fields, fn, n=160):
    return [dict(zip(fields,fn(i))) for i in range(n)]

add('efatura-sla','e-Fatura işlem SLA analizi','Entegratör işlem süreleri hangi belge durumlarında uzuyor?',
 ['status','duration_min','channel'],records(['status','duration_min','channel'],lambda i: (s:=R.choices(['Başarılı','Hatalı','Bekliyor'],[.82,.1,.08])[0],round(max(1,R.gauss({'Başarılı':12,'Hatalı':31,'Bekliyor':42}[s],8)),1),R.choice(['API','Portal']))),
 'SELECT status, COUNT(*) AS belge, ROUND(AVG(duration_min),1) AS ort_dakika, ROUND(100.0*SUM(duration_min>30)/COUNT(*),1) AS sla_asimi_pct FROM data GROUP BY status ORDER BY ort_dakika DESC',
 '30 dakika varsayımsal demo SLA eşiğidir; resmî GİB hizmet taahhüdü değildir.')
add('eirsaliye-gecikme','e-İrsaliye gecikme analizi','Hangi sevkiyat bölgelerinde belge gecikmesi yoğunlaşıyor?',
 ['region','delay_min','carrier'],records(['region','delay_min','carrier'],lambda i:(b:=R.choice(['Marmara','İç Anadolu','Ege']),round(max(0,R.gauss({'Marmara':19,'İç Anadolu':36,'Ege':25}[b],11)),1),R.choice(['A','B']))),
 'SELECT region, COUNT(*) AS sevkiyat, ROUND(AVG(delay_min),1) AS ort_gecikme, SUM(delay_min>30) AS geciken FROM data GROUP BY region ORDER BY ort_gecikme DESC',
 'Gecikme, oluşturma ve teslim kaydı arasındaki simüle edilmiş farktır.')
add('api-hata-pareto','API hata Pareto analizi','Hata yükünün çoğunu hangi uç noktalar oluşturuyor?',
 ['endpoint','http_status','latency_ms'],records(['endpoint','http_status','latency_ms'],lambda i:(e:=R.choices(['/invoice','/status','/token','/waybill'],[.4,.3,.12,.18])[0],R.choices([200,400,429,500],[.77,.13 if e=='/invoice' else .08,.05,.05 if e=='/invoice' else .1])[0],int(max(20,R.gauss(190,70))))),
 'SELECT endpoint, COUNT(*) AS istek, SUM(http_status>=400) AS hata, ROUND(100.0*SUM(http_status>=400)/COUNT(*),1) AS hata_orani_pct FROM data GROUP BY endpoint ORDER BY hata DESC',
 'HTTP 4xx/5xx hata kabul edilir; uç nokta ağırlıkları sentetiktir.')
add('stok-abc','ERP stok ABC analizi','Hangi ürünler stok değerinin büyük kısmını taşıyor?',
 ['sku','units','unit_cost'],records(['sku','units','unit_cost'],lambda i:(f'SKU-{i+1:03}',R.randint(4,230),R.randint(20,1200)),n=120),
 'WITH v AS (SELECT sku, units*unit_cost AS stock_value FROM data), r AS (SELECT sku,stock_value,ROUND(100.0*SUM(stock_value) OVER (ORDER BY stock_value DESC)/SUM(stock_value) OVER (),1) AS cumulative_pct FROM v) SELECT CASE WHEN cumulative_pct<=80 THEN \'A\' WHEN cumulative_pct<=95 THEN \'B\' ELSE \'C\' END AS abc, COUNT(*) AS urun, SUM(stock_value) AS stok_degeri FROM r GROUP BY abc ORDER BY abc',
 'ABC sınıfları birikimli stok değerinin %80 ve %95 eşiklerine göre tanımlanır.')
add('satis-kanal-karliligi','Satış kanalı kârlılık analizi','Komisyon ve iadeler sonrasında hangi kanal daha kârlı?',
 ['channel','revenue','cost','commission','refunded'],records(['channel','revenue','cost','commission','refunded'],lambda i:(c:=R.choice(['Pazaryeri','Web','Mağaza']),v:=R.randint(150,2400),round(v*R.uniform(.48,.76),2),round(v*({'Pazaryeri':.17,'Web':.04,'Mağaza':.02}[c]),2),int(R.random()<{'Pazaryeri':.12,'Web':.06,'Mağaza':.04}[c]))),
 'SELECT channel, COUNT(*) AS siparis, ROUND(SUM(CASE WHEN refunded=1 THEN -cost-commission ELSE revenue-cost-commission END),2) AS net_kar, ROUND(100.0*SUM(refunded)/COUNT(*),1) AS iade_pct FROM data GROUP BY channel ORDER BY net_kar DESC',
 'İade durumunda gelirin tamamı geri alınır; maliyet ve komisyon gideri korunur.')
add('siparis-fulfillment','Sipariş hazırlama darboğazı','Sipariş hazırlamada en fazla gecikme hangi vardiyada?',
 ['shift','pick_min','pack_min','ship_min'],records(['shift','pick_min','pack_min','ship_min'],lambda i:(s:=R.choice(['Sabah','Akşam','Gece']),int(max(2,R.gauss({'Sabah':20,'Akşam':29,'Gece':35}[s],7))),R.randint(4,18),R.randint(5,28))),
 'SELECT shift, COUNT(*) AS siparis, ROUND(AVG(pick_min+pack_min+ship_min),1) AS toplam_dakika, ROUND(AVG(pick_min),1) AS toplama_dakika FROM data GROUP BY shift ORDER BY toplam_dakika DESC',
 'Vardiyalar ve süreler kurgu veridir; ölçüm sistemi yerine geçmez.')
add('pazaryeri-iade','Pazaryeri iade nedenleri','Hangi kategori ve nedenlerde iade oranı artıyor?',
 ['category','reason','returned'],records(['category','reason','returned'],lambda i:(c:=R.choice(['Tekstil','Elektronik','Ev']),R.choice(['Beden','Hasar','Beklenti']),int(R.random()<{'Tekstil':.19,'Elektronik':.12,'Ev':.08}[c]))),
 'SELECT category, COUNT(*) AS satis, SUM(returned) AS iade, ROUND(100.0*SUM(returned)/COUNT(*),1) AS iade_pct FROM data GROUP BY category ORDER BY iade_pct DESC',
 'İade nedeni yalnızca örnek amaçlıdır; oran kategori bazında hesaplanır.')
add('odeme-mutabakat','Ödeme mutabakat farkları','ERP tutarı ile ödeme sağlayıcı tutarı nerede ayrışıyor?',
 ['provider','erp_amount','paid_amount'],records(['provider','erp_amount','paid_amount'],lambda i:(p:=R.choice(['POS-A','POS-B','Havale']),v:=R.randint(100,3000),v+R.choice([0]*14+[-20,15,50]))),
 'SELECT provider, COUNT(*) AS kayit, SUM(ABS(erp_amount-paid_amount)>0) AS farkli, SUM(ABS(erp_amount-paid_amount)) AS mutlak_fark FROM data GROUP BY provider ORDER BY mutlak_fark DESC',
 'Tutarlar sentetiktir; mutabakat toleransı sıfır kabul edilir.')
add('musteri-churn','Müşteri kayıp riski','Son kullanım süresi ve şikâyet ile hangi segment riskli?',
 ['segment','days_inactive','complaints','monthly_value'],records(['segment','days_inactive','complaints','monthly_value'],lambda i:(s:=R.choice(['KOBİ','Kurumsal','Bireysel']),R.randint(0,150),R.randint(0,4),R.randint(100,3500))),
 'SELECT segment, COUNT(*) AS musteri, SUM(days_inactive>60 AND complaints>=2) AS yuksek_risk, ROUND(AVG(monthly_value),1) AS ort_deger FROM data GROUP BY segment ORDER BY yuksek_risk DESC',
 'Kayıp tahmini değildir; >60 gün pasif ve ≥2 şikâyet açıklanabilir risk kuralıdır.')
add('destek-oncelik','Destek talebi önceliklendirme','Hangi talep türü açık bilet yükünü büyütüyor?',
 ['topic','severity','hours_open','resolved'],records(['topic','severity','hours_open','resolved'],lambda i:(R.choice(['Entegrasyon','Rapor','Yetki','Fatura']),R.choice([1,2,3]),R.randint(1,96),int(R.random()<.7))),
 'SELECT topic, COUNT(*) AS bilet, SUM(resolved=0) AS acik, ROUND(AVG(CASE WHEN resolved=0 THEN hours_open END),1) AS acik_ort_saat, SUM(resolved=0 AND severity=3) AS kritik_acik FROM data GROUP BY topic ORDER BY kritik_acik DESC, acik DESC',
 'Şiddet 1–3 olarak kodlanır; 3 en kritik düzeydir.')
add('sepet-birliktelik','Sepet birliktelik analizi','Ürün çiftlerinin birlikte satın alınma sıklığı nedir?',
 ['order_id','product'],[{'order_id':i,'product':p} for i in range(1,101) for p in R.sample(['Kahve','Filtre','Kupa','Çay','Şeker'],R.randint(1,3))],
 'SELECT a.product AS urun_a,b.product AS urun_b,COUNT(*) AS birlikte_siparis FROM data a JOIN data b ON a.order_id=b.order_id AND a.product<b.product GROUP BY a.product,b.product ORDER BY birlikte_siparis DESC LIMIT 10',
 'Aynı siparişte tekil ürünler bulunur; metrik birliktelik adedidir, nedensel ilişki değildir.')
add('kampanya-ab','Kampanya A/B testi','Deneme gruplarının dönüşüm oranları nasıl değişiyor?',
 ['variant','converted','revenue'],records(['variant','converted','revenue'],lambda i:(v:='A' if i%2==0 else 'B',c:=int(R.random()<(.13 if v=='A' else .18)),R.randint(120,950)*c),n=400),
 'SELECT variant, COUNT(*) AS ziyaretci, SUM(converted) AS donusum, ROUND(100.0*AVG(converted),2) AS donusum_pct, SUM(revenue) AS gelir FROM data GROUP BY variant ORDER BY variant',
 'Gruplar rastgele sentetik üretilir; oran farkı istatistiksel anlamlılık veya nedensellik kanıtı değildir.')
add('talep-tahmini','Talep eğilimi ve hareketli ortalama','Son üç ay ortalamasına göre ürün grubu talebi nasıl seyreder?',
 ['category','month','units'],[{'category':c,'month':m,'units':int(max(10,base+m*trend+R.gauss(0,9)))} for c,base,trend in [('Tekstil',80,3),('Ev',100,1),('Aksesuar',65,5)] for m in range(1,13)],
 'SELECT category,month,units,ROUND(AVG(units) OVER (PARTITION BY category ORDER BY month ROWS BETWEEN 2 PRECEDING AND CURRENT ROW),1) AS uc_ay_ort FROM data WHERE month>=9 ORDER BY category,month',
 'Üç aylık geçmiş/şimdiki ortalamadır; ileriye dönük tahmin modeli değildir.')
add('fiyat-talep','Fiyat ve talep ilişkisi','Fiyat aralıklarında satış miktarı nasıl değişiyor?',
 ['price_band','units_sold','discount_pct'],records(['price_band','units_sold','discount_pct'],lambda i:(b:=R.choice(['Düşük','Orta','Yüksek']),int(max(1,R.gauss({'Düşük':28,'Orta':20,'Yüksek':13}[b],5))),R.choice([0,5,10,15]))),
 'SELECT price_band, COUNT(*) AS gozlem, ROUND(AVG(units_sold),1) AS ort_birim, ROUND(AVG(discount_pct),1) AS ort_indirim FROM data GROUP BY price_band ORDER BY ort_birim DESC',
 'Fiyat bantları ürün ve sezon etkilerini kontrol etmez; esneklik katsayısı çıkarılmaz.')
add('alacak-yaslandirma','Alacak yaşlandırma analizi','Vadesi geçen alacak hangi yaş aralıklarında birikiyor?',
 ['customer_segment','days_overdue','balance'],records(['customer_segment','days_overdue','balance'],lambda i:(R.choice(['KOBİ','Kurumsal']),R.randint(-20,130),R.randint(100,10000))),
 'SELECT CASE WHEN days_overdue<=0 THEN \'Vadesinde\' WHEN days_overdue<=30 THEN \'1-30 gün\' WHEN days_overdue<=60 THEN \'31-60 gün\' ELSE \'60+ gün\' END AS vade_grubu, COUNT(*) AS fatura, SUM(balance) AS bakiye FROM data GROUP BY vade_grubu ORDER BY bakiye DESC',
 'Bakiye ve gecikme simüle edilmiştir; finansal karar amacıyla kullanılmaz.')
add('veri-kalitesi','Müşteri ana veri kalitesi','Zorunlu alanların eksik ve mükerrer kayıt oranı nedir?',
 ['customer_id','tax_id','email','city'],records(['customer_id','tax_id','email','city'],lambda i:(i+1,'' if R.random()<.11 else f'TAX{i//15 if R.random()<.04 else i:04}', '' if R.random()<.16 else f'user{i}@example.test',R.choice(['Konya','Bursa','İstanbul','']))),
 'SELECT COUNT(*) AS kayit, SUM(tax_id=\'\') AS eksik_vkn, SUM(email=\'\') AS eksik_eposta, SUM(city=\'\') AS eksik_sehir, COUNT(tax_id)-COUNT(DISTINCT NULLIF(tax_id,\'\')) AS yinelenen_vkn FROM data',
 'Boş VKN mükerrer hesabından çıkarılır; eşleşme yalnızca birebir tanımlayıcı üzerindendir.')
add('tedarikci-otd','Tedarikçi zamanında teslim','Teslim performansı hangi tedarikçide düşüyor?',
 ['supplier','promised_day','actual_day','quantity'],records(['supplier','promised_day','actual_day','quantity'],lambda i:(s:=R.choice(['T1','T2','T3']),d:=R.randint(5,22),d+R.randint(-2,{'T1':4,'T2':8,'T3':2}[s]),R.randint(10,140))),
 'SELECT supplier, COUNT(*) AS teslimat, ROUND(100.0*SUM(actual_day<=promised_day)/COUNT(*),1) AS zamaninda_pct, ROUND(AVG(MAX(0,actual_day-promised_day)),1) AS ort_gecikme_gun FROM data GROUP BY supplier ORDER BY zamaninda_pct ASC',
 'OTD metriği taahhüt edilen gün veya öncesinde teslim oranıdır.')
add('stok-devir','Stok devir göstergesi','Hangi kategoride stok hareketi daha yavaş?',
 ['category','cost_sold','avg_inventory'],records(['category','cost_sold','avg_inventory'],lambda i:(c:=R.choice(['Tekstil','Elektronik','Ev']),R.randint(40,900),R.randint(100,1100))),
 'SELECT category, ROUND(SUM(cost_sold)*1.0/SUM(avg_inventory),2) AS devir_orani, SUM(cost_sold) AS satis_maliyeti, SUM(avg_inventory) AS ort_stok FROM data GROUP BY category ORDER BY devir_orani ASC',
 'Tek dönem maliyet/stok oranıdır; yıllıklandırılmış stok devir hızı değildir.')
add('islem-anomali','İşlem tutarı aykırı değer','Üç sigma eşiğini aşan işlemler hangi kanalda?',
 ['channel','amount'],records(['channel','amount'],lambda i:(R.choice(['API','Portal','Mobil']),round(R.uniform(7000,11000),2) if i in (22,109,151) else round(max(1,R.gauss(520,110)),2))),
 'WITH stats AS (SELECT AVG(amount) AS mean, SQRT(AVG(amount*amount)-AVG(amount)*AVG(amount)) AS sigma FROM data) SELECT channel, COUNT(*) AS islem, SUM(amount>(SELECT mean+3*sigma FROM stats)) AS uc_sigma_ustu FROM data GROUP BY channel ORDER BY uc_sigma_ustu DESC',
 'Yüksek tutarlar sentetik olarak eklenmiştir; üç sigma işareti dolandırıcılık kanıtı değildir.')
add('surec-darbogaz','Onay süreci darboğazı','İş akışının hangi aşaması toplam sürenin çoğunu tüketiyor?',
 ['stage','duration_min','reworked'],records(['stage','duration_min','reworked'],lambda i:(s:=R.choice(['Kayıt','Kontrol','Onay','İletim']),int(max(1,R.gauss({'Kayıt':8,'Kontrol':24,'Onay':39,'İletim':10}[s],5))),int(R.random()<.12))),
 'SELECT stage, COUNT(*) AS adim, SUM(duration_min) AS toplam_dakika, ROUND(AVG(duration_min),1) AS ort_dakika, SUM(reworked) AS tekrar_is FROM data GROUP BY stage ORDER BY toplam_dakika DESC',
 'Aşama örnekleri farklı işlem sayıları içerebilir; toplam ve ortalama birlikte değerlendirilir.')

RUNNER = '''"""Run this case study with Python 3 standard library only."""\nimport csv, json, sqlite3\nfrom pathlib import Path\np=Path(__file__).parent\nwith (p/'data.csv').open(encoding='utf-8', newline='') as f:\n    reader=csv.DictReader(f); rows=list(reader); columns=reader.fieldnames\nconn=sqlite3.connect(':memory:')\nconn.execute('CREATE TABLE data ('+', '.join('"'+c+'" '+('REAL' if all(row[c].replace('.','',1).replace('-','',1).isdigit() for row in rows) else 'TEXT') for c in columns)+')')\nconn.executemany('INSERT INTO data VALUES ('+','.join('?' for _ in columns)+')',[[row[c] for c in columns] for row in rows])\nresult=conn.execute((p/'analysis.sql').read_text(encoding='utf-8')).fetchall()\nheaders=[x[0] for x in conn.execute((p/'analysis.sql').read_text(encoding='utf-8')).description]\nprint(json.dumps({'source_rows':len(rows),'columns':headers,'results':[dict(zip(headers,row)) for row in result]},ensure_ascii=False,indent=2))\n'''

INDEX = []
for case in CASES:
    folder = OUT/case['slug']; folder.mkdir(parents=True,exist_ok=True)
    with (folder/'data.csv').open('w',encoding='utf-8',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=case['columns']);writer.writeheader();writer.writerows(case['rows'])
    (folder/'analysis.sql').write_text(case['sql']+';\n',encoding='utf-8')
    (folder/'run.py').write_text(RUNNER,encoding='utf-8')
    conn=sqlite3.connect(':memory:')
    def kind(col):
        return 'REAL' if all(isinstance(r[col],(int,float)) for r in case['rows']) else 'TEXT'
    conn.execute('CREATE TABLE data ('+', '.join('"'+c+'" '+kind(c) for c in case['columns'])+')')
    conn.executemany('INSERT INTO data VALUES ('+','.join('?' for _ in case['columns'])+')',[[r[c] for c in case['columns']] for r in case['rows']])
    cur=conn.execute(case['sql']);headers=[d[0] for d in cur.description];result=[dict(zip(headers,row)) for row in cur.fetchall()]
    (folder/'results.json').write_text(json.dumps({'source_rows':len(case['rows']),'columns':headers,'results':result},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    table='<thead><tr>'+''.join('<th>'+html.escape(c)+'</th>' for c in headers)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+html.escape(str(row[c]))+'</td>' for c in headers)+'</tr>' for row in result[:30])+'</tbody>'
    numeric=[c for c in headers[1:] if result and all(isinstance(row[c],(int,float)) and row[c]>=0 for row in result)]
    chart=''
    if numeric and 1 < len(result) <= 12:
        metric=numeric[0]
        ceiling=max(float(row[metric]) for row in result) or 1
        bars=''.join(f'<div class="bar-row"><span>{html.escape(str(row[headers[0]]))}</span><div class="track"><i style="width:{100*float(row[metric])/ceiling:.1f}%"></i></div><b>{html.escape(str(row[metric]))}</b></div>' for row in result)
        chart=f'<div class="chart" role="img" aria-label="{html.escape(metric)} değerleri; ayrıntılar alttaki tabloda">{bars}</div>'
    report=f'''<!doctype html><html lang="tr"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{html.escape(case['title'])} | Analiz</title><style>body{{font:17px/1.6 system-ui;background:#08151f;color:#ecf4f5;margin:0}}main{{max-width:1000px;margin:auto;padding:48px 24px}}a{{color:#6fdcc0}}h1{{font-size:clamp(28px,5vw,48px);line-height:1.1}}.tag{{color:#6fdcc0}}p{{max-width:70ch}}.scroll{{overflow-x:auto}}table{{border-collapse:collapse;width:100%;background:#102434}}th,td{{padding:12px 16px;border:1px solid #274052;text-align:left}}th{{color:#6fdcc0}}code,pre{{font:14px/1.5 ui-monospace,monospace}}pre{{white-space:pre-wrap;overflow-wrap:anywhere;background:#061019;padding:20px;border-radius:10px}}.chart{{background:#102434;padding:18px;border-radius:12px;margin:18px 0 24px}}.bar-row{{display:grid;grid-template-columns:minmax(90px,150px) 1fr 75px;align-items:center;gap:12px;font-size:14px;margin:8px 0}}.bar-row span{{overflow-wrap:anywhere}}.bar-row b{{text-align:right}}.track{{height:12px;background:#274052;border-radius:8px;overflow:hidden}}.track i{{display:block;height:100%;background:#6fdcc0;border-radius:8px}}@media(max-width:500px){{.bar-row{{grid-template-columns:90px 1fr 55px;gap:6px}}}}</style><main><a href="../../index.html#analizler">← Tüm analizler</a><p class="tag">ÇALIŞTIRILMIŞ ANALİZ · SENTETİK DEMO VERİSİ · {len(case['rows'])} KAYIT</p><h1>{html.escape(case['title'])}</h1><h2>Analiz sorusu</h2><p>{html.escape(case['question'])}</p><h2>Sonuçlar</h2>{chart}<div class="scroll"><table>{table}</table></div><h2>Yöntem</h2><p>Veri: <a href="data.csv">data.csv</a> · Sorgu: <a href="analysis.sql">analysis.sql</a> · Tekrar çalıştırma: <a href="run.py">run.py</a> · Makine okunur sonuç: <a href="results.json">results.json</a>.</p><pre>{html.escape(case['sql'])}</pre><h2>Yorumlama sınırı</h2><p>{html.escape(case['note'])}</p></main></html>'''
    (folder/'index.html').write_text(report,encoding='utf-8')
    (folder/'README.md').write_text(f"# {case['title']}\n\n**Durum:** Tamamlanmış, tekrar üretilebilir sentetik veri analizi. Gerçek işletme verisi değildir.\n\n**Soru:** {case['question']}\n\n**Veri:** `{len(case['rows'])}` sentetik kayıt, alanlar: {', '.join(case['columns'])}.\n\n**Yöntem:** SQLite sorgusu `analysis.sql` dosyasındadır. Python 3 ile `python analizler/{case['slug']}/run.py` çalıştırın. Önceden çalıştırılmış çıktı `results.json`, tarayıcı raporu `index.html` dosyasındadır.\n\n**Yorumlama sınırı:** {case['note']}\n",encoding='utf-8')
    INDEX.append({k:case[k] for k in ('slug','title','question','note')} | {'row_count':len(case['rows']),'category':('Entegrasyon' if len(INDEX)<3 else 'Operasyon' if len(INDEX)<8 else 'Müşteri ve pazar' if len(INDEX)<14 else 'Veri ve finans'),'highlight':f"{headers[0]}: {result[0][headers[0]]}" if result else 'Sonuç yok'})
(OUT/'projects.json').write_text(json.dumps(INDEX,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('Built',len(CASES),'case studies with',sum(x['row_count'] for x in INDEX),'synthetic records')
