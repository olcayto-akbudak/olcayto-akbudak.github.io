# Kaynaklı analiz ve gereksinim projeleri

Bu paket, İbrahim Olcayto Akbudak'ın bağımsız portföy çalışmalarıdır. Şirket içi veri veya ürün kararı içermez. Tamamı aynı kanıt düzeyinde değildir: gerçek kurum günlüğü, resmi teknik örnek, kaynaklı gereksinim tasarımı ve sentetik kabul testi açıkça ayrılır.

## Çalışmalar

| Klasör | Kanıt ve çıktı |
|---|---|
| `ubl-tr-peppol` | GİB’in 28 XML örneği; 40 alan eşlemesi; 12 gereksinim; seçilmiş semantik ön kontrol |
| `gib-paket-etkisi` | İki resmi URL’den indirilen snapshot'ın byte/semantik farkı; 6 kural değişimi için etki ve test matrisi |
| `bpi2020-masraf` | Gerçek BPI 2020 günlüğü; 10.500 süreç ve 56.437 olay; geçiş ve ödeme süresi bulguları; BPMN kaynak modeli |
| `efatura-karar-modeli` | Güncel kural alt kümesi; kanal/profil/tip/vergi kararının ayrımı; eski örnek–güncel kural tutarsızlığı |
| `vergi-kod-modeli` | Kaynaktan türetilen aileli kod kataloğu; sürümlü SQLite veri modeli |
| `erp-kapanis` | Microsoft WWI açık şemasına dayanan uyarlama; 8 staging SQL kontrolü; sentetik kabul senaryoları |
| `erp-gecis` | Eşleme ve risk şablonları; 5 mutabakat SQL’i; geçiş kabul kapıları |
| `tcmb-kur` | Gerçek TCMB XML snapshot’ı; birim/tarih/kur türü parser ve açık seçim politikası |

Analiz ve kararlar her klasördeki README'de öndedir. Python/SQL ayrı dosyalardadır. Bunlar sekiz bağımsız GitHub deposu veya üretime alınmış sistemler olarak sunulmaz.

## Yeniden üretme

Python 3.12 ile doğrulandı. Ana dizinde çalıştırın:

```sh
python -m pip install -r requirements.txt
python fetch_sources.py --output sources
python ubl-tr-peppol/preflight.py sources/gib.zip --output ubl-tr-peppol/outputs
python gib-paket-etkisi/diff_packages.py sources/gib-efatura.zip sources/gib-efatura29.zip --output gib-paket-etkisi/outputs
python bpi2020-masraf/mine.py sources/DomesticDeclarations.xes.gz --output bpi2020-masraf/outputs
python vergi-kod-modeli/extract_codes.py sources/gib-efatura29.zip --output vergi-kod-modeli/code-catalog.csv
python tcmb-kur/policy.py sources/tcmb.xml --date 2026-10-03 --currency USD --type ForexBuying --allow-previous
RESEARCH_SOURCES="$PWD/sources" python -m unittest -v test_acceptance
```

`fetch_sources.py`, değişken URL'lerdeki içerik kaydedilmiş SHA-256 ile uyuşmuyorsa işlemi durdurur. Yeni sürüm eski bulgunun girdisi yerine sessizce konmaz. Güncel snapshot için yeni analiz sürümü oluşturulmalıdır. Kaynak indirmeden çalıştırılan testler resmi dosya testlerini atlar; test çıktısında bu açıkça görünür.

Alan matrisi ve gereksinim notları insan incelemesiyle hazırlanmıştır; tüm standarttan otomatik türetilmiş, kapsamlı bir uyum modeli değildir. SQLite kontrol modellerinin kayıtları test fixture’larında açıkça sentetiktir. WideWorldImporters SQL Server yedeği çalıştırılmadı; bu çalışmada gerçek ERP istisna sayısı üretilmedi.

## Doğrulama ve sınırlar

3 Ekim 2026: 22 otomatik test metodu, resmi kaynak kontrolleri açıkken geçti. İki paketin değişen plaka/dorse XPath 2.0 ifadeleri gerçek kaynak dosyalarından okunarak `elementpath` ile sınır örneklerinde yürütüldü. Bu, tam Schematron derleme/çalıştırma sertifikasyonu değildir. Resmi Peppol paketinin 9 Invoice örneği seçilmiş ön kontrollerden geçti; 28 GİB örneği hedef profil için boşluk verdi. Bu bulgu GİB belgelerinin hatalı olduğu anlamına gelmez.

BPI sonuçları takvim zamanıdır, aktif çalışma zamanı değildir. Gözlemsel farklar nedensel iyileştirme vaadi taşımaz. Vergi/kur ve kanal tasarımı mevzuata uyum hükmü vermez. Mali müşavir teyidi alınmadı. Kod ve öneriler üretim dağıtımı veya canlı belge düzenleme izni değildir.

## Kaynak ve lisans

URL, erişim tarihi ve içerik SHA-256 değerleri `SOURCES.json` içinde. BPI kaynağı: Boudewijn van Dongen (2020), DOI [10.4121/uuid:3f422315-ed9d-4882-891f-e180b5b4feb5](https://doi.org/10.4121/uuid:3f422315-ed9d-4882-891f-e180b5b4feb5), CC BY-NC 4.0. Türetilmiş BPI bulguları kaynağa atıfla ve aynı ticari olmayan kullanım sınırı açıklanarak sunulur. Orijinal olay günlüğü, GİB paketleri, PDF’ler ve Peppol artefaktları bu ZIP'te yeniden dağıtılmaz; kendi kaynak/lisansları geçerlidir.
