"""Descriptive event-log analysis. Case aggregates only; no personal identifiers."""
import argparse, collections, datetime, gzip, hashlib, json, csv
from pathlib import Path
from lxml import etree
X='{http://www.xes-standard.org/}'
def attributes(e):return {x.get('key'):x.get('value') for x in e if x.get('key')}
def percentile(values,p):
    if not values:return None
    values=sorted(values);pos=(len(values)-1)*p;a=int(pos);b=min(a+1,len(values)-1);return round(values[a]+(values[b]-values[a])*(pos-a),4)
def run(path,out):
    out.mkdir(parents=True,exist_ok=True);cases=[];activities=collections.Counter();edges=collections.defaultdict(list);variants=collections.Counter();issues=collections.Counter();terminal=collections.Counter()
    with gzip.open(path,'rb') as f:
        _,logroot=next(etree.iterparse(f,events=('start',),resolve_entities=False,no_network=True))
        namespace=etree.QName(logroot).namespace
        prefix='{'+namespace+'}' if namespace else ''
        f.seek(0)
        for _,trace in etree.iterparse(f,events=('end',),tag=prefix+'trace',resolve_entities=False,no_network=True):
            attrs=attributes(trace);events=[]
            for e in trace.findall(prefix+'event'):
                a=attributes(e);act=a.get('concept:name');stamp=a.get('time:timestamp')
                if not act or not stamp:issues['missing_activity_or_time']+=1;continue
                events.append((datetime.datetime.fromisoformat(stamp.replace('Z','+00:00')),act))
            if not events:issues['empty_case']+=1;trace.clear();continue
            if events!=sorted(events,key=lambda x:x[0]):issues['out_of_order_case']+=1
            events=sorted(events,key=lambda x:x[0]);seq=tuple(a for _,a in events);variants[seq]+=1;activities.update(seq);terminal[seq[-1]]+=1
            counts=collections.Counter(seq);repeated=sum(n-1 for n in counts.values() if n>1)
            paid=any(a=='Payment Handled' for a in seq);rejected=any('REJECTED' in a.upper() for a in seq)
            # Payment events can precede other administrative events; report both durations.
            first_paid=next((t for t,a in events if a=='Payment Handled'),None)
            cases.append({'year':events[0][0].year,'duration_days':(events[-1][0]-events[0][0]).total_seconds()/86400,'time_to_payment_days':(first_paid-events[0][0]).total_seconds()/86400 if first_paid else None,'events':len(events),'paid':paid,'rejected_event':rejected,'repeated_activity':repeated>0,'amount':attrs.get('Amount')})
            for (t1,a),(t2,b) in zip(events,events[1:]):edges[(a,b)].append((t2-t1).total_seconds()/86400)
            trace.clear()
            while trace.getprevious() is not None:del trace.getparent()[0]
    if not cases: raise ValueError('No usable cases; check XES namespace and input')
    def describe(group):
        paid=[c for c in group if c['paid']];return {'cases':len(group),'paid_cases':len(paid),'cases_with_rejection':sum(c['rejected_event'] for c in group),'cases_with_repeated_activity':sum(c['repeated_activity'] for c in group),'paid_time_to_payment_median_days':percentile([c['time_to_payment_days'] for c in paid],.5),'paid_time_to_payment_p90_days':percentile([c['time_to_payment_days'] for c in paid],.9),'observed_duration_median_days':percentile([c['duration_days'] for c in group],.5)}
    report={'source_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'events':sum(activities.values()),'overall':describe(cases),'by_year':{str(y):describe([c for c in cases if c['year']==y]) for y in sorted(set(c['year'] for c in cases))},'by_repetition':{label:describe([c for c in cases if c['repeated_activity']==flag]) for label,flag in [('repeated',True),('no_repetition',False)]},'terminal_activities':dict(terminal),'activities':dict(activities),'variants':len(variants),'data_quality':dict(issues),'top_variants':[{'activities':list(k),'cases':v} for k,v in variants.most_common(10)],'limits':'Calendar elapsed time, not active work; associations not causes. No payment event is not proof of non-payment. 2017/2018 coverage differs.'}
    (out/'results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    with (out/'transitions.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.writer(f);w.writerow(['from','to','occurrences','median_calendar_days','p90_calendar_days'])
        for (a,b),v in sorted(edges.items(),key=lambda x:-len(x[1])):w.writerow([a,b,len(v),percentile(v,.5),percentile(v,.9)])
    print(json.dumps({k:v for k,v in report.items() if k in ['events','overall','by_year','by_repetition','data_quality','variants']}))
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('log',type=Path);p.add_argument('--output',type=Path,default=Path('outputs'));a=p.parse_args();run(a.log,a.output)
