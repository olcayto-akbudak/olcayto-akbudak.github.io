"""Acceptance tests with explicit synthetic fixtures and optional official sources.

python -m unittest -v test_acceptance
RESEARCH_SOURCES=/path/to/downloads python -m unittest -v test_acceptance
"""
import csv,datetime,gzip,importlib.util,json,os,sqlite3,tempfile,unittest,zipfile
from pathlib import Path
from lxml import etree
ROOT=Path(__file__).parent
def module(folder,file):
    spec=importlib.util.spec_from_file_location(folder.replace('-','_'),ROOT/folder/file);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
preflight=module('ubl-tr-peppol','preflight.py');decision=module('efatura-karar-modeli','decision.py');fx=module('tcmb-kur','policy.py');mine=module('bpi2020-masraf','mine.py')
SOURCES=Path(os.environ['RESEARCH_SOURCES']) if os.getenv('RESEARCH_SOURCES') else None
def controls(folder):
    text=(ROOT/folder/('controls.sql' if folder=='erp-kapanis' else 'reconciliation.sql')).read_text()
    chunks=text.split('-- control: ')[1:]
    return {c.split('\n',1)[0]:c.split('\n',1)[1].strip() for c in chunks}

class SemanticChecks(unittest.TestCase):
    def test_official_examples_and_actual_package(self):
        if not SOURCES:self.skipTest('Set RESEARCH_SOURCES for official source checks')
        examples=zipfile.ZipFile(SOURCES/'peppol-examples.zip');tested=0
        for n in examples.namelist():
            if n.endswith('.xml'):
                root=etree.fromstring(examples.read(n))
                if etree.QName(root).localname=='Invoice':
                    with self.subTest(sample=n):self.assertEqual(preflight.check(root),[])
                    tested+=1
        self.assertEqual(tested,9)
        with tempfile.TemporaryDirectory() as d:
            preflight.run(SOURCES/'gib.zip',Path(d));r=json.loads((Path(d)/'results.json').read_text())
            self.assertEqual(r['invoice_examples'],28);self.assertEqual(r['examples_with_at_least_one_selected_gap'],28)
    def test_mutated_missing_reference_detected(self):
        if not SOURCES:self.skipTest('Official positive fixture required')
        with zipfile.ZipFile(SOURCES/'peppol-examples.zip') as z:
            n=next(n for n in z.namelist() if n.endswith('/base-example.xml'));root=etree.fromstring(z.read(n))
        for e in root.xpath('cbc:BuyerReference | cac:OrderReference',namespaces=preflight.NS):root.remove(e)
        self.assertIn('ROUTING',preflight.check(root))
    def test_customization_version_suffix_rejected(self):
        root=etree.Element('{urn:oasis:names:specification:ubl:schema:xsd:Invoice-2}Invoice')
        etree.SubElement(root,'{'+preflight.NS['cbc']+'}CustomizationID').text=preflight.CUSTOM+'::3.0.21'
        self.assertIn('SPEC',preflight.check(root))

class PackageRules(unittest.TestCase):
    def test_actual_changed_rule_boundary_cases(self):
        if not SOURCES:self.skipTest('Official packages required')
        import elementpath
        ns={'s':'http://purl.oclc.org/dsdl/schematron'}
        def rules(name):
            with zipfile.ZipFile(SOURCES/name) as z:
                code=etree.fromstring(z.read(next(n for n in z.namelist() if n.endswith('/UBL-TR_Codelist.xml'))))
                common=etree.fromstring(z.read(next(n for n in z.namelist() if n.endswith('/UBL-TR_Common_Schematron.xml'))))
            variables={e.get('name'):e.get('value').strip("'") for e in code.xpath('//s:let',namespaces=ns)}
            tests={e.get('id'):[a.get('test') for a in e.findall('s:assert',ns)] for e in common.xpath('//s:rule[@id]',namespaces=ns)}
            return tests,variables
        old,ov=rules('gib-efatura.zip');new,nv=rules('gib-efatura29.zip')
        def passes(tests,variables,node):return all(elementpath.select(node,test,namespaces=preflight.NS,variables=variables,fragment=True) for test in tests)
        for scheme,value,expected in [('PLAKA','34ABC123',True),('PLAKA','00ABC123',False),('PLAKA','82ABC123',False),('YABANCIPLAKA','AB-12',True),('YABANCIPLAKA','',False),('DORSE','34ABC123',False)]:
            node=etree.Element('{'+preflight.NS['cbc']+'}LicensePlateID',schemeID=scheme);node.text=value
            with self.subTest(scheme=scheme,value=value):self.assertEqual(passes(new['LicensePlateIDSchemeIDCheck'],nv,node),expected)
            if scheme=='DORSE':self.assertTrue(passes(old['LicensePlateIDSchemeIDCheck'],ov,node))
        for scheme,value,expected in [('DORSE','34ABC123',True),('YABANCIDORSE','AB-12',True),('DORSE','AB-12',False),('PLAKA','34ABC123',False)]:
            node=etree.Element('{'+preflight.NS['cbc']+'}ID',schemeID=scheme);node.text=value
            with self.subTest(dorse=scheme,value=value):self.assertEqual(passes(new['TransportEquipmentIDSchemeIDCheck'],nv,node),expected)
        shipment=etree.Element('{'+preflight.NS['cac']+'}Shipment')
        self.assertFalse(passes(old['LicensePlateIDCheck'],ov,shipment));self.assertTrue(passes(new['LicensePlateIDCheck'],nv,shipment))
        stage=etree.SubElement(shipment,'{'+preflight.NS['cac']+'}ShipmentStage');etree.SubElement(stage,'{'+preflight.NS['cac']+'}DriverPerson')
        self.assertFalse(passes(new['LicensePlateIDCheck'],nv,shipment))

class DecisionModel(unittest.TestCase):
    def base(self,**kw):return dict(profile='TEMELFATURA',type='SATIS',recipient_registered=True,registry_checked_at='2026-10-03T12:00:00Z',**kw)
    def test_return_profile_and_reference(self):
        d=self.base();d.update(profile='TICARIFATURA',type='IADE');self.assertIn('IADE_PROFILE',decision.review(d)['errors'])
        d['profile']='TEMELFATURA';self.assertEqual(decision.review(d)['status'],'REVIEW');d['original_invoice']='INV-1';self.assertEqual(decision.review(d)['status'],'SCOPED_CHECKS_PASSED')
    def test_energy_pair(self):
        d=self.base();d.update(profile='ENERJI',type='SATIS');self.assertIn('ENERJI_PAIR',decision.review(d)['errors']);d['type']='SARJ';self.assertNotIn('ENERJI_PAIR',decision.review(d)['errors'])
    def test_unknown_type_and_tax_basis(self):
        d=self.base();d['type']='UNKNOWN';self.assertEqual(decision.review(d)['status'],'BLOCKED');d['type']='ISTISNA';self.assertIn('TAX_REVIEW_REQUIRED',decision.review(d)['holds'])
    def test_technology_and_registry_evidence(self):
        d=self.base();d['type']='TEKNOLOJIDESTEK';self.assertIn('TECH_ARCHIVE',decision.review(d)['errors']);d['registry_checked_at']=None;self.assertIn('REGISTRY_EVIDENCE_REQUIRED',decision.review(d)['holds'])

class TaxModel(unittest.TestCase):
    def setUp(self):
        self.db=sqlite3.connect(':memory:');self.db.executescript((ROOT/'vergi-kod-modeli/schema.sql').read_text());self.db.execute('INSERT INTO code_release VALUES(?,?,?,?)',('r','https://example.test/source','a'*64,'2026-10-03'))
    def tearDown(self):self.db.close()
    def test_family_key_and_zeroes(self):
        for family,code in [('special_base','801'),('withholding','801'),('exemption','001')]:self.db.execute('INSERT INTO tax_code VALUES(?,?,?,?,?,?)',('r',family,code,'fixture','2026-01-01',None))
        self.assertEqual(self.db.execute('SELECT COUNT(*) FROM tax_code WHERE code="801"').fetchone()[0],2);self.assertEqual(self.db.execute('SELECT code FROM tax_code WHERE family="exemption"').fetchone()[0],'001')
    def test_unknown_code_rejected(self):
        self.db.execute('INSERT INTO invoice_line VALUES(1,"I","2026-10-03",10000,2000)')
        with self.assertRaises(sqlite3.IntegrityError):self.db.execute('INSERT INTO line_tax VALUES(1,"r","withholding","999",3,10,"D")')
    def test_ratio_and_applicability(self):
        self.db.execute('INSERT INTO tax_code VALUES("r","withholding","601","fixture","2026-01-01","2026-09-01")');self.db.execute('INSERT INTO invoice_line VALUES(1,"I","2026-10-03",10000,2000)')
        with self.assertRaises(sqlite3.IntegrityError):self.db.execute('INSERT INTO line_tax VALUES(1,"r","withholding","601",11,10,"D")')
        self.db.execute('INSERT INTO line_tax VALUES(1,"r","withholding","601",3,10,"D")');self.assertEqual(self.db.execute('SELECT line_id FROM applicability_exceptions').fetchall(),[(1,)])

class CloseControls(unittest.TestCase):
    def setUp(self):
        self.db=sqlite3.connect(':memory:');self.db.executescript((ROOT/'erp-kapanis/staging.sql').read_text());self.q=controls('erp-kapanis');self.params={'cutoff':'2026-10-01','price_tolerance':5}
    def tearDown(self):self.db.close()
    def delivery(self,id='D',qty=10):self.db.execute('INSERT INTO delivery VALUES(?,"C","S","2026-09-30",?,100)',(id,qty))
    def invoice(self,id='I',qty=10,date='2026-09-30',customer='C',item='S',price=100,kind='SALE',original=None):self.db.execute('INSERT INTO invoice_line VALUES(?,?,?,?,?,?,?,?)',(id,customer,item,date,kind,qty,price,original))
    def allocate(self,d='D',i='I',qty=10):self.db.execute('INSERT INTO allocation VALUES(?,?,?)',(d,i,qty))
    def result(self,key):return self.db.execute(self.q[key],self.params).fetchall()
    def test_split_invoice_without_fanout(self):
        self.delivery();self.invoice('I1',4);self.invoice('I2',6);self.allocate(i='I1',qty=4);self.allocate(i='I2',qty=6)
        for key in ['UNBILLED_DELIVERY','OVERALLOCATED_DELIVERY','OVERALLOCATED_INVOICE','UNMATCHED_INVOICE']:self.assertEqual(self.result(key),[])
    def test_open_delivery_and_unmatched_invoice(self):
        self.delivery();self.invoice();self.assertEqual(self.result('UNBILLED_DELIVERY'),[('D','S',10)]);self.assertEqual(self.result('UNMATCHED_INVOICE'),[('I',)])
    def test_overallocation_both_sides(self):
        self.delivery();self.invoice();self.allocate(qty=11);self.assertEqual(self.result('OVERALLOCATED_DELIVERY'),[('D',)]);self.assertEqual(self.result('OVERALLOCATED_INVOICE'),[('I',)])
    def test_customer_item_and_price_boundary(self):
        self.delivery();self.invoice(customer='OTHER',price=105);self.allocate();self.assertEqual(self.result('WRONG_ITEM_OR_CUSTOMER'),[('D','I')]);self.assertEqual(self.result('PRICE_REVIEW'),[]);self.db.execute('UPDATE invoice_line SET unit_minor=106');self.assertEqual(self.result('PRICE_REVIEW'),[('D','I')])
    def test_cutoff_and_credit_reference(self):
        self.delivery();self.invoice(date='2026-10-01');self.allocate();self.assertEqual(self.result('CUTOFF_MISMATCH'),[('D','I')]);self.invoice('R',kind='CREDIT',original='MISSING');self.assertEqual(self.result('INVALID_CREDIT_REFERENCE'),[('R',)]);self.db.execute('UPDATE invoice_line SET original_line_id="I" WHERE line_id="R"');self.assertEqual(self.result('INVALID_CREDIT_REFERENCE'),[])

class MigrationControls(unittest.TestCase):
    def setUp(self):self.db=sqlite3.connect(':memory:');self.db.executescript((ROOT/'erp-gecis/staging.sql').read_text());self.q=controls('erp-gecis')
    def tearDown(self):self.db.close()
    def test_net_equal_gross_wrong_and_currency(self):
        self.db.executescript('INSERT INTO source_master VALUES("S","fixture");INSERT INTO target_master VALUES("T","fixture");INSERT INTO mapping VALUES("S","T","A","D");INSERT INTO source_balance VALUES("S","TRY",100,80);INSERT INTO opening_balance VALUES("T","TRY",20,0);INSERT INTO opening_balance VALUES("T","EUR",5,0);')
        rows=self.db.execute(self.q['BALANCE_DIFFERENCE']).fetchall();self.assertEqual(set(rows),{('T','TRY',80,80),('T','EUR',-5,0)})
    def test_missing_mapping_target_duplicate_and_orphan(self):
        self.db.executescript('INSERT INTO source_master VALUES("S1","a"),("S2","b"),("S3","c");INSERT INTO mapping VALUES("S1","T","A","D"),("S2","T","A","D");INSERT INTO source_balance VALUES("X","TRY",3,0);')
        self.assertEqual(self.db.execute(self.q['MISSING_MAPPING']).fetchall(),[('S3',)]);self.assertEqual(len(self.db.execute(self.q['MISSING_TARGET']).fetchall()),2);self.assertEqual(self.db.execute(self.q['DUPLICATE_TARGET_REVIEW']).fetchall(),[('T',2)]);self.assertEqual(self.db.execute(self.q['ORPHAN_BALANCE']).fetchall(),[('X','TRY')])

class CurrencyPolicy(unittest.TestCase):
    def setUp(self):self.s={'date':datetime.date(2026,10,2),'sha256':'a'*64,'rates':{'USD':{'ForexBuying':fx.decimal.Decimal('48.9699'),'BanknoteBuying':None}}}
    def test_prior_bulletin_needs_policy(self):
        with self.assertRaises(ValueError):fx.select(self.s,datetime.date(2026,10,3),'USD','ForexBuying')
        self.assertTrue(fx.select(self.s,datetime.date(2026,10,3),'USD','ForexBuying',True)['previous_bulletin'])
    def test_future_stale_missing_type(self):
        for date,field in [(datetime.date(2026,10,1),'ForexBuying'),(datetime.date(2026,10,8),'ForexBuying'),(datetime.date(2026,10,2),'BanknoteBuying'),(datetime.date(2026,10,2),'guess')]:
            with self.subTest(date=date,field=field),self.assertRaises(ValueError):fx.select(self.s,date,'USD',field,True)
    def test_quote_unit_and_empty(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'x.xml';p.write_text('<Tarih_Date Tarih="02.10.2026"><Currency CurrencyCode="JPY"><Unit>100</Unit><ForexBuying>32.10</ForexBuying><BanknoteBuying/></Currency></Tarih_Date>');s=fx.read_snapshot(p);self.assertEqual(s['rates']['JPY']['ForexBuying'],fx.decimal.Decimal('0.321'));self.assertIsNone(s['rates']['JPY']['BanknoteBuying'])

class EventLog(unittest.TestCase):
    def test_namespace_and_payment_not_last_event(self):
        for namespace in ['', ' xmlns="http://www.xes-standard.org/"']:
            with tempfile.TemporaryDirectory() as d:
                p=Path(d)/'log.xes.gz';p.write_bytes(gzip.compress(('<log'+namespace+'><trace><event><string key="concept:name" value="Submitted"/><date key="time:timestamp" value="2026-01-01T00:00:00Z"/></event><event><string key="concept:name" value="Payment Handled"/><date key="time:timestamp" value="2026-01-03T00:00:00Z"/></event><event><string key="concept:name" value="Audit"/><date key="time:timestamp" value="2026-01-04T00:00:00Z"/></event></trace></log>').encode()));mine.run(p,Path(d)/'out');r=json.loads((Path(d)/'out/results.json').read_text());self.assertEqual(r['events'],3);self.assertEqual(r['overall']['paid_time_to_payment_median_days'],2);self.assertEqual(r['overall']['observed_duration_median_days'],3)

if __name__=='__main__':unittest.main()
