# Vergi kodu nerede yaşamalı?

Ürün ve cari kartları varsayılan sağlayabilir; işlem anındaki vergi kararı, sürüm ve dayanak fatura satırında izlenmelidir.

## English overview

A versioned ERP tax-code model with family-qualified identifiers, preserving leading zeroes and historical invoice decisions. Includes a source-derived catalog and executable referential and ratio constraints; legal effective dates are not inferred from ZIP timestamps.

## İş sorusu ve kaynak

Aynı ürün farklı işlem, alıcı ve hukuki dayanakla farklı vergi niteliği taşıyabilir. Bu nedenle ürün kartına tek istisna kodu yazıp tüm faturaları oradan beslemek yeterli değildir. Kod Listeleri 1.43 açıklamaları ile paket B’nin machine-readable istisna, tevkifat, özel matrah ve ihraç kayıtlı listeleri ayrı incelendi.

## Yöntem ve bulgu

Dört kod ailesi isim uzayı korunarak çıkarıldı. Kodlar sayı değil metin olarak tutuldu; baştaki sıfırlar korunuyor. Aynı sayısal değer farklı ailelerde görülebiliyor: örneğin 801 hem özel matrah hem tevkifat ailesinde yer alıyor. Anahtar yalnız code olursa anlam çakışır.

| Katman | Tutulacak bilgi | Tutulmaması gereken varsayım |
| --- | --- | --- |
| Kod sürümü | Kaynak URL, hash, erişim zamanı, onaylı geçerlilik | Dosya adı = hukuki yürürlük tarihi |
| Kod tanımı | Sürüm + aile + kod + açıklama | Sadece sayısal kod |
| Ürün/cari varsayılanı | İncelemeyi başlatan öneri ve koşul | Her işlem için kesin vergi kararı |
| Fatura satırı | İşlem tarihi, seçilen kod ailesi, oran, dayanak, onay | Sonraki kod güncellemesiyle geçmişi değiştirme |
| Belge toplamı | Satır kararlarından hesaplanan özet | Satır detayını kaybettiren tek dip kod |

## Doğrulama ve kabul kriterleri

| Kimlik | Kontrol | Beklenen davranış |
| --- | --- | --- |
| TAX-01 | Aile + sürüm + kod referansı | Katalogda olmayan birleşim FK ile reddedilir |
| TAX-02 | Başında sıfır olan kod | 001 metin olarak kalır; 1’e çevrilmez |
| TAX-03 | Tevkifat oranı | Pay/payda birlikte; pozitif ve pay ≤ payda |
| TAX-04 | Uygulanabilirlik tarihi | Onaylı tarih dışında işlem istisna raporuna gider |
| TAX-05 | Kod tipi + fatura tipi | Kaynak Schematron uygunluk kontrolü uygulanır; tek FK yeterli değil |
| TAX-06 | Kod güncellemesi | Eski belgenin sürüm/dayanak referansı değişmez |
| TAX-07 | Satır / dip toplam | Yuvarlama ve toplam mutabakatı ayrı kontrol |
| TAX-08 | Aynı kod farklı aile | 801 aile adı olmadan seçilemez |

## Karar ve değişiklik yönetimi

Sürüm tablosu + aileli katalog + işlem satırı kararı öneriyorum. Varsayılan değişikliği yeni taslakları etkiler; düzenlenmiş belgeler onaylı düzeltme süreci dışında yeniden hesaplanmaz. İşlem tarihiyle kod uygulanabilirliği, hukuki onay kaydına dayanır; ZIP içindeki dosya tarihi bu onayın yerini tutmaz.

## Sınırlar

SQLite şeması referans bütünlüğü ve oran biçimini çalıştırılabilir şekilde gösterir. Tam vergi hesabı, tüm fatura tipi kombinasyonları ve hukuki yürürlük takvimi uygulanmadı. CSV kataloğundaki machine-readable aile üyeliği hukuki kod açıklaması değildir; kılavuz ve uzman onayıyla birlikte kullanılır.

## Kaynaklar

- [GİB: Kod Listeleri 1.43 ve açıklamalar](https://ebelge.gib.gov.tr/dosyalar/kilavuzlar/UBLTR_1.2.1_Kilavuzlar.zip)
- [GİB: aile bazlı UBL-TR_Codelist.xml](https://ebelge.gib.gov.tr/dosyalar/kilavuzlar/e-FaturaPaketi%20(29).zip)

Yeniden üretme komutları paket kökündeki README.md içinde. Kaynak URL/hash kayıtları SOURCES.json içinde.
