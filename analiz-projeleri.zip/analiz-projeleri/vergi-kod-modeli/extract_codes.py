import argparse,csv,zipfile
from pathlib import Path
from lxml import etree
FAMILIES={'WithholdingTaxType':'withholding','istisnaTaxExemptionReasonCodeType':'exemption','ozelMatrahTaxExemptionReasonCodeType':'special_base','ihracExemptionReasonCodeType':'export_registered'}
def run(package,output):
    with zipfile.ZipFile(package) as z:
        name=next(n for n in z.namelist() if n.endswith('/UBL-TR_Codelist.xml'));root=etree.fromstring(z.read(name),etree.XMLParser(resolve_entities=False,no_network=True))
    rows=[]
    for variable,family in FAMILIES.items():
        value=root.xpath('string(//s:let[@name=$name]/@value)',namespaces={'s':'http://purl.oclc.org/dsdl/schematron'},name=variable)
        if not value:raise ValueError('Source variable missing: '+variable)
        rows.extend((family,c,'UBL-TR_Codelist.xml',variable) for c in value.strip("'").split(',') if c)
    with output.open('w',newline='',encoding='utf-8') as f:w=csv.writer(f);w.writerow(['family','code','source_file','source_variable']);w.writerows(rows)
    print(len(rows),'family-qualified entries')
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('package',type=Path);p.add_argument('--output',type=Path,default=Path('code-catalog.csv'));a=p.parse_args();run(a.package,a.output)
