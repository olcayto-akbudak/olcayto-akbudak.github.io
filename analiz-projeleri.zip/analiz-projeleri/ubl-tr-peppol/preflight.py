"""Selected semantic gap checks; NOT a Peppol compliance validator.

Input is a ZIP obtained directly from GİB. XML is parsed without network access.
No invoice conversion or changes to signed source documents are performed.
"""
import argparse, csv, hashlib, io, json, zipfile
from pathlib import Path
from lxml import etree

NS = {'cbc': 'urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2',
      'cac': 'urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2'}
CUSTOM = 'urn:cen.eu:en16931:2017#compliant#urn:fdc:peppol.eu:2017:poacc:billing:3.0'
PROFILES = {'urn:fdc:peppol.eu:2017:poacc:billing:01:1.0',
            'urn:peppol:bis:billing_with_response'}
TYPE_CODES = set('71 80 82 84 102 218 219 326 331 380 382 383 384 386 388 393 395 553 575 623 780 817 870 875 876 877'.split())
RULES = {
 'SPEC': 'CustomizationID differs from Peppol R004',
 'PROCESS': 'ProfileID outside the two billing profiles scoped in this study',
 'TYPE': 'InvoiceTypeCode outside P0100 scoped code list',
 'ROUTING': 'No buyer reference or purchase order reference (R003)',
 'SELLER_ENDPOINT': 'No seller EndpointID with schemeID',
 'BUYER_ENDPOINT': 'No buyer EndpointID with schemeID',
 'SELLER_COUNTRY': 'No seller country IdentificationCode',
 'BUYER_COUNTRY': 'No buyer country IdentificationCode',
 'SELLER_NAME': 'No seller PartyLegalEntity/RegistrationName',
 'BUYER_NAME': 'No buyer PartyLegalEntity/RegistrationName',
 'VAT_BREAKDOWN': 'At least one document VAT breakdown has no category ID or VAT scheme ID',
 'VAT_LINE': 'At least one invoice line has no classified VAT category ID or VAT scheme ID',
}

def check(root):
    def text(path): return root.xpath('string('+path+')', namespaces=NS).strip()
    def exists(path): return bool(root.xpath(path, namespaces=NS))
    findings = []
    spec = text('cbc:CustomizationID')
    if not spec.startswith(CUSTOM) or '::' in spec: findings.append('SPEC')
    if text('cbc:ProfileID') not in PROFILES: findings.append('PROCESS')
    if text('cbc:InvoiceTypeCode') not in TYPE_CODES: findings.append('TYPE')
    if not (text('cbc:BuyerReference') or text('cac:OrderReference/cbc:ID')): findings.append('ROUTING')
    for party, prefix in [('AccountingSupplierParty','SELLER'), ('AccountingCustomerParty','BUYER')]:
        base = 'cac:'+party+'/cac:Party/'
        if not text(base+'cbc:EndpointID') or not text(base+'cbc:EndpointID/@schemeID'): findings.append(prefix+'_ENDPOINT')
        if not text(base+'cac:PostalAddress/cac:Country/cbc:IdentificationCode'): findings.append(prefix+'_COUNTRY')
        if not text(base+'cac:PartyLegalEntity/cbc:RegistrationName'): findings.append(prefix+'_NAME')
    for path, key in [('cac:TaxTotal/cac:TaxSubtotal/cac:TaxCategory','VAT_BREAKDOWN'),
                      ('cac:InvoiceLine/cac:Item/cac:ClassifiedTaxCategory','VAT_LINE')]:
        categories=root.xpath(path,namespaces=NS)
        missing=not categories if key=='VAT_BREAKDOWN' else len(categories)!=len(root.xpath('cac:InvoiceLine',namespaces=NS))
        if missing or any(not c.xpath('normalize-space(cbc:ID)',namespaces=NS) or c.xpath('normalize-space(cac:TaxScheme/cbc:ID)',namespaces=NS)!='VAT' for c in categories): findings.append(key)
    return findings

def run(package, output):
    output.mkdir(parents=True, exist_ok=True)
    rows=[]
    with zipfile.ZipFile(package) as archive:
        for name in sorted(archive.namelist()):
            if not name.lower().endswith('.xml'): continue
            root=etree.fromstring(archive.read(name),parser=etree.XMLParser(resolve_entities=False,no_network=True))
            if root.tag!='{urn:oasis:names:specification:ubl:schema:xsd:Invoice-2}Invoice':continue
            gaps=check(root)
            rows.append({'sample':Path(name).name,'profile':root.findtext('cbc:ProfileID',namespaces=NS),'type':root.findtext('cbc:InvoiceTypeCode',namespaces=NS),'line_count':len(root.findall('cac:InvoiceLine',namespaces=NS)),**{k:int(k in gaps) for k in RULES}})
    with (output/'sample-gaps.csv').open('w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    report={'source_sha256':hashlib.sha256(package.read_bytes()).hexdigest(),'invoice_examples':len(rows),'examples_with_at_least_one_selected_gap':sum(any(r[k] for k in RULES) for r in rows),'gap_counts':{k:sum(r[k] for r in rows) for k in RULES},'scope':'12 selected preflight checks; no full XSD, CEN/Peppol Schematron, code-list, country-rule or transport certification'}
    (output/'results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(report,ensure_ascii=False))

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('package',type=Path);parser.add_argument('--output',type=Path,default=Path('outputs'));args=parser.parse_args();run(args.package,args.output)
