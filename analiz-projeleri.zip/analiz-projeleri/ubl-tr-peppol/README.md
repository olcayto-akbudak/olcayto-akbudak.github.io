# Aynı UBL, farklı iş kuralları.

Bir Türk ERP’sindeki faturanın AB’deki alıcıya aktarılması için hangi bilgi korunmalı, hangisi yeniden yapılandırılmalı ve hangi karar insan onayı gerektiriyor?

## English overview

A 40-row field mapping and 12 scoped checks across 28 official GİB invoice examples. The finding concerns cross-profile gaps, not invalid Turkish invoices. Includes requirements and a decision note; not a certified converter.

## İş sorusu ve kapsam

Bu çalışma, UBL-TR XML’ini Peppol BIS Billing 3.0’a doğrudan gönderme varsayımını sınar. EN 16931 semantik çekirdek; Peppol bu çekirdeği süreç, kod listesi ve ağ gereksinimleriyle daraltır. Bir XML’in UBL şemasına uyması, hedef iş kurallarına uyduğunu göstermez.

Kapsam: GİB UBL-TR 1.2.1 paketindeki Invoice köklü örnekler ve Peppol Mayıs 2026 / 3.0.21 dokümantasyonu. Standartların tümünü kapsayan bir dönüştürücü veya üretim sertifikasyonu değildir.

## Kaynak ve yöntem

GİB paketinden 28 fatura XML’i ayrıldı; uygulama yanıtı ve irsaliye dosyaları örnekleme alınmadı. Alan eşlemesi 40 satırda kaynak yolu, hedef iş terimi, aksiyon ve karar gerekçesiyle kuruldu. Ayrıca 12 seçilmiş ön kontrol her XML üzerinde çalıştırıldı.

Kontroller: uyarlama/profil/tip, alıcı referansı, iki tarafın elektronik adresi, ülke kodu, yasal adı ve belge/satır VAT sınıflandırması. Peppol’un resmî örnekleri pozitif kontrol olarak kullanıldı. Ülkeye özgü profiller bu ön kontrolün kapsamı dışındadır.

## Bulgu: isim benzerliği yeterli değil

28 örneğin tamamında seçilen 12 ön kontrolün her biri bir eşleme boşluğu buldu. Bu sonuç GİB örneklerinin hatalı olduğu anlamına gelmez; farklı bir hedef profile değiştirilmeden gönderilemeyeceklerini gösterir. Örnekler teknik eğitim belgeleridir, gerçek ERP faturası veya AB’ye satış örneklemi değildir.

| Boşluk | Kaynakta görülen | Hedefte gerekli | Karar |
| --- | --- | --- | --- |
| Uyarlama ve süreç | TR1.2; TEMELFATURA/TICARIFATURA ve yerel profiller | Peppol uyarlama kimliği ve seçilmiş iş süreci | Sadece kimlik değiştirerek uyum iddiası kurma |
| Alıcı yönlendirme | BuyerReference / sipariş referansı yok | R003: alıcı referansı veya satın alma siparişi | Alıcıdan/ERP iş akışından temin et |
| Ana veri | PartyName/Person; ülke adı | Yasal ad, ülke kodu, endpoint + schemeID | Doğrulanmış cari ve ağ bilgisi ekle |
| Vergi | Yerel vergi türü ve TaxTotal | Belge VAT kategorisi ve satır ClassifiedTaxCategory | Vergi kararı + konum değişikliği |
| İade/tevkifat | IADE / WithholdingTaxTotal | İşleme uygun fatura/credit note ve vergi anlamı | Otomatik 381 veya AE eşlemesi yapma |

## Alan eşleme matrisi

“Koru” yine hedef validasyonunu gerektirir. “Karar” sınıfındaki alanlar vergi veya iş süreci anlamı onaylanmadan çevrilmez. Örneklerde alanın yokluğu, tüm UBL-TR faturalarında yasak olduğu anlamına gelmez.

| Terim | Alan | Kaynak | Hedef | Aksiyon / gerekçe |
| --- | --- | --- | --- | --- |
| BT-24 | Uyarlama kimliği | cbc:CustomizationID | cbc:CustomizationID | Dönüştür — TR1.2 yerine hedef uyarlama URN; belgeyi sadece yeniden etiketleme. |
| BT-23 | İş süreci | cbc:ProfileID | cbc:ProfileID | Karar — TEMEL/TICARI ile Peppol 01 veya yanıtlı profil aynı iş akışı değildir. |
| BT-1 | Fatura numarası | cbc:ID | cbc:ID | Koru — Fatura numarasını koru; UUID ile değiştirme. |
| BT-2 | Düzenleme tarihi | cbc:IssueDate | cbc:IssueDate | Koru — Takvim tarihini saat dilimi dönüşümüyle bir gün kaydırma. |
| BT-3 | Fatura tipi | cbc:InvoiceTypeCode | cbc:InvoiceTypeCode | Karar — SATIS için normal fatura 380 adaydır; IADE otomatik CreditNote 381 değildir. |
| BT-5 | Belge para birimi | cbc:DocumentCurrencyCode | cbc:DocumentCurrencyCode | Kontrol — Hedef sürüm ISO 4217 kod listesine göre doğrula. |
| BT-6 | Vergi muhasebe para birimi | cbc:TaxCurrencyCode | cbc:TaxCurrencyCode | Karar — Hedef ülke gereksinimi ve ikinci VAT toplamı birlikte tasarlanır. |
| BT-9 | Vade | cac:PaymentTerms/cbc:PaymentDueDate | cbc:DueDate | Dönüştür — Vade tarihinin kaynak konumu ile hedef konumu farklıdır. |
| BT-20 | Ödeme koşulu | cac:PaymentTerms/cbc:Note | cac:PaymentTerms/cbc:Note | Kontrol — Ödeme koşulu metni ile vade tarihini birbirine karıştırma. |
| BT-10 | Alıcı yönlendirme referansı | ERP iş akışı / alıcıdan alınan referans | cbc:BuyerReference | Zenginleştir — Referans veya satın alma siparişi R003 için gerekir; uydurma değer üretme. |
| BT-13 | Satın alma siparişi | cac:OrderReference/cbc:ID | cac:OrderReference/cbc:ID | Kontrol — Alıcının satın alma siparişi ile satıcının siparişini ayır. |
| BT-25 | Önceki fatura | cac:BillingReference/cac:InvoiceDocumentReference/cbc:ID | cac:BillingReference/cac:InvoiceDocumentReference/cbc:ID | Kontrol — Düzeltme/iade ilişkisinin taraf ve belge anlamını doğrula. |
| BT-27 | Satıcı yasal adı | cac:Party/cac:PartyName/cbc:Name | cac:Party/cac:PartyLegalEntity/cbc:RegistrationName | Zenginleştir — Ticari adı otomatik yasal ad sayma; resmi cari kaydından onayla. |
| BT-44 | Alıcı yasal adı | cac:Party/cac:PartyName veya cac:Person | cac:Party/cac:PartyLegalEntity/cbc:RegistrationName | Zenginleştir — Gerçek kişi/tüzel kişi ayrımı ve yasal adın kaynağı kayıtlı olmalı. |
| BT-34 | Satıcı elektronik adresi | GİB gönderici alias bilgisi | cac:AccountingSupplierParty/cac:Party/cbc:EndpointID | Zenginleştir — Alias ile Peppol EAS adresi eşdeğer değildir; doğrulanmış katılımcı bilgisi gerekir. |
| BT-49 | Alıcı elektronik adresi | GİB posta kutusu / cari entegrasyon bilgisi | cac:AccountingCustomerParty/cac:Party/cbc:EndpointID | Zenginleştir — Alıcı endpoint ve schemeID; taşıma zarfındaki kimlik ile tutarlı olmalı. |
| BT-31 | Satıcı VAT kimliği | cac:PartyIdentification/cbc:ID[@schemeID="VKN"] | cac:PartyTaxScheme/cbc:CompanyID | Karar — VKN üzerine ülke öneki eklemek VAT kaydı doğrulaması değildir. |
| BT-48 | Alıcı VAT kimliği | Cari vergi kimlik kaydı | cac:PartyTaxScheme/cbc:CompanyID | Karar — Vergi kimliği ile ağ katılımcısı farklı kimlik alanlarıdır. |
| BT-40 | Satıcı ülke kodu | cac:Country/cbc:Name | cac:Country/cbc:IdentificationCode | Zenginleştir — Ülke adı yerine ISO alpha-2; isim eşlemesi belirsizse durdur. |
| BT-55 | Alıcı ülke kodu | cac:Country/cbc:Name | cac:Country/cbc:IdentificationCode | Zenginleştir — Alıcının gerçek ülkesini kullan; AB varsayımı yapma. |
| BT-81 | Ödeme aracı | cac:PaymentMeans/cbc:PaymentMeansCode | cac:PaymentMeans/cbc:PaymentMeansCode | Kontrol — UNCL4461 hedef sürüm kodları ve gerekli hesap alanları birlikte kontrol edilir. |
| BT-84 | Ödeme hesabı | cac:PaymentMeans/cac:PayeeFinancialAccount/cbc:ID | cac:PaymentMeans/cac:PayeeFinancialAccount/cbc:ID | Kontrol — Hesap kimliği ve ödeme yöntemine bağlı kurallar doğrulanır. |
| BT-116 | VAT matrahı | cac:TaxSubtotal/cbc:TaxableAmount | cac:TaxSubtotal/cbc:TaxableAmount | Dönüştür — Kategori ve oran bazında gruplandır; farklı vergi türlerini tek VAT toplamında toplama. |
| BT-117 | VAT tutarı | cac:TaxSubtotal/cbc:TaxAmount | cac:TaxSubtotal/cbc:TaxAmount | Dönüştür — Matrah × oran ve hedef yuvarlama toleransı ile yeniden kontrol et. |
| BT-118 | VAT kategorisi | cac:TaxCategory/cac:TaxScheme/cbc:TaxTypeCode | cac:TaxCategory/cbc:ID | Karar — 0015 vergi türüdür; S/E/Z/O gibi kategori seçimi vergi kararına dayanır. |
| BT-119 | VAT oranı | cac:TaxSubtotal/cbc:Percent | cac:TaxSubtotal/cac:TaxCategory/cbc:Percent | Dönüştür — Oranın XML konumu değişir; sıfır oran istisna gerekçesini tek başına belirlemez. |
| BT-121 | İstisna gerekçe kodu | cbc:TaxExemptionReasonCode (GİB) | cbc:TaxExemptionReasonCode (VATEX) | Karar — 301 gibi yerel kodun VATEX karşılığını otomatik üretme; onaylı gerekçe eşlemesi gerekir. |
| BT-120 | İstisna gerekçe metni | cbc:TaxExemptionReason | cbc:TaxExemptionReason | Kontrol — Hedef kategoriye uygun gerekçe ve dil gereksinimini doğrula. |
| BT-106 | Satır toplamı | cac:LegalMonetaryTotal/cbc:LineExtensionAmount | Aynı XML yolu | Kontrol — Toplam satır neti ile eşitlik; iki ondalık basamak kontrolü. |
| BT-109 | Vergi hariç toplam | cac:LegalMonetaryTotal/cbc:TaxExclusiveAmount | Aynı XML yolu | Kontrol — Satır neti - belge indirimi + belge masrafı kontrol edilir. |
| BT-112 | Vergi dahil toplam | cac:LegalMonetaryTotal/cbc:TaxInclusiveAmount | Aynı XML yolu | Kontrol — Vergi hariç toplam + VAT tutarı; ÖTV/diğer vergiler ayrı değerlendirilir. |
| BT-115 | Ödenecek toplam | cac:LegalMonetaryTotal/cbc:PayableAmount | Aynı XML yolu | Karar — Tevkifat, ön ödeme ve yuvarlama etkisini koru; tutarı sessizce değiştirme. |
| BT-126 | Satır kimliği | cac:InvoiceLine/cbc:ID | Aynı XML yolu | Koru — Belge içinde tekil satır kimliği ve izlenebilir kaynak satırı. |
| BT-129/130 | Miktar ve birim | cac:InvoiceLine/cbc:InvoicedQuantity/@unitCode | Aynı XML yolu | Kontrol — UNECE hedef birimi; baz birim dönüşümü miktar ve fiyatı birlikte etkiler. |
| BT-146 | Birim fiyat | cac:InvoiceLine/cac:Price/cbc:PriceAmount | Aynı XML yolu | Kontrol — Fiyat baz miktarı ile satır net hesabını doğrula. |
| BT-153 | Mal/hizmet adı | cac:InvoiceLine/cac:Item/cbc:Name | Aynı XML yolu | Koru — Ürün adını koru; kod ile ad alanını değiştirme. |
| BT-151/152 | Satır VAT sınıfı | cac:InvoiceLine/cac:TaxTotal/... | cac:InvoiceLine/cac:Item/cac:ClassifiedTaxCategory | Dönüştür — Satır vergi türünü hedef kategori/oran grubuna taşı; karar onayı olmadan sınıf üretme. |
| BG-24 | Ek belgeler | cac:AdditionalDocumentReference | Aynı XML grubu | Kontrol — XSLT ekini otomatik hedef eki sayma; MIME, ad ve belge amacı denetlenir. |
| Yerel | İmza ve ETTN | ext:UBLExtensions / cac:Signature / cbc:UUID | Doğrudan çekirdek eşlemesi yok | Arşiv — İmzalı özgün belgeyi sakla; türetilen belge ile hash bağlantısı kur. |
| Yerel | Tevkifat toplamı | cac:WithholdingTaxTotal | Doğrudan çekirdek eşlemesi yok | Karar — Yerel tevkifatı otomatik AE/reverse-charge kabul etme; işlem ve ülke incelemesi gerekir. |

## Gereksinim ve karar notu

| Kimlik | Alan | Gereksinim | Kabul kriteri |
| --- | --- | --- | --- |
| REQ-01 | Belge kimliği | İmzalı kaynak ve türetilen hedef ayrı kayıt | Kaynak hash sabit; fatura ID korunur; dönüşüm sürümü kaydedilir |
| REQ-02 | Hedef profil | Alıcı kapasitesine göre süreç seçimi | Profil 01 veya yanıtlı profil açık seçilir; SMP kaydı kontrol edilir |
| REQ-03 | Yönlendirme | Alıcı referansının talep edilmesi | BuyerReference veya OrderReference eksikse gönderim durur |
| REQ-04 | Katılımcı kimliği | Endpoint ve schemeID kaynağı | Alias/VKN otomatik endpoint olmaz; onaylı kimlik ve zarf aynı |
| REQ-05 | Yasal ad/ülke | Ana veri zenginleştirmesi | Ülke kodu ve yasal ad açık kaynaktan doğrulanır; belirsiz eşleme engellenir |
| REQ-06 | Vergi kararı | Kategori ve gerekçe onayı | Sıfır oran/yerel kod tek başına hedef sınıfı üretmez |
| REQ-07 | İade/tevkifat | İşlem sınıfı incelemesi | IADE ve TEVKIFAT otomatik CreditNote/AE olmaz |
| REQ-08 | Hesaplama | Kesin ondalık ve mutabakat | Satır, belge, vergi ve payable eşitlikleri; fark eşiği aşılırsa blok |
| REQ-09 | Kod listesi | Sürüm pinleme | Para, birim, EAS ve VATEX listeleri hedef artefakt sürümüyle saklanır |
| REQ-10 | Doğrulama | Katmanlı geçiş kapısı | UBL XSD + CEN + Peppol + ülke kuralları + taşıma doğrulanır |
| REQ-11 | Teslimat kanıtı | Ağ sonucu ve iş yanıtı ayrı | Teknik teslimat faturanın kabul edildiği anlamına gelmez |
| REQ-12 | Durdurma kararı | Veri uydurmama | Eksik VAT/endpoint/gerekçe alanları tahminle doldurulmaz |

Karar: İmzalı yerel belgeyi koruyan, ortak fatura modelinden hedef profili üreten bir aktarım katmanı öneriyorum. Alan eksikliği ile vergi anlamı belirsizliğini ayrı hata sınıfları yaparım. Endpoint, yasal ad ve vergi gerekçesi tahminle doldurulmaz. İlk pilot, tarafları ve işlem türü doğrulanmış normal faturalarla sınırlanır. İade, tevkifat, ÖTV ve özel profiller ayrı karar kapısına gider.

## Sınırlar ve uygulama kapısı

- Ön kontrol tam Peppol validatörü değildir; sıfır seçilmiş boşluk, uyum sertifikası değildir.
- UBL XSD, CEN/Peppol Schematron, hedef ülke kuralları, geçerli kod listeleri ve taşıma zarfı ayrıca doğrulanmalıdır.
- AB’deki alıcıya fatura kesmenin hukuki yöntemi, ülke, işlem, kayıt ve kanal koşullarına göre ayrıca değerlendirilir. Teknik eşleme Türk veya AB mevzuatına uyum hükmü vermez.
- Kaynak imzası düzenlenmiş hedef XML’e taşınmış sayılmaz; iki belge arasındaki ilişki hash ve dönüşüm sürümüyle izlenir.

## Kaynaklar

- [GİB: UBL-TR XML ve XSD paketi](https://ebelge.gib.gov.tr/dosyalar/kilavuzlar/UBL-TR1.2.1_Paketi.zip)
- [Peppol: sürüm 3.0.21 notları](https://docs.peppol.eu/poacc/billing/3.0/release-notes/)
- [Peppol: Invoice sözdizimi ve alan bazlı bağlantılar](https://docs.peppol.eu/poacc/billing/3.0/syntax/ubl-invoice/)
- [Peppol: doğrulama ve zarf uyumu](https://docs.peppol.eu/poacc/billing/3.0/compliance/)
- [Avrupa Komisyonu: EN 16931 semantik model](https://ec.europa.eu/digital-building-blocks/sites/spaces/DIGITAL/pages/467108926/Compliance+with+eInvoicing+standard)

Yeniden üretme komutları paket kökündeki README.md içinde. Kaynak URL/hash kayıtları SOURCES.json içinde.
