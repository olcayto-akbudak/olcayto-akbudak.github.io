# Bugünün dosyası, bugünün kuru mu?

Kurun alınma zamanı, bülten tarihi, kur türü ve birimini birbirinden ayıran bir ERP entegrasyon politikası.

## English overview

Requirements based on an actual TCMB XML snapshot. Separates retrieval time, bulletin date, rate type and quoted unit. Prior-day use needs an explicit policy; invoice tax interpretation remains unverified and is not automated.

## İş sorusu ve kaynak

TCMB today.xml adresi sabittir; içindeki bülten tarihi bugünden eski olabilir. 3 Ekim 2026 Cumartesi günü alınan gerçek dosyanın Tarih alanı 02.10.2026, bülten numarası 2026/186. URL adını işlem tarihi saymak sessiz yanlış fiyatlamaya yol açabilir.

TCMB kaynakları iş günü, tatil ve yarım gün durumunu açıklıyor. Gösterge kur sayfası 15.30 ilanını belirtirken otomatik erişim SSS’si kontroller sonrası 16.00–16.30 yayın penceresini de söylüyor. Bu yüzden tek saatlik cron sonucuna güvenmek yerine içerik tarihini denetlemek gerekir.

## Yöntem ve sözleşme

- Bülten tarihi, numarası, erişim zamanı, kaynak URL ve SHA-256 saklanır.
- Kur alanı açık seçilir: ForexBuying, ForexSelling, BanknoteBuying veya BanknoteSelling. Eksik alan başka türden doldurulmaz.
- Unit dikkate alınır; örneğin 100 birimlik kotasyon bir birim kuru değildir. Decimal kullanılır; binary float hesaplamaya girmez.
- İstenen işlem tarihi ile bülten tarihi karşılaştırılır; eski/güncel/gelecek ve izinli önceki bülten ayrılır.
- Resmi tatil ve yarım gün takvimi ayrı sürümlü girdi olmalıdır. Gün farkı tek başına iş günü hesabı değildir.

## Gereksinim ve sınır durumları

| Durum | Davranış önerisi | Kabul |
| --- | --- | --- |
| Hafta sonu / tatil | Onaylı politika varsa önceki bülten; görünür tarih | Sessiz bugünkü kur etiketi yok |
| İş günü yayın öncesi | Önceki bülten veya bekleme; firma politikası | İşlem ve bülten tarihi birlikte |
| Yayın saati sonrası eski dosya | Sınırlı backoff; son geçerli snapshot korunur | Yeni diye eski veri yazılmaz |
| HTTP/XML hatası | Kayıtlı snapshotı değiştirme; alarm | Eksik dosya sıfır kur olmaz |
| Kur türü eksik | Blok / inceleme | Alış yoksa satışa otomatik geçilmez |
| Unit = 100 | Değer / 100 | 100 kat fiyatlama önlenir |
| Geçmiş fatura | Arşiv tarihli bülten ve onaylı kural | today.xml ile geçmiş tarih fiyatlanmaz |
| Bülten gelecekte | Reddet | İşlemden ileri tarihli kur yok |
| Aynı tarih farklı hash | Yeni revizyon kaydı + inceleme | Önceki kanıt silinmez |
| Uzun kesinti | Onaylı azami yaşa göre blok | Takvim günü eşiği hukuki kural diye sunulmaz |

## Bulgu ve karar

Gerçek dosyada dört kur türü ayrı alanlar ve bazı alanlar boş. Parser boş alanı None olarak korur ve Unit üzerinden birim başına kuru hesaplar. Örnek politika tarihi 3 Ekim istediğinde 2 Ekim snapshotını ancak allow_previous açık ise döndürür; sonuçta previous_bulletin ve iki tarih açık kalır.

Karar: Kur indirme, teknik kur seçme politikası ve faturada uygulanacak vergi/muhasebe kararı üç ayrı sorumluluk olsun. Günlük entegrasyon güncel snapshotı saklasın; belge kayıt anında seçilen kaynak ve kur türü sabitlensin. Dört günlük azami yaş kodda gösterim varsayımıdır, hukuki kural değildir.

## Vergi kararı ve sınırlar

Hangi faturada hangi kur türü ve tarihin zorunlu olduğu bu çalışmada hükme bağlanmadı. Mali müşavir teyidi alınmadı; alınmış gibi gösterilmez. Üretim için mevzuat, işlem niteliği ve onaylayan bilgisiyle ayrı bir kur politikası kararı gereklidir. Parser/politika prototipi HTTP retry, zamanlayıcı, resmi tatil takvimi veya geçmiş bülten indiricisi içermez. Bunlar gereksinim olarak tanımlandı, uygulanmış özellik olarak sunulmadı.

## Kaynaklar

- [TCMB: indirilen günlük XML kaynağı](https://www.tcmb.gov.tr/kurlar/today.xml)
- [TCMB: gösterge kur ve tatil açıklaması](https://www.tcmb.gov.tr/wps/wcm/connect/TR/TCMB%2BTR/Main%2BMenu/Temel%2BFaaliyetler/Doviz%2BEfektif/Doviz%2Bve%2BEfektif%2BPiyasalari/Gosterge%2BNiteligindeki%2BKurlar)
- [TCMB: otomatik erişim ve yayın penceresi](https://www.tcmb.gov.tr/wps/wcm/connect/TR/TCMB%2BTR/Main%2BMenu/Banka%2BHakkinda/Sikca%2BSorulan%2BSorular/Doviz%2BKuru%2BPolitikasi%2Bve%2BRezerv%2BYonetimi/)

Yeniden üretme komutları paket kökündeki README.md içinde. Kaynak URL/hash kayıtları SOURCES.json içinde.
