"""Parse an actual TCMB snapshot; application policy requires explicit rate type.

The rate selector is an engineering policy proposal, not a tax interpretation.
"""
import datetime,decimal,hashlib,json
from pathlib import Path
from lxml import etree
FIELDS={'ForexBuying','ForexSelling','BanknoteBuying','BanknoteSelling'}
def read_snapshot(path):
    content=Path(path).read_bytes();root=etree.fromstring(content,etree.XMLParser(resolve_entities=False,no_network=True))
    date=datetime.datetime.strptime(root.get('Tarih'),'%d.%m.%Y').date();rates={}
    for node in root.findall('Currency'):
        code=node.get('CurrencyCode');unit=decimal.Decimal(node.findtext('Unit'))
        if unit<=0:raise ValueError('Invalid unit')
        rates[code]={field:(decimal.Decimal(node.findtext(field))/unit if node.findtext(field) else None) for field in FIELDS}
    return {'date':date,'sha256':hashlib.sha256(content).hexdigest(),'bulletin':root.get('Bulten_No'),'rates':rates}
def select(snapshot,requested_date,currency,rate_type,allow_previous=False,max_age_days=4):
    if rate_type not in FIELDS:raise ValueError('Explicit rate type required')
    age=(requested_date-snapshot['date']).days
    if age<0:raise ValueError('Future snapshot cannot price a historical transaction')
    if age>max_age_days:raise ValueError('Snapshot exceeds configured calendar-day limit')
    if age and not allow_previous:raise ValueError('Previous bulletin requires approved policy')
    value=snapshot['rates'].get(currency,{}).get(rate_type)
    if value is None:raise ValueError('Rate missing; no fallback to a different rate type')
    return {'rate_per_unit':str(value),'requested_date':str(requested_date),'bulletin_date':str(snapshot['date']),'rate_type':rate_type,'currency':currency,'source_sha256':snapshot['sha256'],'previous_bulletin':bool(age)}
if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('xml');p.add_argument('--date',required=True);p.add_argument('--currency',default='USD');p.add_argument('--type',required=True,choices=sorted(FIELDS));p.add_argument('--allow-previous',action='store_true');a=p.parse_args();print(json.dumps(select(read_snapshot(a.xml),datetime.date.fromisoformat(a.date),a.currency,a.type,a.allow_previous),indent=2))
