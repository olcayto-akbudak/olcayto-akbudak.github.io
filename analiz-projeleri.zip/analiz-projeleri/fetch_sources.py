"""Download source snapshots only after checking their published evidence hashes.

Mutable URLs may no longer match: fail explicitly rather than silently replacing
the input evidence. Source files are excluded from the published source package.
"""
import argparse,hashlib,json,urllib.request
from pathlib import Path
def run(dest):
    dest.mkdir(parents=True,exist_ok=True)
    for source in json.loads((Path(__file__).parent/'SOURCES.json').read_text()):
        if not source.get('download_for_reproduction'):continue
        path=dest/source['file']
        if path.exists():data=path.read_bytes()
        else:
            with urllib.request.urlopen(source['url'],timeout=45) as response:data=response.read()
        if hashlib.sha256(data).hexdigest()!=source['sha256']:raise ValueError('Snapshot changed: '+source['file']+'. Obtain the recorded version; do not substitute without a new analysis.')
        path.write_bytes(data);print(source['file'],'verified')
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=Path('sources'));a=p.parse_args();run(a.output)
