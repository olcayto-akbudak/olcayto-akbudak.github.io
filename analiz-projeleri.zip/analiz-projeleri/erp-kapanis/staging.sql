PRAGMA foreign_keys=ON;
CREATE TABLE delivery(delivery_id TEXT PRIMARY KEY,customer_id TEXT NOT NULL,item_id TEXT NOT NULL,delivered_at TEXT NOT NULL,base_quantity INTEGER NOT NULL CHECK(base_quantity>0),agreed_unit_minor INTEGER NOT NULL);
CREATE TABLE invoice_line(line_id TEXT PRIMARY KEY,customer_id TEXT NOT NULL,item_id TEXT NOT NULL,issued_at TEXT NOT NULL,kind TEXT NOT NULL CHECK(kind IN ('SALE','CREDIT')),base_quantity INTEGER NOT NULL CHECK(base_quantity>0),unit_minor INTEGER NOT NULL,original_line_id TEXT);
CREATE TABLE allocation(delivery_id TEXT NOT NULL,line_id TEXT NOT NULL,base_quantity INTEGER NOT NULL CHECK(base_quantity>0),PRIMARY KEY(delivery_id,line_id),FOREIGN KEY(delivery_id) REFERENCES delivery(delivery_id),FOREIGN KEY(line_id) REFERENCES invoice_line(line_id));
