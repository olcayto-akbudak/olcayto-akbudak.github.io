# Sevkiyat ile fatura nasıl mutabık olur?

Kısmi faturalama, çoklu sevkiyat, miktar farkı ve ay sonu kesimini aynı kontrol paketi içinde ele alan bir tasarım.

## English overview

A delivery/invoice control design based on Microsoft’s open WWI schema, with an explicit allocation bridge and eight tested staging queries. No real ERP exception rates are claimed; fixtures are synthetic and WWI lacks Turkish legal dispatch documents.

## İş sorusu ve kaynak sınırı

Microsoft WideWorldImporters açık kaynak şeması incelendi. Sales.Invoices/InvoiceLines ve Warehouse.StockItemTransactions fatura–stok ilişkisini sunuyor. Ancak bu şema Türkiye’deki hukuki e-İrsaliye belgesini veya satır düzeyinde doğrudan irsaliye–fatura köprüsünü sağlamıyor.

Bu nedenle çalışma gerçek kurum verisi analizi olarak sunulmuyor. Resmi açık şema üzerinden boşluk analizi, uyarlanmış staging modeli, SQL kontrolleri ve açıkça sentetik sınır testleri içeriyor. WideWorldImporters yedeği SQL Server’da çalıştırılmadı; gerçek veri üzerinde istisna sayısı hesaplanmadı.

## Yöntem: eşleşme anahtarını doğru kurmak

Önce fatura, stok hareketi ve sipariş arasındaki mevcut anahtarlar belirlendi. Bir sipariş kalemi birden çok sevkiyata; bir sevkiyat birden çok faturaya bölünebilir. Ürün ve cari eşitliği tek başına belge bağı değildir. Adaptasyon modeline açık tahsis köprüsü eklendi: delivery_id + line_id + base_quantity.

Birimler ETL’de onaylı baz birime çevrilir; miktar işareti, satış/iade ve işlem zamanı ayrıştırılır. Fatura satırı ile stok hareketlerini aynı sorguda ham olarak JOIN etmek çoğalma yaratabilir. Önce kendi tane düzeylerinde toplam alınır; sonra anahtar üzerinden karşılaştırılır.

## Kontrol listesi ve sorumluluk

| Kontrol | İstisna | Sorumlu / aksiyon |
| --- | --- | --- |
| UNBILLED_DELIVERY | Kesim öncesi sevkiyatın tahsis edilmemiş miktarı | Operasyon + muhasebe: eksik fatura veya zamanlama kararı |
| UNMATCHED_INVOICE | Satış faturasının tahsis bağlantısı yok | Muhasebe: hizmet/ön fatura istisnası mı, eksik bağ mı? |
| OVERALLOCATED_DELIVERY | Sevkiyat miktarından fazla tahsis | Entegrasyon: mükerrer bağ veya yanlış dönüşüm |
| OVERALLOCATED_INVOICE | Fatura miktarından fazla tahsis | Entegrasyon: satır bağı düzeltme |
| WRONG_ITEM_OR_CUSTOMER | Bağlı kayıtlarda ürün veya cari farkı | Veri sorumlusu: yanlış eşleme |
| PRICE_REVIEW | Onaylı toleransı aşan fiyat farkı | Satış + muhasebe: fiyat/iskonto/kur dayanağı |
| CUTOFF_MISMATCH | Sevkiyat önce, fatura kesimden sonra | Muhasebe: dönem sonu kararı |
| INVALID_CREDIT_REFERENCE | İadenin geçerli satış satırı referansı yok | Muhasebe: önceki belge ve miktar mutabakatı |

## Şema boşluğu ve karar

WWI InvoiceLines, OrderLineID içermez; Invoices üzerinde OrderID vardır. Aynı üründen birden çok sipariş satırı bulunabileceğinden OrderID + StockItemID üzerinden fiyat farkı çıkarmak güvenilir satır eşlemesi değildir. Öneri, kaynağın sahip olduğu gerçek belge bağlarını staging’e almak; yoksa “eşleşti” yerine “inceleme gerekli” sonucu üretmektir.

Kapanış kontrol çıktısı istisna sahibi, dayanak, açılış/kapanış zamanı ve tekrar ölçüm kaydı taşımalı. Kontrol paketi deftere kayıt veya otomatik vergi düzeltmesi yapmaz.

## Kabul senaryoları

- Bir sevkiyat iki faturaya bölünür; miktar iki kez sayılmaz.
- Aynı faturaya iki sevkiyat bağlanır; çoktan çoğa tahsis açıkça korunur.
- Tahsis miktarı iki taraftan herhangi birini aşarsa istisna oluşur.
- Ay sonu sınırı yarı açık zaman aralığıdır: cut-off anındaki belge sonraki döneme gider.
- İade referansı cari ve ürün ile doğrulanır; referans varlığı tek başına yetmez.
- Toleransın tam sınırındaki fiyat farkı alarm üretmez; bir alt birim üzeri üretir.

## Sınırlar

Sekiz SQL kontrolü SQLite staging’de test edildi. T-SQL üretim sorguları ve ETL eşlemesi ilgili sistemde ayrıca doğrulanmalı. Tasarlanan delivery tablosu WWI’de varmış gibi gösterilmez. Gerçek e-İrsaliye, hizmet faturası, masraf, döviz, birim ve iadeler için firma bazlı kurallar gerekir.

## Kaynaklar

- [Microsoft: WWI resmi veri kataloğu](https://learn.microsoft.com/en-us/sql/samples/wide-world-importers-oltp-database-catalog?view=sql-server-ver17)
- [Microsoft: incelenen açık tablo şemaları](https://github.com/microsoft/sql-server-samples/tree/master/samples/databases/wide-world-importers/wwi-ssdt/wwi-ssdt)

Yeniden üretme komutları paket kökündeki README.md içinde. Kaynak URL/hash kayıtları SOURCES.json içinde.
