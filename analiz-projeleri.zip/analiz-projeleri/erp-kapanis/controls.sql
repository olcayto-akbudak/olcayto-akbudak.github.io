-- Portable staging controls. Amounts use integer minor units. Quantity is an
-- integer in a canonical base unit chosen during ETL. This is an adaptation,
-- not a claim that WWI contains Turkish legal dispatch documents.
-- control: UNBILLED_DELIVERY
SELECT d.delivery_id,d.item_id,d.base_quantity-COALESCE(a.allocated,0) AS open_quantity
FROM delivery d LEFT JOIN (SELECT delivery_id,SUM(base_quantity) allocated FROM allocation GROUP BY delivery_id) a USING(delivery_id)
WHERE d.delivered_at<:cutoff AND d.base_quantity>COALESCE(a.allocated,0);
-- control: UNMATCHED_INVOICE
SELECT i.line_id FROM invoice_line i WHERE i.issued_at<:cutoff AND i.kind='SALE' AND NOT EXISTS(SELECT 1 FROM allocation a WHERE a.line_id=i.line_id);
-- control: OVERALLOCATED_DELIVERY
SELECT d.delivery_id FROM delivery d JOIN allocation a USING(delivery_id) GROUP BY d.delivery_id,d.base_quantity HAVING SUM(a.base_quantity)>d.base_quantity;
-- control: OVERALLOCATED_INVOICE
SELECT i.line_id FROM invoice_line i JOIN allocation a USING(line_id) GROUP BY i.line_id,i.base_quantity HAVING SUM(a.base_quantity)>i.base_quantity;
-- control: WRONG_ITEM_OR_CUSTOMER
SELECT a.delivery_id,a.line_id FROM allocation a JOIN delivery d USING(delivery_id) JOIN invoice_line i USING(line_id) WHERE d.item_id<>i.item_id OR d.customer_id<>i.customer_id;
-- control: PRICE_REVIEW
SELECT a.delivery_id,a.line_id FROM allocation a JOIN delivery d USING(delivery_id) JOIN invoice_line i USING(line_id) WHERE ABS(d.agreed_unit_minor-i.unit_minor)>:price_tolerance;
-- control: CUTOFF_MISMATCH
SELECT a.delivery_id,a.line_id FROM allocation a JOIN delivery d USING(delivery_id) JOIN invoice_line i USING(line_id) WHERE d.delivered_at<:cutoff AND i.issued_at>=:cutoff;
-- control: INVALID_CREDIT_REFERENCE
SELECT i.line_id FROM invoice_line i WHERE i.kind='CREDIT' AND NOT EXISTS(SELECT 1 FROM invoice_line o WHERE o.line_id=i.original_line_id AND o.kind='SALE' AND o.item_id=i.item_id AND o.customer_id=i.customer_id);
