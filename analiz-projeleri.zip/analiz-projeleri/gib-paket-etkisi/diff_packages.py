"""Content and semantic inventory for two supplied official ZIP snapshots."""
import argparse, difflib, hashlib, json, zipfile
from pathlib import Path
from lxml import etree
SCH={'sch':'http://purl.oclc.org/dsdl/schematron'}

def inventory(path):
    with zipfile.ZipFile(path) as z:
        return {n.split('/',1)[-1]:z.read(n) for n in z.namelist() if not n.endswith('/')}

def semantic(data):
    root=etree.fromstring(data,etree.XMLParser(resolve_entities=False,no_network=True))
    entries={}
    for e in root.xpath('//sch:let | //sch:rule',namespaces=SCH):
        kind=etree.QName(e).localname
        key=kind+':'+(e.get('name') or e.get('id') or e.get('context') or '')
        # Repeated contexts are legal in different patterns. Keep pattern identity.
        pattern=e.getparent().get('id') or ''
        if key in entries: key=key+'@'+pattern
        if key in entries: raise ValueError('Duplicate semantic key '+key)
        entries[key]={'value':e.get('value'),'asserts':[a.get('test') for a in e.findall('sch:assert',SCH)],'extends':[a.get('rule') for a in e.findall('sch:extends',SCH)]}
    return entries

def run(old,new,out):
    out.mkdir(parents=True,exist_ok=True);a=inventory(old);b=inventory(new);changes=[]
    for name in sorted(a.keys()|b.keys()):
        if a.get(name)==b.get(name):continue
        item={'path':name,'status':'added' if name not in a else 'removed' if name not in b else 'modified','old_sha256':hashlib.sha256(a[name]).hexdigest() if name in a else None,'new_sha256':hashlib.sha256(b[name]).hexdigest() if name in b else None}
        if name.endswith('.xml') and name in a and name in b:
            x=semantic(a[name]);y=semantic(b[name]);item['semantic_changes']=[{'key':k,'before':x.get(k),'after':y.get(k)} for k in sorted(x.keys()|y.keys()) if x.get(k)!=y.get(k)]
            diff=''.join(difflib.unified_diff(a[name].decode('utf-8-sig').splitlines(True),b[name].decode('utf-8-sig').splitlines(True),fromfile='A/'+name,tofile='B/'+name))
            (out/(Path(name).stem+'.diff')).write_text(diff,encoding='utf-8')
        changes.append(item)
    report={'old_sha256':hashlib.sha256(old.read_bytes()).hexdigest(),'new_sha256':hashlib.sha256(new.read_bytes()).hexdigest(),'files_a':len(a),'files_b':len(b),'changed_files':len(changes),'changed_xsd_files':sum(c['path'].endswith('.xsd') for c in changes),'changes':changes}
    (out/'package-diff.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='changes'}))
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('old',type=Path);p.add_argument('new',type=Path);p.add_argument('--output',type=Path,default=Path('outputs'));a=p.parse_args();run(a.old,a.new,a.output)
