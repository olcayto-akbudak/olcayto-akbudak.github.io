# Paket değişti. Hangi modül etkileniyor?

GİB’in iki paket bağlantısındaki değişiklikler veri modeline, ekran doğrulamasına ve regresyon setine nasıl yansıyor?

## English overview

A reproducible diff of two official downloadable package snapshots: 3 changed XML files, 6 semantic entries, no changed XSD files. Includes rule-to-module-to-test traceability. Mutable URLs are explicitly distinguished from historical release archives.

## İş sorusu

Paket güncellemesini yalnızca ZIP dosyasını değiştirerek uygulamak yeterli mi? Bu çalışma dosya farkını iş etkisine çevirir; kod listesi değişikliği, ortak kontrol ve ana kural çağrısı birlikte izlenir.

## Kaynak ve sürüm sınırı

GİB duyurularındaki 27 Temmuz 2026 bağlantısı e-FaturaPaketi.zip; 24 Ağustos 2026 düzeltme bağlantısı e-FaturaPaketi (29).zip olarak sunuluyor. Her iki dosya 3 Ekim 2026’da indirildi ve SHA-256 ile sabitlendi. Duyuruda ortak devreye alma tarihi 14 Eylül 2026 olarak belirtiliyor.

Önemli ayrım: Bunlar duyurulardaki bağlantıların erişim günündeki içerikleridir. URL’ler sonradan değiştirilebilir; indirilen byte’ların tarihsel yayın gününün birebir arşiv kopyası olduğu kanıtlanmadı. Bu nedenle bulguyu “27 Temmuz tarihindeki kesin içerik” diye sunmuyorum.

## Yöntem

Arşiv kök klasörü çıkarıldıktan sonra tam göreli dosya yolları eşlendi. Önce byte farkı, sonra Schematron let/rule/assert/extends farkı incelendi. Aynı context’in farklı pattern’lerde tekrar etmesi ayrı tutuldu. XML biçimi ile iş kuralı etkisi birbirine karıştırılmadı.

## Bulgu

İki arşivde de 57 dosya var. Üç dosya değişiyor: UBL-TR_Codelist.xml, UBL-TR_Common_Schematron.xml ve UBL-TR_Main_Schematron.xml. Altı semantik kayıt farklı. XSD dosyalarında bu çift arasında değişiklik bulunmadı.

En belirgin değişim, plaka kodlarının dorse kodlarından ayrılması. Yeni TransportEquipmentID kontrolü ana Schematron’daki e-İrsaliye bağlamına bağlanıyor. Plaka zorunluluğu kontrolü de şoför bilgisi bulunmasına bağlı hale geliyor. Paket adında e-Fatura yazması, etkinin yalnız fatura modülüyle sınırlı olduğunu göstermiyor.

## Etki ve izlenebilirlik matrisi

| Kimlik | Kural | Değişiklik | Modül | Kabul | Sınır testi |
| --- | --- | --- | --- | --- | --- |
| CHG-01 | LicensePlateIDSchemeIDType | PLAKA/YABANCIPLAKA ile dorse kodlarının ayrılması | Sevkiyat ana verisi, araç seçimi, XML üretici | DORSE değeri RoadTransport/LicensePlateID içinde reddedilir | PLAKA=34ABC123 kabul; DORSE burada ret |
| CHG-02 | TransportEquipmentIDSchemeIDType | Dorse kodları için yeni liste | Dorse kayıtları ve TransportHandlingUnit | DORSE/DORSEPLAKA doğru TransportEquipment/ID alanına taşınır | DORSE=34ABC123 doğru düğümde kabul; PLAKA aynı düğümde ret |
| CHG-03 | LicensePlateIDSchemeIDCheck | Yerli/yabancı plaka kontrollerinin daraltılması | Ekran validasyonu ve API doğrulama | Yerel plaka 01–81 öneki; yabancı format farklı | 00ABC1 ve 82ABC1 ret; boş yabancı plaka ret |
| CHG-04 | TransportEquipmentIDSchemeIDCheck | Yeni dorse kontrol kuralı | Paylaşılan sevkiyat validatörü | Yerli/yabancı dorse biçimleri doğru kodla doğrulanır | YABANCIDORSE=AB-12 kabul; DORSE=AB-12 ret |
| CHG-05 | LicensePlateIDCheck | Şoför varsa plaka zorunluluğu koşulu | Sevkiyat formu ve eksiklik uyarısı | Şoförsüz kaydı eski koşulla yanlış reddetme | Şoför var + plaka yok ret; şoför yok + plaka yok bu kuraldan geçer |
| CHG-06 | Main Schematron yeni context | TransportEquipment/ID bağlamının kuralı çağırması | Schematron derleme ve paket dağıtımı | Yeni kural sadece tanımlanmaz; ana bağlamdan çalıştırılır | Dorse düğümüne geçersiz schemeID verildiğinde hata oluşur |

## Karar ve dağıtım planı

- Araç plakası ile dorse bilgisini farklı alanlarda tut; geçmişte tek alan kullanılan kayıtlara kontrollü dönüşüm listesi üret.
- UI, API ve XML üreticinin aynı onaylı kod listesi sürümünü kullanmasını sağla.
- Ortak kural dosyası ile Main Schematron çağrılarını atomik paket olarak dağıt; yeni kural tanımının çağrılmaması regresyon olarak test edilir.
- Pilot öncesi yeni/eskiden üretilmiş sevkiyat XML’lerinde doğru düğüm, yerli/yabancı biçim ve şoför koşullarını karşılaştır.
- Başarısız üretim, kural sürümü, hata sınıfı ve dönüşüm kuyruğu metriklerini izle; rollback XML/veri dönüşümü etkisini de kapsasın.

## Sınırlar

Bu çiftte XSD farkı olmadığı için yeni kolon zorunluluğu keşfedilmiş gibi sunulmaz. Esas öneri mevcut sevkiyat verisinin anlamını ayırmaktır. Sınır testleri seçilmiş ifadelerin iş etkisini denetler; tüm GİB Schematron paketinin çalıştırıldığı veya resmi test ortamında kabul alındığı iddiası yoktur.

## Kaynaklar

- [GİB: 27.07 ve 24.08.2026 duyuruları](https://ebelge.gib.gov.tr/duyurular.html)
- [Paket A: erişim günü snapshot](https://ebelge.gib.gov.tr/dosyalar/kilavuzlar/e-FaturaPaketi.zip)
- [Paket B: erişim günü snapshot](https://ebelge.gib.gov.tr/dosyalar/kilavuzlar/e-FaturaPaketi%20(29).zip)

Yeniden üretme komutları paket kökündeki README.md içinde. Kaynak URL/hash kayıtları SOURCES.json içinde.
