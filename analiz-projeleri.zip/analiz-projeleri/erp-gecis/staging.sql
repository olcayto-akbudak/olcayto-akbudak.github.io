CREATE TABLE source_master(source_id TEXT PRIMARY KEY,name TEXT NOT NULL);
CREATE TABLE target_master(target_id TEXT PRIMARY KEY,name TEXT NOT NULL);
CREATE TABLE mapping(source_id TEXT PRIMARY KEY,target_id TEXT NOT NULL,approved_by TEXT NOT NULL,decision_ref TEXT NOT NULL);
CREATE TABLE source_balance(source_id TEXT NOT NULL,currency TEXT NOT NULL,debit_minor INTEGER NOT NULL,credit_minor INTEGER NOT NULL);
CREATE TABLE opening_balance(target_id TEXT NOT NULL,currency TEXT NOT NULL,debit_minor INTEGER NOT NULL,credit_minor INTEGER NOT NULL);
