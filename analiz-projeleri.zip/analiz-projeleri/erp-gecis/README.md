# Geçişten önce verinin hesabını ver.

Cari ve stok eşlemesi, açılış bakiyesi ve kesim anını aynı geçiş kararı içinde toplayan çalıştırılabilir bir hazırlık paketi.

## English overview

A migration readiness and reconciliation guide, including mapping and risk templates and five executable checks. Debit and credit are reconciled separately by customer and currency; no completed customer migration or operational improvement is claimed.

## İş sorusu

Yeni ERP açıldığında hangi kayıt taşındı, hangisi dönüştürüldü ve hangi bakiye hangi eski kayda dayanıyor? Bu çalışma belirli bir şirket geçişinin sonucu değildir; bağımsız bir gereksinim ve kabul tasarımıdır. İşveren verisi veya iç uygulama kararı kullanılmadı.

## Yöntem ve geçiş sırası

- Envanter: cari, stok, birim, para birimi, hesap, açık sipariş ve belgeler; sahibi ve tane düzeyi kaydedilir.
- Profil çıkarma: boş anahtar, tekillik, yetim bağlantı, negatif/uygunsuz miktar ve tarih formatları ölçülür.
- Eşleme: her kaynak anahtarının hedef anahtarı ve onaylı birleşme/ayrılma kararı saklanır.
- Prova: salt okunur snapshot, aktarım sürümü ve sonuç hash’leriyle tekrarlanır.
- Mutabakat: kayıt sayısı yanında borç ve alacak ayrı, cari ve para birimi bazında karşılaştırılır.
- Kesim: değişiklik dondurma/delta yakalama kararı; son aktarım ve iş birimi kabulü.
- Açılış sonrası: belge izlenebilirliği, rol kabulü ve ilk kapanış kontrolü; geri dönüş koşulu.

## Bulgu: net bakiye eşitliği tek başına yetmez

Tasarlanmış sınır örneği: kaynak borç 100, alacak 80; hedef borç 20, alacak 0. Net bakiye her iki tarafta 20 olduğu halde borç/alacak hareket temeli farklıdır. Kontrol bu nedenle iki toplamı ayrı tutar. Benzer şekilde toplam TRY + EUR sayısal eşitliği anlamlı bir muhasebe mutabakatı değildir.

| Kontrol | Amaç | Kapı |
| --- | --- | --- |
| MISSING_MAPPING | Taşınmayan kaynak kartı | Açıklanamayan kaynak kartı kalmaz |
| MISSING_TARGET | Olmayan hedefe işaret | Hedef referansı bulunur |
| DUPLICATE_TARGET_REVIEW | Çoktan-bire birleşme | Onaylı karar olmadan tamamlanmaz |
| ORPHAN_BALANCE | Kartı olmayan bakiye | Anahtar/dönem araştırılır |
| BALANCE_DIFFERENCE | Cari + para birimi bazlı ayrı borç/alacak | Fark sıfır veya kanıtlı dönüşüm kararı |

## Eşleme ve veri kalitesi

CSV şablonu anahtar, vergi kimliği, hedef, durum, onaylayan ve karar referansı taşır. Vergi kimliği tek başına tüm carileri otomatik birleştirmez; şube, kişi/kurum ve hukuki kayıt ayrımı incelenir. Stok için ad benzerliği yeterli değildir: varyant, birim, lot/seri ve fiyat bazını doğrulamak gerekir. Açılış stok miktarı depo/birim/lot düzeyinde ayrı mutabık olmalıdır.

## Karar ve sorumluluk

Geçiş onayı “script bitti” sonucundan verilmez. Muhasebe borç/alacak ve dönem sınırını, operasyon stok ve açık siparişleri, veri sahibi eşlemeleri, BT ise tekrarlanabilir snapshot ve geri dönüşü kabul eder. SQL paketi birleştirilmiş kartların beklenen toplamlarını hesaplar; birleşmenin uygun olduğuna kendi karar vermez.

## Sınırlar

Beş mutabakat SQL’i sentetik kabul örneklerinde çalıştırıldı. Şablon evrensel ERP aktarım formatı değildir. Stok değerleme, hesap planı, kur dönüşümü, lot/seri ve açık belge aktarım SQL’i sistem bazında geliştirilmelidir. Bu paket tamamlanmış bir müşteri geçişi veya veri üzerinde ölçülmüş kazanım gibi sunulmaz.

## Kaynaklar

- [Açık ERP benzeri veri modeli bağlamı: Microsoft WWI](https://learn.microsoft.com/en-us/sql/samples/wide-world-importers-oltp-database-catalog?view=sql-server-ver17)

Yeniden üretme komutları paket kökündeki README.md içinde. Kaynak URL/hash kayıtları SOURCES.json içinde.
