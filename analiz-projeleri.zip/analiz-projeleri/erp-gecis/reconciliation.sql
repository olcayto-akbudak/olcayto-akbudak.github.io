-- control: MISSING_MAPPING
SELECT s.source_id FROM source_master s LEFT JOIN mapping m USING(source_id) WHERE m.target_id IS NULL;
-- control: MISSING_TARGET
SELECT m.source_id,m.target_id FROM mapping m LEFT JOIN target_master t USING(target_id) WHERE t.target_id IS NULL;
-- control: DUPLICATE_TARGET_REVIEW
SELECT target_id,COUNT(*) source_cards FROM mapping GROUP BY target_id HAVING COUNT(*)>1;
-- control: ORPHAN_BALANCE
SELECT b.source_id,b.currency FROM source_balance b LEFT JOIN source_master s USING(source_id) WHERE s.source_id IS NULL;
-- control: BALANCE_DIFFERENCE
WITH expected AS (SELECT m.target_id,b.currency,SUM(b.debit_minor) debit,SUM(b.credit_minor) credit FROM source_balance b JOIN mapping m USING(source_id) GROUP BY m.target_id,b.currency),actual AS (SELECT target_id,currency,SUM(debit_minor) debit,SUM(credit_minor) credit FROM opening_balance GROUP BY target_id,currency),keys AS (SELECT target_id,currency FROM expected UNION SELECT target_id,currency FROM actual)
SELECT k.target_id,k.currency,COALESCE(e.debit,0)-COALESCE(a.debit,0) debit_diff,COALESCE(e.credit,0)-COALESCE(a.credit,0) credit_diff FROM keys k LEFT JOIN expected e USING(target_id,currency) LEFT JOIN actual a USING(target_id,currency) WHERE COALESCE(e.debit,0)<>COALESCE(a.debit,0) OR COALESCE(e.credit,0)<>COALESCE(a.credit,0);
