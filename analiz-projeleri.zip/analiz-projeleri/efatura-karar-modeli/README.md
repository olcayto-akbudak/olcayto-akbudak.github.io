# Senaryo ile fatura tipi aynı karar değil.

Kanal, süreç ve vergi niteliğini ayrı kararlar olarak ele alan; bilinmeyen vergi durumunda tahmin üretmeyen bir ön inceleme modeli.

## English overview

Separates channel, process profile, tax treatment and prior-document references. Identifies an actual mismatch between a published legacy return example and the downloaded current rule. The executable model implements a scoped subset, not issuance authorization.

## İş sorusu ve kaynak

Faturanın e-Fatura/e-Arşiv kanalı, TEMEL/TICARI gibi profili ve SATIS/IADE/TEVKIFAT gibi tipi farklı karar eksenleridir. Çalışma Temmuz 2026 tarihli GİB Kod Listeleri 1.43 ve indirilen paket B’deki InvoiceTypeCodeCheck kuralını esas alır. İşlem koşulları şirket veya ürün iç bilgisi içermez.

## Yöntem: dört karar kapısı

- Kanal: alıcı kayıt durumu ve sorgu zamanı kanıtı. Kayıt bilinmiyorsa kanal önerisi durur.
- Süreç: tarafların işlem şekli ve özel profil kapsamı. Temel/ticari seçim sadece satış veya iade tipinden türetilmez.
- Vergi niteliği: istisna, tevkifat, özel matrah veya ihraç kayıtlı işlemin dayanağı ayrı onaylanır.
- Belge ilişkisi: iade ve düzeltmede önceki fatura referansı ve karşı taraf kaydı doğrulanır.

## Kaynaklı karar tablosu

| Durum | Teknik kontrol | İş kararı |
| --- | --- | --- |
| Normal satış | Profil ve SATIS kodu kaynak listede | TEMEL/TICARI seçimini sözleşme ve süreç belirler |
| IADE + TICARIFATURA | İndirilen InvoiceTypeCodeCheck bu eşleşmeyi reddediyor | Eski örneği güncel kural gibi kullanma; izinli profile göre yeniden tasarla |
| IADE + TEMELFATURA | Seçilmiş profil kuralı izin veriyor | Önceki fatura ilişkisinin tamlığını ayrıca denetle |
| ENERJI | SARJ veya SARJANLIK ile eşleşmeli | Şarj işleminin kapsamı ayrıca doğrulanır |
| TEKNOLOJIDESTEK | EARSIVFATURA profili gerektirir | Destek şartlarını teknik kod geçerliliği kanıtlamaz |
| YTBISTISNA | e-Arşiv yatırım teşvik tipidir | ISTISNA ile körlemesine değiştirme |
| YATIRIMTESVIK | Özel e-Fatura tip kümesi kullanılır | Teşvik belgesi/dayanak onayı gerekir |
| İhracat / ihraç kayıtlı | IHRACAT profil ile IHRACKAYITLI tipi ayrı kavramlar | Ülke yabancı diye otomatik sınıf üretme |
| Vergi dayanağı bilinmiyor | Teknik kod geçerli olsa da REVIEW | Muhasebe/vergi onayı beklenir |

## Bulgu: örnek ile güncel kural çelişebilir

UBL-TR örnek paketinde IadeFaturasiOrnegi.xml, TICARIFATURA + IADE kombinasyonu içeriyor. Buna karşılık güncel indirilen paket B’deki kural IADE için TEMELFATURA, EARSIVFATURA, ILAC_TIBBICIHAZ, YATIRIMTESVIK, IDIS veya KAMU profillerini sayıyor. Bu, örneklerin tarihsel eğitim içeriği ile güncel doğrulama kurallarını ayrı değerlendirmek gerektiğini somut olarak gösteriyor.

## Hata kataloğu ve kabul

- Kanalı tipten türetmek → ayrı kayıt durumu kanıtı zorunlu.
- İadeyi ticari profilde eski örneğe bakarak kabul etmek → güncel kural sürümüyle test.
- Sıfır KDV’yi otomatik ISTISNA yapmak → dayanak ve kod ailesi onayı.
- İhracat ile ihraç kayıtlıyı birleştirmek → ayrı iş sorusu ve onay kapısı.
- Tüm yabancı müşterilere aynı profil vermek → işlem türü ve teknik kanal sorgusu.
- Bilinmeyen tip veya profil → blok; vergi dayanağı eksik → inceleme; geçilen seçilmiş kontroller → resmi validasyona devam.

## Karar ve sınırlar

Önerim tek bir dev dropdown yerine kanal, süreç ve vergi kararını ayrı kaydetmek; her sonucun kural sürümü ve kanıtını saklamak. Python modelindeki onay gereksinimleri tasarım önerisidir; resmi kurallarla aynı etiketi taşımaz. Bu model tüm özel profilleri, mevzuatı veya GİB kurallarını kapsamaz; fatura düzenleme izni vermez.

## Kaynaklar

- [GİB: Kod Listeleri 1.43, bölüm 1.4 ve 2.2](https://ebelge.gib.gov.tr/dosyalar/kilavuzlar/UBLTR_1.2.1_Kilavuzlar.zip)
- [GİB: InvoiceTypeCodeCheck ve özel profil kontrolleri](https://ebelge.gib.gov.tr/dosyalar/kilavuzlar/e-FaturaPaketi%20(29).zip)
- [GİB: eski iade örneği ile kural karşılaştırması](https://ebelge.gib.gov.tr/dosyalar/kilavuzlar/UBL-TR1.2.1_Paketi.zip)

Yeniden üretme komutları paket kökündeki README.md içinde. Kaynak URL/hash kayıtları SOURCES.json içinde.
