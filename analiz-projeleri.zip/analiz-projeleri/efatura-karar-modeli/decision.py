"""A scoped requirements model, not a tax adviser or full GİB validator."""
IADE_PROFILES={'TEMELFATURA','EARSIVFATURA','ILAC_TIBBICIHAZ','YATIRIMTESVIK','IDIS','KAMU'}
YTB_ARCHIVE={'YTBSATIS','YTBIADE','YTBISTISNA','YTBTEVKIFAT','YTBTEVKIFATIADE'}
PROFILES={'TICARIFATURA','TEMELFATURA','YOLCUBERABERFATURA','IHRACAT','EARSIVFATURA','OZELFATURA','KAMU','HKS','ENERJI','ILAC_TIBBICIHAZ','YATIRIMTESVIK','IDIS'}
TYPES={'SATIS','IADE','TEVKIFAT','TEVKIFATIADE','ISTISNA','OZELMATRAH','IHRACKAYITLI','SGK','KOMISYONCU','HKSSATIS','HKSKOMISYONCU','KONAKLAMAVERGISI','SARJ','SARJANLIK','TEKNOLOJIDESTEK'}|YTB_ARCHIVE

def review(data):
    profile=data.get('profile');kind=data.get('type');errors=[];holds=[]
    if profile is None or kind is None:errors.append('MISSING_PROFILE_OR_TYPE')
    if profile not in PROFILES:errors.append('UNKNOWN_PROFILE')
    if kind not in TYPES:errors.append('UNKNOWN_TYPE')
    if data.get('recipient_registered') is None or not data.get('registry_checked_at'):holds.append('REGISTRY_EVIDENCE_REQUIRED')
    if data.get('recipient_registered') is True and profile=='EARSIVFATURA':errors.append('CHANNEL_REVIEW_REQUIRED')
    if kind=='IADE' and profile not in IADE_PROFILES:errors.append('IADE_PROFILE')
    if (profile=='ENERJI') != (kind in {'SARJ','SARJANLIK'}):errors.append('ENERJI_PAIR')
    if kind=='TEKNOLOJIDESTEK' and profile!='EARSIVFATURA':errors.append('TECH_ARCHIVE')
    if kind in YTB_ARCHIVE and profile!='EARSIVFATURA':errors.append('YTB_ARCHIVE_PROFILE')
    if profile=='YATIRIMTESVIK' and kind not in {'SATIS','IADE','ISTISNA','TEVKIFAT','TEVKIFATIADE'}:errors.append('YTB_EINVOICE_TYPE')
    if kind in {'IADE','TEVKIFATIADE','YTBIADE','YTBTEVKIFATIADE'} and not data.get('original_invoice'):holds.append('RETURN_REFERENCE_REQUIRED')
    if kind in {'ISTISNA','YTBISTISNA','IHRACKAYITLI','OZELMATRAH','TEVKIFAT','TEVKIFATIADE','YTBTEVKIFAT','YTBTEVKIFATIADE'} and not data.get('tax_basis_approved'):holds.append('TAX_REVIEW_REQUIRED')
    return {'status':'BLOCKED' if errors else 'REVIEW' if holds else 'SCOPED_CHECKS_PASSED','errors':errors,'holds':holds,'limits':'Unknown profiles/types and all unimplemented Schematron rules require official validation; this outcome never authorizes invoice issuance.'}
